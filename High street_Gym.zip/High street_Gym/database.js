import mysql from "mysql2/promise"
export const db_conn = mysql.createPool({
  host: "localhost",
  port: "3309",
  user: "root",
  password: "root",
  database: "high street gym",

}) 