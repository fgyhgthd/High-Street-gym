import express from "express"
import session from "express-session";




const app = express()
const port = 808
 app.use(express.urlencoded({ extended: true }))

// setup and use dession middleware 
 app.use(session({
    secret: "secret phrase",
    resave: false,
    saveUninitialized: false,
    cookie: { secure: false },
}))

import userController from "./controllers/users.js";
app.use( userController)
import postController from "./controllers/blog_post.js";
app.use( postController)
import 
activityController from "./controllers/activties.js";
app.use(
    activityController)

    import 
    bookingController from "./controllers/booking.js";
    app.use(
        bookingController)

        import 
        locationController from "./controllers/loctaion.js";
        app.use(
            locationController)
        
    
   
       

import 
classesController from "./controllers/classes.js";
app.use(
    classesController)



//setup and use  the ejs view engine 
app.set("view engine", "ejs")
// TODO: Middleware goes here (things like 
// authentication, session, and cookies)

// Serve static files (such as images and CSS)
app.use(express.static("static"))



// TODO: Connect up the controllers to the server
// app.use(calculatorController)

app.get("/", (request, response) => {
    response.status(200).send("Hi ")

    

    // response.status(301).redirect("/calculator/add")
})

app.get("/", (request, response) => {
    response.status(301).redirect("/staff_login")
})

app.get("/login", (request, response) => {

    response.render("login.ejs", {})

})
app.get("/home", (request, response) => {

    response.render("home.ejs",  {role: request.session.user.role})
  


})

// Start listening for requests to handle with the controllers
app.listen(port, () => {
    console.log("Express server started on http://localhost:" + port)
    console.log("index:http://localhost:" + port + "/home")
    console.log("index:http://localhost:" + port + "/login")
    console.log("index:http://localhost:" + port + "/add_activtes")
    console.log("index:http://localhost:" + port + "/booking_view")
})




