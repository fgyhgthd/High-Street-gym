import express from "express";
import * as activittes from "../models/activties.js";
import * as clesses from "../models/classes.js";
import * as newclesses from "../models/class_activity.js";
import access_control from "../access_control.js";
import * as location from "../models/location.js";
import * as users from "../models/users.js";
import validator from "validator"
import { getAllByclassid, getBySearchClass } from "../models/class_activity.js";

const classesController = express.Router();

// GET route for booking classes
classesController.get("/booking", access_control(["members"]), (request, response) => {
    const editID = request.query.edit_id;
    const daysOfWeek = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
    const today = new Date();

    // Calculate the date of the Monday of the current week
    const mondayOfThisWeek = new Date();
    mondayOfThisWeek.setDate(today.getDate() - (today.getDay() - 1));

    const sundayOfThisWeek = new Date(mondayOfThisWeek);
    sundayOfThisWeek.setDate(sundayOfThisWeek.getDate() + 6);

    // Build an object wityh days as keys and lists of classes as values
    const classesByDay = {
        "Monday": [],
        "Tuesday": [],
        "Wednesday": [],
        "Thursday": [],
        "Friday": [],
        "Saturday": [],
        "Sunday": [],
    };



    // Query the database for classes between the start and end of the week
    newclesses.getAllByclassDate(mondayOfThisWeek, sundayOfThisWeek)
        .then(Classdateandtime => {
            // Iterate over the classes retrieved from the database
            for (const classes of Classdateandtime) {
                // Parse the class date from the database
                const classDate = new Date(classes.Class_datetime);
                // Get the day of the week for the class
                const dayOfWeek = daysOfWeek[classDate.getDay()];
                // Push the class to the corresponding day in the classesByDay object
                classesByDay[dayOfWeek].push(classes);
            }

            // Render the "activites.ejs" view with the classesByDay object and user's role
            response.render("activites.ejs", { classesByDay, role: request.session.user.role });
        })
        .catch(error => {
            // Handle errors if the database query fails
            console.error("Error fetching classes by date:", error);
            response.status(500).send("Error fetching classes. Please try again later.");
        });
});

// GET route for booking a specific class
classesController.get("/book_class", access_control(["members"]), (request, response) => {
    if (request.query.id) {
        getAllByclassid(request.query.id)
            .then(clesses => {
                response.render("book_class.ejs", {
                    clesses,
                    role: request.session.user.role,
                    userID: request.session.user.userID
                });
            })
            .catch(error => {
                response.send("Error: " + error);
            });
    }
});

// GET route for managing classes (for managers and trainers)
classesController.get("/cless", access_control(["manager", "trainer"]), (request, response) => {
    if (request.query.search_term) {
        getBySearchClass(request.query.search_term)
            .then(allnewclessess => {
                location.getAll()
                    .then(alllocation => {
                        activittes.getAll()
                            .then(allactivittes => {
                                users.getAll()
                                    .then(alluser => {
                                        response.status(200).render("cless.ejs", {
                                            allnewclessess,
                                            alllocation,
                                            allactivittes,
                                            alluser,
                                            role: request.session.user.role,
                                            editnewclesses: clesses.newClasses(0, "", "", "", ""),
                                        });
                                    })
                                    .catch(error => {
                                        console.error("Error fetching users:", error);
                                        response.status(500).send("Internal Server Error");
                                    });
                            })
                            .catch(error => {
                                console.error("Error fetching activities:", error);
                                response.status(500).send("Internal Server Error");
                            });
                    })
                    .catch(error => {
                        console.error("Error fetching locations:", error);
                        response.status(500).send("Internal Server Error");
                    });
            })
            .catch(error => {
                console.error("Error searching classes:", error);
                response.status(500).send("Internal Server Error");
            });
        return;
    }

    // Handle other logic for rendering without search term
    let allnewclessess = [];
    let editnewclesses = {};

    newclesses.getAllByclassactivties()
        .then(classes => {
            allnewclessess = classes;

            const editID = request.query.edit_id;
            if (editID) {
                clesses.getById(editID)
                    .then(editClass => {
                        editnewclesses = editClass;
                        console.log(editnewclesses)
                        location.getAll()
                            .then(alllocation => {
                                activittes.getAll()
                                    .then(allactivittes => {
                                        users.getAll()
                                            .then(alluser => {
                                                response.render("cless.ejs", {
                                                    allnewclessess,
                                                    editID: editID,
                                                    alllocation,
                                                    allactivittes,
                                                    editnewclesses,
                                                    alluser,
                                                    role: request.session.user.role
                                                });
                                            })
                                            .catch(error => {
                                                console.error("Error fetching users:", error);
                                                response.status(500).send("Internal Server Error");
                                            });
                                    })
                                    .catch(error => {
                                        console.error("Error fetching activities:", error);
                                        response.status(500).send("Internal Server Error");
                                    });
                            })
                            .catch(error => {
                                console.error("Error fetching locations:", error);
                                response.status(500).send("Internal Server Error");
                            });
                    })
                    .catch(error => {
                        console.error("Error fetching edit class:", error);
                        response.status(500).send("Internal Server Error");
                    });
            } else {
                editnewclesses = clesses.newClasses(0, "", "", "", "");

                location.getAll()
                    .then(alllocation => {
                        activittes.getAll()
                            .then(allactivittes => {
                                users.getAll()
                                    .then(alluser => {
                                        response.render("cless.ejs", {
                                            allnewclessess,
                                            alllocation,
                                            allactivittes,
                                            editnewclesses,
                                            alluser,
                                            role: request.session.user.role
                                        });
                                    })
                                    .catch(error => {
                                        console.error("Error fetching users:", error);
                                        response.status(500).send("Internal Server Error");
                                    });
                            })
                            .catch(error => {
                                console.error("Error fetching activities:", error);
                                response.status(500).send("Internal Server Error");
                            });
                    })
                    .catch(error => {
                        console.error("Error fetching locations:", error);
                        response.status(500).send("Internal Server Error");
                    });
            }
        })
        .catch(error => {
            console.error("Error fetching classes:", error);
            response.status(500).send("Internal Server Error");
        });
});

// POST route for editing classes
classesController.post("/edit_class", access_control(["manager", "trainer"]), (request, response) => {
    const formData = request.body;
    const Class_id = formData.class_id;

    const editClasses = clesses.newClasses(
        validator.escape(Class_id),
        validator.escape(formData.Class_datetime),
        validator.escape(formData.location_id),
        validator.escape(formData.activity_id),
        validator.escape(formData.trainer_user_id),


    );
    console.log(formData)
    console.log(editClasses)

    if (formData.action === "create") {
        clesses.create(editClasses)
            .then(([result]) => {
                console.log(result)
                response.redirect("/cless");
            })

    } else if (formData.action === "update") {
        clesses.update(editClasses)
            .then(([result]) => {
                console.log(result)
                response.redirect("/cless");
            })

    } else if (formData.action === "delete") {
        clesses.deleteById(editClasses.id)
            .then(([result]) => {
                console.log(result)
                response.redirect("/cless");
            })

    }
});

export default classesController;