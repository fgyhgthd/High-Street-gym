import express from "express"
import validator from "validator";
import * as users from "../models/users.js";
import { getAllByclassid } from "../models/class_activity.js";
import access_control from "../access_control.js";
import bcrypt from "bcryptjs";

const usercontroller = express.Router();

// Middleware to parse JSON bodies
usercontroller.use(express.json());

// GET route for fetching users

// login page 
usercontroller.get("/login", (request, response) => {
    response.render("login.ejs");
});

usercontroller.post("/login", (request, response) => {
    const login_email = request.body.email;
    const login_password = request.body.password;

    users.getByemail(login_email).then(user => {

        if (bcrypt.compareSync(login_password, user.password)) {
            request.session.user = {
                userID: user.id,
                role: user.role,
            }

            response.redirect("/home")


        } else {
            response.render("status_login.ejs", { status: "Login Failed", message: "Your emial or password is  incorrect please try again" });
        }
    }).catch(error => {
        response.render("status_login.ejs", { status: "Login Failed", message: "Your emial or password is  incorrect please try again" });

    })




// log out 


    usercontroller.get("/logout", (request, response) => {
        request.session.destroy();
        response.redirect("/");
    });

});

//  user page 


usercontroller.get("/users", access_control(["manager"]), (request, response) => {
    const editID = request.query.edit_id;

    if (editID) {
        // Fetch user by ID
        users.getById(editID)
            .then(edituser => {
                // Fetch all users
                return users.getAll().then(alluser => {
                    response.render("users.ejs", { alluser, edituser, role: request.session.user.role, });
                });
            })
            .catch(error => {
                // Handle errors
                console.error("Error fetching user by ID:", error);
                response.status(500).send("Internal Server Error");
            });
    } else {
        // Fetch all users
        users.getAll()
            .then(alluser => {
                response.render("users.ejs", {
                    alluser,
                    role: request.session.user.role,
                    edituser: users.newUser(0, "", "", "", "", "", "", ""),
                });
            })

    }


    // POST route for editing users
    usercontroller.post("/edit_user", access_control(["manager"]), (request, response) => {
        const formData = request.body;



        if (!/[a-zA-Z]{2,}/.test(formData.first_name)) {
            response.render("status.ejs", {
                status: "Invalid first name",
                message: "First name must be letters",
            });
            return;
        }

        if (!/[a-zA-Z-]{2,}/.test(formData.last_name)) {
            response.render("status.ejs", {
                status: "Invalid last name",
                message: "Last name must be letters",
            });
            return;
        }

        if (!/[0-9]{10,}/.test(formData.phone)) {
            response.render("status.ejs", {
                status: "Invalid phone",
                message: "Please enter a valid phone number",
            });
            return;
        }

        if (!/^\S+@\S+\.\S+$/.test(formData.email)) {
            response.render("status.ejs", {
                status: "Invalid email",
                message: "Please enter a valid email address for example  hight@outlook.com",
            });
            return;
        }
        if (!/[a-zA-Z0-9-]{6,}/.test(formData.password)) {
            response.render("status.ejs", {
                status: "Invalid password",
                message:
                    "Password must be at least 6 characters long and contain a variety of characters.",
            });
            return;
        }
        if (!/[a-zA-Z0-9\s,'-]*$/.test(formData.address)) {
            response.render("status.ejs", {
                status: "Invalid address",
                message: "Please enter a valid address",
            });
            return;
        }




        // Extract user_id from form data
        const user_id = formData.user_id;

        // Create or update user based on form data
        const edituser = users.newUser(
            validator.escape(user_id),
            validator.escape(formData.email),
            formData.password,
            validator.escape(formData.role),
            validator.escape(formData.phone),
            validator.escape(formData.first_name),
            validator.escape(formData.last_name),
            validator.escape(formData.address),







        )

        // Determine and execute the CRUD operation based on the form button pressed


        if (!edituser.password.startsWith("$2a")) {
            edituser.password = bcrypt.hashSync(edituser.password);
        }


        if (formData.action === "create") {
            users.create(edituser)
                .then(() => {
                    response.redirect("/users");
                })

        } else if (formData.action === "update") {
            users.update(edituser)
                .then(() => {
                    response.redirect("/users");
                })

        } else if (formData.action === "delete") {
            users.deleteById(edituser.id)
                .then(() => {
                    response.redirect("/users");
                })

        }
    });
});





//  Sinup page 

usercontroller.get("/sinup", (request, response) => {
    const editID = request.query.edit_id;

    if (editID) {
        // Fetch user by ID
        users.getById(editID)
            .then(edituser => {
                // Fetch all users
                return users.getAll().then(alluser => {
                    response.render("sinpup.ejs", { alluser, edituser });
                });
            })

    } else {
        // Fetch all users
        users.getAll()
            .then(alluser => {
                response.render("sinpup.ejs", {
                    alluser,
                    edituser: users.newUser(0, "", "", "", "", "", "", ""),
                });
            })

    }




    // POST route for editing users
    usercontroller.post("/edit_signup", (request, response) => {
        const formData = request.body;
        if (!/[a-zA-Z]{2,}/.test(formData.first_name)) {
            response.render("status.ejs", {
                status: "Invalid first name",
                message: "First name must be letters",
            });
            return;
        }

        if (!/[a-zA-Z-]{2,}/.test(formData.last_name)) {
            response.render("status.ejs", {
                status: "Invalid last name",
                message: "Last name must be letters",
            });
            return;
        }

        if (!/[0-9]{10,}/.test(formData.phone)) {
            response.render("status.ejs", {
                status: "Invalid phone",
                message: "Please enter a valid phone number",
            });
            return;
        }

        if (!/^\S+@\S+\.\S+$/.test(formData.email)) {
            response.render("status.ejs", {
                status: "Invalid email",
                message: "Please enter a valid email address for example  hight@outlook.com",
            });
            return;
        }
        if (!/[a-zA-Z0-9-]{6,}/.test(formData.password)) {
            response.render("status.ejs", {
                status: "Invalid password",
                message:
                    "Password must be at least 6 characters long and contain a variety of characters.",
            });
            return;
        }
        if (!/[a-zA-Z0-9\s,'-]*$/.test(formData.address)) {
            response.render("status.ejs", {
                status: "Invalid address",
                message: "Please enter a valid address",
            });
            return;
        }



        // Extract user_id from form data
        const user_id = formData.user_id;

        // Create or update user based on form data
        const edituser = users.newUser(
            validator.escape(user_id),
            validator.escape(formData.email),
            formData.password,
            validator.escape("members"),
            validator.escape(formData.phone),
            validator.escape(formData.first_name),
            validator.escape(formData.last_name),
            validator.escape(formData.address),







        );





        if (!edituser.password.startsWith("$2a")) {
            edituser.password = bcrypt.hashSync(edituser.password);
        }

        if (formData.action === "create") {
            users.create(edituser)
                .then(() => {
                    response.redirect("/login");
                })

        } else if (formData.action === "update") {
            users.update(edituser)
                .then(() => {
                    response.redirect("/login");
                })

        } else if (formData.action === "delete") {
            users.deleteById(edituser.id)
                .then(([result]) => {
                    response.redirect("/login");
                })

        }
    });
});





export default usercontroller;