import express from "express"
import validator from "validator"
import * as  location from "../models/location.js";
import access_control from "../access_control.js";
const locationController = express.Router()








locationController.get("/add_location", access_control(["manager", "trainer"]), (request, response) => {
    const editID = request.query.edit_id;

    if (editID) {
        // Fetch user by ID
        location.getById(editID)
            .then(editlcosction => {
                // Fetch all users
                return location.getAll().then(alllocation => {
                    response.render("add_location.ejs", { alllocation, editlcosction, role: request.session.user.role, });
                });
            })
            .catch(error => {
                // Handle errors
                console.error("Error fetching user by ID:", error);
                response.status(500).send("Internal Server Error");
            });
    } else {
        // Fetch all users
        location.getAll()
            .then(alllocation => {
                response.render("add_location.ejs", {
                    alllocation,
                    role: request.session.user.role,
                    editlcosction: location.newLaction(0, "", "", ""),

                });
            })

    }


    // POST route for editing users
    locationController.post("/edit_location", access_control(["manager", "trainer"]), (request, response) => {
        const formData = request.body;

        // Extract user_id from form data
        const location_id = formData.location_id;
        if (!/[a-zA-Z]{2,}/.test(formData.name)) {
            response.render("status.ejs", {
                status: "Invalid location name",
                message: "location name must be  in letters",
            });
            return;
        }

        // Create or update Clesses based on form data
        const editlcosction = location.newLaction(

            validator.escape(location_id),
            validator.escape(formData.name),



        );

        // Determine and execute the CRUD operation based on the form button pressed
        if (formData.action === "create") {
            location.create(editlcosction)
                .then(() => {
                    response.redirect("/add_location");
                })

        } else if (formData.action === "update") {
            location.update(editlcosction)
                .then(() => {
                    response.redirect("/add_location");
                })

        } else if (formData.action === "delete") {
            location.deleteById(editlcosction.id)
                .then(() => {
                    response.redirect("/add_location");
                })

        }
    });
});



export default locationController