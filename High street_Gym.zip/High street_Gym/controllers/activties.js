import express from "express"
import validator from "validator"
import * as  activittes from "../models/activties.js";
import access_control from "../access_control.js";

const activityController = express.Router()
activityController.get("/add_activtes", access_control(["manager", "trainer"]), (request, response) => {
    const editID = request.query.edit_id;

    if (editID) {
        // Fetch user by ID
        activittes.getById(editID)
            .then(editactivittes => {
                // Fetch all users
                return activittes.getAll().then(allactivittes => {
                    response.render("add_activtes.ejs", { allactivittes, editactivittes, role: request.session.user.role, });
                });
            })
            .catch(error => {
                // Handle errors
                console.error("Error fetching user by ID:", error);
                response.status(500).send("Internal Server Error");
            });
    } else {
        // Fetch all users
        activittes.getAll()
            .then(allactivittes => {
                response.render("add_activtes.ejs", {
                    allactivittes,
                    role: request.session.user.role,
                    editactivittes: activittes.newActivities(0, "", "", ""),

                });
            })

    }

    // POST route for editing users
    activityController.post("/edit_activity", access_control(["manager", "trainer"]), (request, response) => {
        const formData = request.body;

        // Extract user_id from form data
        const activity_id = formData.activity_id;

        if (!/[a-zA-Z]{2,}/.test(formData.name)) {
            response.render("status.ejs", {
                status: "Invalid  Activity name",
                message: " Activity name must be  in letters",
            });
            return;
        }



        if (!/[a-zA-Z]{2,}/.test(formData.description)) {
            response.render("status.ejs", {
                status: "Invalid description",
                message: "description must be  in letters",
            });
            return;
        }


        if (!/[a-zA-Z]{2,}/.test(formData.duration)) {
            response.render("status.ejs", {
                status: "Invalid duration name",
                message: "duration name must be  in number  and  letters for example 20 minute  ",
            });
            return;
        }


        // Create or update Clesses based on form data
        const editactivittes = activittes.newActivities(

            validator.escape(activity_id),

            validator.escape(formData.name),
            validator.escape(formData.description),
            validator.escape(formData.duration),



        );

        // Determine and execute the CRUD operation based on the form button pressed
        if (formData.action === "create") {
            activittes.create(editactivittes)
                .then(() => {
                    response.redirect("/add_activtes");
                })

        } else if (formData.action === "update") {
            activittes.updateActivityById(editactivittes)
                .then(() => {
                    response.redirect("/add_activtes");
                })

        } else if (formData.action === "delete") {
            activittes.deleteById(editactivittes.id)
                .then(() => {
                    response.redirect("/add_activtes");
                })

        }
    });
});



export default activityController