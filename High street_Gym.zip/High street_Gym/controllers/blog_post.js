import express from "express"
import * as post from "../models/bolg_post.js"
import validator from "validator"
import access_control from "../access_control.js";

const postController = express.Router()



// TODO: Staff admin (CRUD)
postController.get("/Blogviwe", (request, response  ) => {
    const editID = request.query.edit_id

    if (editID) {
        // Case when a specific blog post is selected for editing
        post.getById(editID).then(editblog => {
          post.getAll().then(allblog => {
            response.render("Blog.ejs", {
              allblog,
              editblog,
              role: request.session.user.role,
              userID: request.session.user.userID
            });
          });
        });
      } else {
        // Case when no blog post is selected
        post.getAll().then(allblog => {
          response.render("Blog.ejs", {
            allblog,
            
            role: request.session.user.role,
            userID: request.session.user.userID,
            editblog: post.newPost(0, "", "", "", "", "")
          });
        });
      }
    });
postController.get("/addblog", (request, response) => {
    const editID = request.query.edit_id

    if (editID) {
        // This is the case when a staff member is selected
        post.getById(editID).then(editblog => {
            post.getAll().then(allblog => {
                response.render("addblog.ejs", { allblog, editblog,role: request.session.user.role,userID: request.session.user.userID})
            })
        })
        
    } else {
        // This is the case when no staff member is selected
        post.getAll().then(allblog => {
            response.render("addblog.ejs", { 
                allblog,
                editblog: post.newPost(0, "", "", "", "", ""),
                role: request.session.user.role,
                userID: request.session.user.userID
            })
        })
    }
    postController.post("/edit_blog", (request, response) => {
        const formData = request.body;
        const postId = formData.post_id;
        const userId = request.session.user.userID;
      
        // Validate form data
        if (!/[a-zA-Z]{2,}/.test(formData.title)) {
          response.render("status.ejs", {
            status: "Invalid Title",
            message: "Please enter a valid title."
          });
          return;
        }
      
        if (!/[a-zA-Z]{2,}/.test(formData.content)) {
          response.render("status.ejs", {
              status: "Invalid content",
              message: "Please enter the content  for  e.g  Doing  good fitness will make your day ",
          });
          return;
      }
        // Create staff model from form data
        const editblog= post.newPost(
          validator.escape(formData.post_id),
          new Date().toISOString().slice(0, 19).replace("T", " "),
          validator.escape( formData.user_id),
          validator.escape(formData.title),
          validator.escape(formData.content),
          
          
        )
      
        // Determine and execute the CRUD operation based on the form button pressed
        if (formData.action == "create") {
          post.create(editblog).then(() => {
            response.redirect("/Blogviwe");
          });
        } else if (formData.action == "update") {
          post.getById(postId).then(Post => {
            if (!Post || Post.user_id !== userId) {
              // Unauthorized access to delete the post
              response.render("status.ejs", {
                status: "Unauthorized",
                message: "You are not authorized to  update this post."
              });
              return;
            }
          post.update(editblog).then(() => {
            response.redirect("/Blogviwe");
          
          });
        });
        } else if (formData.action == "delete") {
          // Check if the logged-in user is the creator of the post
          post.getById(postId).then(Post => {
            if (!Post || Post.user_id !== userId) {
              // Unauthorized access to delete the post
              response.render("status.ejs", {
                status: "Unauthorized",
                message: "You are not authorized to delete this post."
              });
              return;
            }
      
            // User is authorized, proceed with deletion
            post.deleteBypostId(postId).then(() => {
              response.redirect("Blogviwe");
            });
          });
        }
      });
    })
        








postController.get("/Blog_backend",access_control(["manager","trainer"]), (request, response) => {
    const editID = request.query.edit_id

    if (editID) {
        // This is the case when a staff member is selected
        post.getById(editID).then(editblog => {
            post.getAll().then(allblog => {
                response.render("Blog_backend.ejs", { allblog, editblog,   role: request.session.user.role,    userID: request.session.user.userID})
            })
        })
        
    } else {
        // This is the case when no staff member is selected
        post.getAll().then(allblog => {
            response.render("Blog_backend.ejs", { 
                allblog,
                role: request.session.user.role,
                userID: request.session.user.userID,
              
                editblog: post.newPost(0, "", "", "", "", "")
            })
        })
    }
  
    postController.post("/edit_blog_backed",access_control(["manager","trainer"]), (request, response) => {
        const formData = request.body
        
        // TODO: Validate form data 
        
        if (!/[a-zA-Z]{2,}/.test(formData.title)) {
            response.render("status.ejs", {
                status: "Invalid Title",
                message: "Please enter the Title for  e.g   Fly High with Gym ",
            });
            return;
        }

        if (!/[a-zA-Z]{2,}/.test(formData.content)) {
          response.render("status.ejs", {
              status: "Invalid content",
              message: "Please enter the content  for  e.g  Doing  good fitness will make you day ",
          });
          return;
      }
        // Create staff model from form data
        const editblog= post.newPost(
          validator.escape(formData.post_id),
          new Date().toISOString().slice(0, 19).replace("T", " "),
          validator.escape( formData.user_id),
          validator.escape(formData.title),
          validator.escape(formData.content),
          
          
        )
        
        // TODO: Hash the password if it is new
        
        // TODO: Determine and execute the C_UD operation based on the form button pressed
        if (formData.action == "create") {
            post.create(editblog).then(() => {
                response.redirect("/Blog_backend")
            })
        } else if (formData.action == "update") {
            post.update(editblog).then(() => {
                response.redirect("/Blog_backend")
            })
        } else if (formData.action == "delete") {
            post.deleteBypostId(editblog.id).then((  ) => {
                
                response.redirect("/Blog_backend")
            })
        }
        
    })
})

//  need to add staff view for Bolg  here 
export default postController;