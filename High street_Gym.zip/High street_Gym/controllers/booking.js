import express from "express"

// import * as booking from "../models/booking_all.js"


import { create, newBooking,  } from "../models/bookings.js"
import * as  activittes from "../models/activties.js";
import access_control from "../access_control.js";

import { Allbooking, getAllBybookingAllid, getAllBybookingsAll, getBySearch, getAllByUserID } from "../models/booking_all.js"

import * as users from "../models/users.js";
import * as newclesses from "../models/class_activity.js"

import * as   getall from "../models/bookings.js"
import validator from "validator";
const bookingController = express.Router()


bookingController.post("/create_booking", (request, response) => {
    // Check that we received form data!


    if (request.body) {
        const formData = request.body


        // TODO: Validate data formats

        // if (!/[a-zA-Z]{2,}/.test(formData.customer_first_name)) {
        //     response.render("status.ejs", {
        //         status: "Invalid First name",
        //         message: "First name must be letters",
        //     });
        //     return;
        // }
        // if (!/[a-zA-Z]{2,}/.test(formData.customer_last_name)) {
        //     response.render("status.ejs", {
        //         status: "Invalid  Last name ",
        //         message: "Enter you last name e.g Tom",
        //     });
        //     return;
        // }

        // if (!/[0-9]{2,}/.test(formData.customer_phone)) {
        //     response.render("status.ejs", {
        //         status: "Invalid  Phone  namber  ",
        //         message: "invalid phone namber please Enter you vaild phone number",
        //     });
        //     return;
        // }

        // if (!/[a-z-0-9-]{6,}/.test(formData.customer_email)) {
        //     response.render("status.ejs", {
        //         status: "Invalid password",
        //         message:
        //             " Enter you emal e.g. sam1@outlook.com ",
        //     });
        //     return;
        // }


        // if (!/[a-z-0-9-]{6,}/.test(formData.customer_address)) {
        //     response.render("status.ejs", {
        //         status: "Invalid address",
        //         message:
        //             "   Enter you  delvery adress  for e. 9 abbotts ccct bellbird parked ",
        //     });
        //     return;
        // }


        // if (!/[0-9]{2,}/.test(formData.customer_pastcode)) {
        //     response.render("status.ejs", {
        //         status: "Invalid Poscode",
        //         message:
        //             "       enter you home postcode for e.g 540  ",
        //     });
        //     return;
        // }
        // if (!/[a-zA-Z]{2,}/.test(formData.customer_city)) {
        //     response.render("status.ejs", {
        //         status: "Invalid  city ",
        //         message: "Enter you  city e.g.Brisbane,Sydney etc",
        //     });
        //     return;

        // }
        console.log(formData)

        // Construct an order
        const bookings = newBooking(
            null,
            Number(formData.user_id),

            formData.Class_id,
            (new Date().toISOString().slice(0, 19).replace("T", " ")),
            formData.activity_id,



        )

        // Save order to database
        create(bookings).then(([result]) => {
            response.redirect("/booking_confirmation?id=" + result.insertId);




            // Send order details
            // response.redirect("payment_s.ejs",{}) 
        }).catch(error => {
            // Handle errors!!!
            response.status(500).send("Failed to create order: " + error)
        })

    } else {
        // Handle errors!!!
        response.status(400).send("missing order details in request body")
    }
})










//  bookig conformation 








bookingController.get("/booking_confirmation", (request, response) => {



    if (request.query.id) {
        getAllBybookingAllid(request.query.id).then(
            Allbooking => {

                response.render("booking_confirmation.ejs", {
                    role: request.session.user.role,
                    Allbooking,
                });
            }
        ).catch(error => {
            response.render("status.ejs", {
                status: "  In vaild  order id",
                message: error,
            })
        })
    }
})





bookingController.get("/bookings_confirmation", (request, response) => {

    // if (!/[1-9]{1,}/.test(request.query.id)) {
    //     response.render("status.ejs", {
    //         status: "Invalid order ID ",
    //         message: "Please contact support on 0405507776.",
    //     });
    //     return;
    // }


    if (request.query.id) {
        getAllBybookingAll(request.query.id).then(
            allAllbooking => {
                response.render("booking_confirmation.ejs", {
                    role: request.session.user.role,
                    allAllbooking,
                });
            }
        ).catch(error => {
            response.render("status.ejs", {
                status: " no booking ",
                message: error,
            })
        })
    }
})


//  customer  edit booking 
bookingController.get("/editbooking", access_control(["members"]), (request, response) => {

    console.log(request.session.user)
    // Get all by user ID
    getAllByUserID(request.session.user.userID)
        .then(allAllbooking => {
            const editID = request.query.edit_id;
            console.log(editID)
            if (editID) {
                getAllBybookingAllid(editID).then(booking => {
                    console.log(booking)
                    response.render("edit_booking.ejs", {
                        allAllbooking,
                        role: request.session.user.role,
                        editAllbooking: booking,
                    })
                })
            } else {
                response.render("edit_booking.ejs", {
                    allAllbooking,
                    role: request.session.user.role,
                    editAllbooking: Allbooking(0, "", "", "", "", "", "", ""),
                })

            }
        }).catch(error => {
            response.render("status.ejs", {
                status: "No Booking is found",
                message: error,

            })
        })
    return;
    getAllByUserID(request.session.user.userID)
        .then(allAllbooking => {
            response.render("edit_booking.ejs", {
                allAllbooking,
                role: request.session.user.role,

                editAllbooking: Allbooking(0, "", "", "", "", "", "", ""),
            })
            return

        })





    const editID = request.query.edit_id;

    if (editID) {
        console.log("editing", editID)
        getAllBybookingsAll(editID)
            .then(allAllbooking => {
                response.render("edit_booking.ejs", {
                    allAllbooking,
                    role: request.session.user.role,


                    editAllbooking: Allbooking(0, "", "", "", "", "", "", ""),
                })
                return;
            })
            .catch(error => {
                // response.send("Error: " + error)
                response.render("status.ejs", {
                    status: "Order not found",
                    message: "You might have provided an invalid order ID"
                })

            }
            )
        // \\\if (editID) {
        //     // Fetch user by ID
        //     getAllBybookingAllid(editID)
        //  .then(editAllbooking => {
        //             // Fetch all users
        //            return getAllBybookingAllid().then(allAllbooking  => {
        //                response.render("edit_booking.ejs", { allAllbooking , editAllbooking,role: request.session.user.role,});
        //             });
        //         })
        //     .catch(error => {
        //            // Handle errors
        //            console.error("Error fetching user by ID:", error);
        //            response.status(500).send("Internal Server Error");
        //         });
    } else (request.query.id)
    getAllBybookingsAll(request.query.id).then(
        allAllbooking => {
            response.render("edit_booking.ejs", {
                role: request.session.user.role,

                allAllbooking,
                editAllbooking: Allbooking(0, "", "", "", "", "", "", ""),
            });
        }
    ).catch(error => {
        response.render("status.ejs", {
            status: "  In vaild  order id",
            message: error,
        })
    })


})





// POST route for editing users
bookingController.post("/edit_booking", access_control(["members"]), (request, response) => {
    const formData = request.body;
    console.log(formData)

    // Extract user_id from form data
    const booking_id = formData.booking_id;

    // Create or update user based on form data
    const editAllbooking = newBooking(


        booking_id,
        formData.user_id,
        formData.Class_id,
        formData.activity_id,
        // formData.booking_created_datetime,
        formData.created_datetime,


    );


    // Determine and execute the CRUD operation based on the form button pressed

    if (formData.action === "create") {
        getall.create(editAllbooking)
            .then(([result]) => {
                response.redirect("/editbooking");
            })

    } else if (formData.action === "update") {
        getall.update(editAllbooking)
            .then(([result]) => {
                response.redirect("/editbooking");
            })

    } else if (formData.action === "delete") {

        getall.deleteById(editAllbooking.id)
            .then(([result]) => {
                response.redirect("/editbooking");
            })

    }
    // response.redirect("/editbooking");
});



bookingController.get("/booking_view", access_control(["manager", "trainer"]), (request, response) => {
    const editID = request.query.edit_id;
    console.log(request.query);

    if (request.query.search_term) {
        getBySearch(request.query.search_term)
            .then(allAllbooking => {
                // Assuming alluser is fetched from somewhere
                users.getAll()
                    .then(alluser => {
                        newclesses. getAllByclassactivties()
                        .then( ClassOnDay => {
                            activittes.getAll()
                            .then(allactivittes => {
                        response.status(200).render("booking_view.ejs", {
                            editAllbooking: Allbooking(0, "", ""),
                            role: request.session.user.role,
                            allAllbooking,
                            alluser,
                            allactivittes,
                            ClassOnDay
                        });
                        });
                    });
                    })
                    .catch(error => {
                        response.status(500).send("Error fetching all users: " + error);
                    });
            })
            .catch(error => {
                response.status(500).send("Error fetching data: " + error);
            });
    } else if (editID) {

        getAllBybookingAllid(editID)
            .then(editAllbooking => {
                getAllBybookingsAll()
                    .then(allAllbooking => {
                        // Assuming alluser is fetched from somewhere
                        console.log(editAllbooking)
                        users.getAll()
                            .then(alluser => {
                                newclesses. getAllByclassactivties()
                                
                                .then( ClassOnDay => {
                                    activittes.getAll()
                                    .then(allactivittes => {
                                response.render("booking_view.ejs", { allAllbooking, editAllbooking, role: request.session.user.role, alluser, ClassOnDay,allactivittes });
                            })
                            .catch(error => {
                                response.status(500).send("Error fetching all users: " + error);
                            });
                        });
                    });
                    })
                    .catch(error => {
                        response.status(500).send("Error fetching data: " + error);
                    });
            })
            .catch(error => {
                response.status(500).send("Error fetching data: " + error);
            });
    } else {
        getAllBybookingsAll()
            .then(allAllbooking => {
                // Assuming alluser is fetched from somewhere
                users.getAll()
                    .then(alluser => {
                        newclesses. getAllByclassactivties()
                        .then( ClassOnDay => { 
                            activittes.getAll()
                            .then(allactivittes => {
                        response.render("booking_view.ejs", {
                            
                            allAllbooking,
                            role: request.session.user.role,
                            editAllbooking: Allbooking(0, "", ""),
                            alluser,
                            ClassOnDay,
                            allactivittes 
                        });
                        });
                    });

                    })
                    .catch(error => {
                        response.status(500).send("Error fetching all users: " + error);
                    });
            })
            .catch(error => {
                response.status(500).send("Error fetching data: " + error);
            });
    }
});


// if (request.query.search_term) {
//         Products.getBySearch(request.query.search_term).then(products => {
//             response.render("product_list.ejs", { products });
//         });
//     } else {
//         Products.getAll().then(products => {
//             response.render("product_list.ejs", { products });
//         });
//     }
// });


//  satff view 
// POST route for editing users
bookingController.post("/mangement_booking", access_control(["manager", "trainer"]), (request, response) => {
    const formData = request.body;
    console.log(formData)
    // Extract user_id from form data
    const booking_id = formData.booking_id;

    // Create or update Clesses based on form data
    const editAllbooking = newBooking(
        validator.escape(booking_id),
        validator.escape(formData.user_id),
        validator.escape(formData.Class_id),
        new Date(formData.created_datetime),
        validator.escape(formData.activity_id),





    );

    // Determine and execute the CRUD operation based on the form button pressed
    console.log('before model', editAllbooking)


    if (formData.action === "create") {
        getall.create(editAllbooking)
            .then(([result]) => {
                response.redirect("/booking_view");
            })

    } else if (formData.action === "update") {
        getall.update(editAllbooking)

            .then(([result]) => {
                console.log(result)

                response.redirect("/booking_view");
            })


    } else if (formData.action === "delete") {

        getall.deleteById(editAllbooking.id)
            .then(([result]) => {
                console.log(result)
                response.redirect("/booking_view");
            })


    }
});


export default bookingController;
