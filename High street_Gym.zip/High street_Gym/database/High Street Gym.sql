-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: high street gym
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activities`
--

DROP TABLE IF EXISTS `activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activities` (
  `activity_id` int NOT NULL AUTO_INCREMENT,
  `activity_name` varchar(45) NOT NULL,
  `activity_description` varchar(1000) NOT NULL,
  `activity_duration` varchar(45) NOT NULL,
  PRIMARY KEY (`activity_id`),
  UNIQUE KEY `activity_id_UNIQUE` (`activity_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activities`
--

LOCK TABLES `activities` WRITE;
/*!40000 ALTER TABLE `activities` DISABLE KEYS */;
INSERT INTO `activities` VALUES (2,'yoga','yoga  is an art and scince of healthy living. The word \'Yoga\' is derived from the Sanskrit root \'Yuj\', meaning \'to join\' or \'to yoke\' or \'to unite\'','30 to 45 minutes'),(7,'Pilates','Pilates uses a combination of approximately 50 simple, repetitive exercises to create muscular exertion','45 minutes to an hour'),(8,' Abs','Abdominal exercises are a type of strength exercise that affect the abdominal muscles','5 to 30 minutes '),(9,'HIIT or High-intensity Interval Training ','A training protocol alternating short periods of intense or explosive anaerobic exercise with brief recovery periods until the point of exhaustion.','30-60 minutes'),(10,' indoor cycling ','Indoor cycling is any type of indoor exercise that focuses on rotating pedals in circles','30-60 minutes daily '),(11,' Boxing ','Boxing is a sport that involves strategically punching an opponent while defending yourself from their return punches.','3 minutes for men, 2 minutes for women.'),(12,'Zumba','Zumba is an interval workout. The classes move between high- and low-intensity dance moves designed to get your heart rate up and boost cardio endurance.','1 Hour');
/*!40000 ALTER TABLE `activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bolg_post`
--

DROP TABLE IF EXISTS `bolg_post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bolg_post` (
  `post_id` int NOT NULL AUTO_INCREMENT,
  `post_datetime` datetime NOT NULL,
  `post_user_id` int NOT NULL,
  `post_title` varchar(45) NOT NULL,
  `post_content` varchar(100) NOT NULL,
  PRIMARY KEY (`post_id`),
  UNIQUE KEY `post_id_UNIQUE` (`post_id`),
  KEY `user_bolg_post_fk_idx` (`post_user_id`),
  CONSTRAINT `user_bolg_post_fk` FOREIGN KEY (`post_user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=81 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bolg_post`
--

LOCK TABLES `bolg_post` WRITE;
/*!40000 ALTER TABLE `bolg_post` DISABLE KEYS */;
INSERT INTO `bolg_post` VALUES (77,'2024-05-08 09:07:11',81,' Having  good food ',' when we have good food  our body is healthy '),(78,'2024-05-08 09:10:08',15,' gym every day ',' when you do  you work out  every day  your body  will be  fit '),(79,'2024-05-08 10:41:22',81,'Fly High with Gym',' in joy  gym  every time ');
/*!40000 ALTER TABLE `bolg_post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bookings`
--

DROP TABLE IF EXISTS `bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bookings` (
  `booking_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `Class_id` int NOT NULL,
  `booking_created_datetime` datetime DEFAULT CURRENT_TIMESTAMP,
  `activity_id` int NOT NULL,
  PRIMARY KEY (`booking_id`),
  UNIQUE KEY `booking_id_UNIQUE` (`booking_id`),
  KEY `users_bookings_fk_idx` (`user_id`),
  KEY `classes_booking_id_idx` (`Class_id`),
  KEY `activities_bookings_fk_idx` (`activity_id`),
  CONSTRAINT `activities_bookings_fk` FOREIGN KEY (`activity_id`) REFERENCES `activities` (`activity_id`),
  CONSTRAINT `classes_bookings_id` FOREIGN KEY (`Class_id`) REFERENCES `classes` (`Class_id`),
  CONSTRAINT `users_bookings_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=186 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookings`
--

LOCK TABLES `bookings` WRITE;
/*!40000 ALTER TABLE `bookings` DISABLE KEYS */;
INSERT INTO `bookings` VALUES (166,97,61,'2024-05-07 18:05:47',11),(177,97,66,'2024-05-09 17:01:45',8),(178,81,66,'2024-05-09 17:03:09',8),(180,81,58,'2024-05-09 17:55:02',11),(181,98,62,'2024-05-09 19:49:58',2),(182,81,59,'2024-05-10 14:12:15',2),(183,81,60,'2024-05-10 14:40:41',12),(184,81,59,'2024-05-10 15:31:13',2),(185,81,66,'2024-05-10 15:36:08',8);
/*!40000 ALTER TABLE `bookings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `classes`
--

DROP TABLE IF EXISTS `classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `classes` (
  `Class_id` int NOT NULL AUTO_INCREMENT,
  `Class_datetime` varchar(45) NOT NULL,
  `location_id` int NOT NULL,
  `activity_id` int NOT NULL,
  `trainer_user_id` int NOT NULL,
  `Class_removed` tinyint NOT NULL DEFAULT '0',
  PRIMARY KEY (`Class_id`),
  UNIQUE KEY `class_id_UNIQUE` (`Class_id`),
  KEY `location_classes_fk_idx` (`location_id`),
  KEY `activity_classes_fk_idx` (`activity_id`),
  KEY `users_classes_fk_idx` (`trainer_user_id`),
  CONSTRAINT `activity_classes_fk` FOREIGN KEY (`activity_id`) REFERENCES `activities` (`activity_id`),
  CONSTRAINT `location_classes_fk` FOREIGN KEY (`location_id`) REFERENCES `location` (`location_id`),
  CONSTRAINT `users_classes_fk` FOREIGN KEY (`trainer_user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=67 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `classes`
--

LOCK TABLES `classes` WRITE;
/*!40000 ALTER TABLE `classes` DISABLE KEYS */;
INSERT INTO `classes` VALUES (5,'2024-05-07T10:00',2,2,15,1),(36,'2024-03-23 10:20:00',2,2,15,1),(55,'2024-05-01T10:00',2,2,79,0),(57,'2024-05-03T18:00',2,10,57,0),(58,'2024-05-10T10:00',2,11,15,0),(59,'2024-05-06T16:00',2,2,57,0),(60,'2024-05-06T09:00',2,12,78,0),(61,'2024-05-10T12:00',2,11,57,0),(62,'2024-05-11T09:00',2,2,15,0),(63,'2024-05-08T10:00',2,7,57,1),(64,'2024-05-08T10:59',2,10,79,0),(65,'2024-05-10T10:00',2,7,15,0),(66,'2024-05-10T19:30',2,8,63,0);
/*!40000 ALTER TABLE `classes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location`
--

DROP TABLE IF EXISTS `location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `location` (
  `location_id` int NOT NULL AUTO_INCREMENT,
  `location_name` varchar(45) NOT NULL,
  PRIMARY KEY (`location_id`),
  UNIQUE KEY `location_id_UNIQUE` (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=96 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location`
--

LOCK TABLES `location` WRITE;
/*!40000 ALTER TABLE `location` DISABLE KEYS */;
INSERT INTO `location` VALUES (2,'South Brisbane ');
/*!40000 ALTER TABLE `location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `user_email` varchar(45) NOT NULL,
  `user_password` varchar(100) NOT NULL,
  `user_role` enum('manager','trainer','members') NOT NULL,
  `user_phone` varchar(45) NOT NULL,
  `user_first_name` varchar(45) NOT NULL,
  `user_last_name` varchar(45) NOT NULL,
  `user_address` varchar(45) NOT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `users_id_UNIQUE` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=99 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (15,'mayurbhagat@outlook.com','$2a$10$5MgocQ0R3EkzfNmsM9/9YOv3fpFPsU4LZiGbPPMliT/5tC/MG4aaK','manager','03847834','mayur','bhaget','17 dan rood '),(57,'toem@ outlookinc ','144','trainer','0405506601','mayur h','bahgs',' tham to and 24'),(62,'mayurbhagat1@outlook.com ','$2a$10$YPPoD756NBWEcTLCRmaAEuT2s8MLqlIe7GwmIT2oCpQDVXrHzHBo6','members','0490942246','mayur','BHAGAT','6'),(63,'mayurbhagat1@outlook.com ','222','trainer','0490942246','dom','hq','6'),(77,'mayurbhagat1@outlook.com ','$2a$10$gN2KnPQmjcjMgtrFX0E/ZO2yyTEKidSk7YCDA1D3DvLekTc3l2F6O','members','0490942246','test','test','6'),(78,'manager.@outlook.com.au','$2a$10$Z0F/s7L0kXRi13GO5QWsxeU.1zAx9qq3vKrJML8vg9Q7MAj78DuU2','manager','0490942246','manger','manager','6'),(79,'tom@outlook.com','$2a$10$SzW7oLaXPwzwjim4kwBGNOXpHM8G3ZGQdIBiaoJTO/2tNmU9Qh35.','trainer','0401155623','pan','HPsrt','6 ABBOT CIRCUIT'),(81,'123@outlook.com','$2a$10$IJbMwSYbhk5/tRNNFi0s1.ODWKDX.XAk6n/k/4zQFJ6MokAb63asG','members','04587845168','Tome','mbers','testing'),(96,'sam@yahoo.com','$2a$10$xwWCh4pE2qBsHabN2iQq9Ob16vh6jJMwUKnSllVKJTj1ugCpIgYOm','trainer','0412548789','Same ','  gan ',' 14 Brisbane rock'),(97,'jack@yahoo.com','$2a$10$4ke7zcliJz5e.3MbVVAmk.K02GI4LCkdotMSVHWIqkmacMoHzx.mW','members','04055088074','jack','pan ','14 Australian Queensland Street'),(98,'Tgon@tgon.com.au','$2a$10$bBjfQX5TkZVb.86enJ0sweiOGLttGRU5O6uHhRGaLiyRqhjM4I9lO','members','04055022031',' Tgon','hqplot','16 computer Brisbane RD');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-05-10 16:03:55
