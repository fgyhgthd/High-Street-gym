import { db_conn } from "../database.js"
export function Allbooking(
    booking_id,
    user_id,
    Class_id,
    booking_created_datetime,
    Class_datetime,
    class_location_id,
    activity_id,
    activity_name,
    activity_description,
    activity_duration,
    // location_name,
    class_trainer_user_id,
    user_email,
    user_password,
    user_role,
    user_phone,
    user_first_name,
    user_last_name,
    user_address,
) {
    return {
        booking_id,
        user_id,
        Class_id,
        booking_created_datetime,
        Class_datetime,
        class_location_id,
        activity_id,
        activity_name,
        activity_description,
        activity_duration,
        // location_name,
        class_trainer_user_id,
        user_email,
        user_password,
        user_role,
        user_phone,
        user_first_name,
        user_last_name,
        user_address,




    }
}


export function getAllBybookingsAll() {
    return db_conn.query(
        `
        SELECT * FROM bookings
        INNER JOIN classes ON bookings.Class_id = classes.Class_id
        INNER JOIN users ON bookings.user_id = users.user_id
        INNER JOIN activities ON bookings.activity_id = activities.activity_id


   

        `,
    ).then(([queryResult]) => {
        // convert each result into a model object
        return queryResult.map(result => Allbooking(
            result.booking_id,
            result.user_id,
            result.Class_id,
            result.booking_created_datetime,
            result.Class_datetime,
            result.class_location_id,
            result.activity_id,
            result.activity_name,
            result.activity_description,
            result.activity_duration,
            // result.location_name,
            result.class_trainer_user_id,
            result.user_email,
            result.user_password,
            result.user_role,
            result.user_phone,
            result.user_first_name,
            result.user_last_name,
            result.user_address,

        ));

    });
}

export function getAllBybookingAllid(bookingAllid) {

    return db_conn.query(
        `
        SELECT * FROM bookings
        INNER JOIN classes ON bookings.Class_id = classes.Class_id
        INNER JOIN users ON bookings.user_id = users.user_id
        INNER JOIN activities ON bookings.activity_id = activities.activity_id


        WHERE bookings.booking_id = ?
        `,
        [bookingAllid]
    ).then(([queryResult]) => {
        // check that at least 1 match was found
        if (queryResult.length > 0) {
            // get the first matching result
            const result = queryResult[0];

            // convert result into a model object
            return Allbooking(
                result.booking_id,
                result.user_id,
                result.Class_id,
                result.booking_created_datetime,
                result.Class_datetime,
                result.class_location_id,
                result.activity_id,
                result.activity_name,
                result.activity_description,
                result.activity_duration,
                // result.location_name,
                result.class_trainer_user_id,
                result.user_email,
                result.user_password,
                result.user_role,
                result.user_phone,
                result.user_first_name,
                result.user_last_name,
                result.user_address,
            );

        } else {

            return Promise.reject("no matching results");
        }
    });
}


export function getAllBybookingsUsers() {
    return db_conn.query(
        `
        SELECT * FROM bookings
        INNER JOIN classes ON bookings.Class_id = classes.Class_id
        INNER JOIN users ON bookings.user_id = users.user_id
        INNER JOIN activities ON bookings.activity_id = activities.activity_id


        WHERE bookings.user_id

        `,
    ).then(([queryResult]) => {
        // convert each result into a model object
        return queryResult.map(result => Allbooking(
            result.booking_id,
            result.user_id,
            result.Class_id,
            result.booking_created_datetime,
            result.Class_datetime,
            result.class_location_id,
            result.activity_id,
            result.activity_name,
            result.activity_description,
            result.activity_duration,
            // result.location_name,
            result.class_trainer_user_id,
            result.user_email,
            result.user_password,
            result.user_role,
            result.user_phone,
            result.user_first_name,
            result.user_last_name,
            result.user_address,

        ));

    });
}



export function getBySearch(searchTerm) {
    const query = `
        SELECT * FROM bookings
        INNER JOIN classes ON bookings.Class_id = classes.Class_id
        INNER JOIN users ON bookings.user_id = users.user_id
        INNER JOIN activities ON bookings.activity_id = activities.activity_id


        WHERE users.user_first_name LIKE ?
    `;

    return db_conn.query(query, [`%${searchTerm}%`]).then(([queryResult]) => {
        // Assuming Allbooking is a class constructor for booking objects
        return queryResult.map(result => new Allbooking(
            result.booking_id,
            result.user_id,
            result.Class_id,
            result.booking_created_datetime,
            result.Class_datetime,
            result.class_location_id,
            result.activity_id,
            result.activity_name,
            result.activity_description,
            result.activity_duration,
            result.class_trainer_user_id,
            result.user_email,
            result.user_password,
            result.user_role,
            result.user_phone,
            result.user_first_name,
            result.user_last_name,
            result.user_address
        ));
    });
}




export function getAllByUserID(UserID) {

    return db_conn.query(
        `
        SELECT * FROM bookings
        INNER JOIN classes ON bookings.Class_id = classes.Class_id
        INNER JOIN users ON bookings.user_id = users.user_id
        INNER JOIN activities ON bookings.activity_id = activities.activity_id

        WHERE bookings.user_id = ?
        `,
        [UserID]
    ).then(([queryResult]) => {
        // check that at least 1 match was found
        if (queryResult.length > 0) {
            // get the first matching result


            // convert result into a model object
            return queryResult.map(
                result => Allbooking(
                    result.booking_id,
                    result.user_id,
                    result.Class_id,
                    result.booking_created_datetime,
                    result.Class_datetime,
                    result.class_location_id,
                    result.activity_id,
                    result.activity_name,
                    result.activity_description,
                    result.activity_duration,
                    // result.location_name,
                    result.class_trainer_user_id,
                    result.user_email,
                    result.user_password,
                    result.user_role,
                    result.user_phone,
                    result.user_first_name,
                    result.user_last_name,
                    result.user_address,
                )
            )


        } else {

            return Promise.reject("no matching results");
        }
    });

}



