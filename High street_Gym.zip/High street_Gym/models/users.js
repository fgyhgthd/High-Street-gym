import { db_conn } from "../database.js"
export function newUser(
    id,
    email,
    password,
    role,
    phone,
    first_name,
    last_name,
    address,

) {
    return {
        id,
        email,
        password,
        role,
        phone,
        first_name,
        last_name,
        address,
    }
}



// Create
export function create(user) {
    return db_conn.query(`
    INSERT INTO users
    (user_email, user_password, user_role, user_phone, user_first_name, user_last_name, user_address)
    VALUES (?, ?, ?, ?, ?, ?, ?)
    `, [

        user.email,
        user.password,
        user.role,
        user.phone,
        user.first_name,
        user.last_name,
        user.address,





    ])
}
// Testing Area (Remove before use!) 

//    const user1 = newUsers(null, "Jess3@outlok.com ", "123", "members", "040550440","to","bhagat","123bne")
//     create(user1)

// Read
export function getAll() {
    return db_conn.query("SELECT * FROM users")
        .then((([queryResult]) => {
            return queryResult.map(
                result => newUser(
                    result.user_id,
                    result.user_email,
                    result.user_password,
                    result.user_role,
                    result.user_phone,
                    result.user_first_name,
                    result.user_last_name,
                    result.user_address,
                )
            )
        }))
}
export function getById(userid) {
    return db_conn.query("SELECT * FROM users WHERE user_id = ?", [userid])
        .then(([queryResult]) => {
            // check that at least 1 match was found
            if (queryResult.length > 0) {
                const result = queryResult[0]

                // Convert the result into a staff model object
                return newUser(
                    result.user_id,
                    result.user_email,
                    result.user_password,
                    result.user_role,
                    result.user_phone,
                    result.user_first_name,
                    result.user_last_name,
                    result.user_address,
                )
            } else {
                return Promise.reject("no matching results")
            }
        })
}



export function getByemail(email) {
    return db_conn.query(`SELECT * FROM users WHERE user_email = ?`, [email])
        .then(([queryResult]) => {
            // check that at least 1 match was found
            if (queryResult.length > 0) {
                // get the first matching result
                const result = queryResult[0]

                // convert result into a model object
                return newUser(
                    result.user_id,
                    result.user_email,
                    result.user_password,
                    result.user_role,
                    result.user_phone,
                    result.user_first_name,
                    result.user_last_name,
                    result.user_address,
                )
            } else {
                return Promise.reject("no matching results")
            }
        })
}

/////////////////////////// Testing Area (Remove before use!) ////////////
//   getAll().then(newUser => {
//      console.log(newUser)
//   })

//////////////////////////////////////////////////////////////////////////


// Update
export function update(user) {
    return db_conn.query(`
     UPDATE users SET 
     user_email =?,
     user_password=?,
     user_role =?,
     user_phone = ?,
     user_first_name = ?,
     user_last_name = ?,
     user_address = ?

     WHERE user_id = ?
     `, [
        user.email,
        user.password,
        user.role,
        user.phone,
        user.first_name,
        user.last_name,
        user.address,
        user.id,
    ])
}
/////////////////////////// Testing Area (Remove before use!) ////////////

//   const user1 = newUsers(1, "Jess@outlok.com ", "123569", "manger", "040550440","mayur","bhagat","123bne")

//   update(user1)

//////////////////////////////////////////////////////////////////////////


// Delete
export function deleteById(edituser) {
    return db_conn.query("DELETE FROM users WHERE user_id = ?", [edituser])
}
////////////////////////// Testing Area (Remove before use!) ////////////

// deleteById(3).then(() => console.log("Delete operation completed!"))

//////////////////////////////////////////////////////////////////////////