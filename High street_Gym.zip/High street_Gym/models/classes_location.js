import { db_conn } from "../database.js"

export function classesloctaion(
    class_id,
    class_datetime,
    location_id,
    class_activity_id,
    class_trainer_user_id,

    location_name

) {
    return {
        class_id,
        class_datetime,
        location_id,
        class_activity_id,
        class_trainer_user_id,

        location_name

    }
}





export function getAllByclass() {
    return db_conn.query(
        `
        SELECT * FROM classes
        INNER JOIN location
        ON classes.location_id = location.location_id 
    `
    ).then(([queryResult]) => {
        // convert each result into a model object
        return queryResult.map(
            result => classesloctaion(
                result.class_id,
                result.class_datetime,
                result.location_id,
                result.class_activity_id,
                result.class_trainer_user_id,
                result.location_name
            )
        )
    })
}

export function getAllByclassLid(classID) {
    return db_conn.query(
        `
        SELECT * FROM classes
        INNER JOIN location
        ON classes.location_id = location.location_id 
        WHERE classes.class_id = ?
    `,
        [classID]
    ).then(([queryResult]) => {
        // check that at least 1 match was found
        if (queryResult.length > 0) {
            // get the first matching result
            const result = queryResult[0]

            // convert result into a model object
            return classesloctaion(
                result.class_id,
                result.class_datetime,
                result.location_id,
                result.class_activity_id,
                result.class_trainer_user_id,
                result.location_name
            )

        } else {
            return Promise.reject("no matching results")
        }
    })
}