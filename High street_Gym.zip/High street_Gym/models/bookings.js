import { db_conn } from "../database.js"
export function newBooking(
    id,
    user_id,

    Class_id,
    created_datetime,
    activity_id


) {
    return {
        id,
        user_id,

        Class_id,
        created_datetime,
        activity_id

    }
}


export function create(booking) {
    // console.log(bookings)
    return db_conn.query(`
    INSERT INTO bookings 
    ( user_id,  Class_id,activity_id)
    VALUES (?, ?,  ?)
    `, [


        booking.user_id,

        booking.Class_id,
        booking.activity_id







    ])
}


// Testing Area (Remove before use!) 
//     const booking = newBooking(null, "15","5","2024-12-03 00:00:00",2)
//    create(booking)
//  read
export function getAll() {
    return db_conn.query("SELECT * FROM  bookings")
        .then((([queryResult]) => {
            return queryResult.map(
                result => newBooking(
                    result.booking_id,
                    result.user_id,
                    result.Class_id,
                    result.booking_created_datetime,
                    result.activity_id




                )
            )
        }))
}


// need to add getallByid 

// export function getAllByUserID(UserID) {
//     return db_conn.query("SELECT * FROM  bookings where bookings.user_id = ?",[UserID])
//         .then((([queryResult]) => {
//             return queryResult.map(
//                 result => newBooking(
//                     result.booking_id,
//                     result.user_id,
//                     result. Class_id,
//                     result.booking_created_datetime,
//                     // result.activity_id




//                 )
//             )
//         }))
// }



//   need to add  getallbyID here 



//  test

//  getAll().then(newBooking => {
//    console.log(newBooking)
//    })

//////////////////////////////////////////////////////////////////////////




// update


export function update(booking) {
    console.log(booking)
    return db_conn.query(`
     UPDATE bookings SET 
     user_id = ?,
     Class_id = ?,
     booking_created_datetime = ?,
     activity_id = ?
     WHERE booking_id = ?
     `, [
        booking.user_id,
        booking.Class_id,
        booking.created_datetime,
        booking.activity_id,
        booking.id,
    ])
}
/////////////////////////// Testing Area (Remove before use!) ////////////
//   const booking = newBooking(149, "81","55","2024-05-03 07:02:30",9)

//    update(booking)

//////////////////////////////////////////////////////////////////////////

// Delete


export function deleteById(booking) {
    return db_conn.query("DELETE FROM bookings WHERE booking_id=?", [booking])
}
// ////////////////////////// Testing Area (Remove before use!) ////////////

//    deleteById(150).then(() => console.log("Delete operation completed!"))

//////////////////////////////////////////////////////////////////////////