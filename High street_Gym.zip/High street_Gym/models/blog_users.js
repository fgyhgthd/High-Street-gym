import { db_conn } from "../database.js"
export function blogusers(
    post_id,
    post_datetime,
    user_id,
    post_title,
    posst_content,
    user_email,
    user_password,
    user_role,
    user_phone,
    user_first_name,
    user_last_name,
    user_address,
) {
    return {
        post_id,
        post_datetime,
        user_id,
        post_title,
        posst_content,
        user_email,
        user_password,
        user_role,
        user_phone,
        user_first_name,
        user_last_name,
        user_address,
    }
}

export function getAllByBlog() {
    return db_conn.query(
        `
        SELECT * FROM blog_post
        INNER JOIN users
        ON post.user_id = user_id 
        
    `,

    ).then(([queryResult]) => {
        // convert each result into a model object
        return queryResult.map(
            result => blogusers(

                result.post_id,
                result.post_datetime,
                result.user_id,
                result.post_title,
                result.post_content,
                result.user_email,
                result.user_password,
                result.user_role,
                result.user_phone,
                result.user_first_name,
                result.user_last_name,
                result.user_address,
            )
        )

    })
}
export function getAllBypostid(post) {
    return db_conn.query(
        `
        SELECT * FROM blog_post
        INNER JOIN users
        ON post.user_id = user_id 
         where blog_post.post_id =?
    `,
        [postid]
    ).then(([queryResult]) => {
        // check that at least 1 match was found
        if (queryResult.length > 0) {
            // get the first matching result
            const result = queryResult[0]

            // convert result into a model object
            return blogusers(

                result.post_id,
                result.post_datetime,
                result.post_user_id,
                result.post_title,
                result.post_content,
                result.user_email,
                result.user_password,
                result.user_role,
                result.user_phone,
                result.user_first_name,
                result.user_last_name,
                result.user_address,
            )

        } else {
            return Promise.reject("no matching results")
        }

    })
}