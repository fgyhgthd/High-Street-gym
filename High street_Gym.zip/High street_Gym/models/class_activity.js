import { db_conn } from "../database.js"
export function classesactivity(
    Class_id,
    Class_datetime,
   lacation_id,
   location_name,
  activity_id,
  activity_name,
   activity_description,
   activity_duration,
 

    trainer_user_id,

    
    user_email,
    user_password,
    user_role,
    user_phone,
    user_first_name,
    user_last_name,
    user_address,






 
) {
    return {
       Class_id,
    Class_datetime,
   lacation_id,

    trainer_user_id,
    
    activity_id,
    activity_name,
    activity_description,
    activity_duration, 
    location_name,
    user_email,
    user_password,
    user_role,
    user_phone,
    user_first_name,
    user_last_name,
    user_address,



    }
}


export function getAllByclassactivties() {
    return db_conn.query(
        `
        SELECT * FROM classes
        INNER JOIN activities ON classes.activity_id = activities.activity_id
        INNER JOIN location ON classes.location_id = location.location_id
        INNER JOIN users ON classes.trainer_user_id = users.user_id
        `
    ).then(([queryResult]) => {
        // convert each result into a model object
        return queryResult.map(result => classesactivity(
            result.Class_id,
            result.Class_datetime,
            result.location_id,
            result.location_name,
            result.activity_id,
            result.activity_name,
            result.activity_description,
            result.activity_duration, 
            result.trainer_user_id,
           
            result.user_email,
            result.user_password,
            result.user_role,
            result.user_phone,
            result.user_first_name,
            result.user_last_name,
            result.user_address,
        
        ));
        
    });
}
    
export function getAllByclassid(clesses) {
    console.log("Searching for Class_id:",clesses);
    return db_conn.query(
        `
        SELECT * FROM classes
        INNER JOIN activities ON classes.activity_id = activities.activity_id
        INNER JOIN location ON classes.location_id = location.location_id
        INNER JOIN users ON classes.trainer_user_id = users.user_id
        WHERE classes.Class_id = ?
        `,
        [clesses]
    ).then(([queryResult]) => {
        // check that at least 1 match was found
        if (queryResult.length > 0) {
            // get the first matching result
            const result = queryResult[0];
            console.log(result)
            // convert result into a model object
            return classesactivity(
                result.Class_id,
                result.Class_datetime,
                result.location_id,
                result.location_name,
                result.activity_id,
                result.activity_name,
                result.activity_description,
                result.activity_duration, 
                result.trainer_user_id,
                result.user_email,
                result.user_password,
                result.user_role,
                result.user_phone,
                result.user_first_name,
                result.user_last_name,
                result.user_address,
            
            );

        } else {
            console.log("No matching results found for Class_id:", clesses);
            return Promise.reject("no matching results");
        }
    });
}
// export function getBySearchClass(searchTerm) {
//     return db_conn.query(
//         "SELECT * FROM classes WHERE Class_removed = 0 AND (  trainer_user_id = ?)",
//         [`%${searchTerm}%`]
//     ).then(([queryResult]) => {
//         // convert each result into a model object
//         return queryResult.map(
//             result =>  classesactivity(
//                 result.Class_id,
//                 result.Class_datetime,
//                 result.location_id,
//                 result.trainer_user_id,
//                 result.activity_id,
//                 result.activity_name,
//                 result.activity_description,
//                 result.activity_duration, 
//                 result.location_name,
//                 result.   user_id,
//                 result.user_email,
//                 result.user_password,
//                 result.user_role,
//                 result.user_phone,
//                 result. user_first_name,
//                 result.user_last_name,
//                 result.user_address,
            
//             )
//         )

//     })
// }
export function getBySearchClass(searchTerm) {
  return db_conn.query(
      `
      SELECT * FROM classes
      INNER JOIN activities ON classes.activity_id = activities.activity_id
      INNER JOIN location ON classes.location_id = location.location_id
      INNER JOIN users ON classes.trainer_user_id = users.user_id
      WHERE classes.Class_removed = 0 
        AND (users.user_first_name = ? OR classes.Class_datetime = ?)
      `,
      [searchTerm, searchTerm] // Assuming searchTerm can represent both user_id and Class_datetime
  ).then(([queryResult]) => {
      // convert each result into a model object
      return queryResult.map(result => new classesactivity(
          result.Class_id,
          result.Class_datetime,
          result.location_id,
          result.location_name,
          result.activity_id,
          result.activity_name,
          result.activity_description,
          result.activity_duration,
          result.trainer_user_id,
          result.user_email,
          result.user_password,
          result.user_role,
          result.user_phone,
          result.user_first_name,
          result.user_last_name,
          result.user_address
      ));
  });
}


export function getAllByclassDate(startDate, endDate) {
    return db_conn.query(
      `
      SELECT * FROM classes
      INNER JOIN activities ON classes.activity_id = activities.activity_id
      INNER JOIN location ON classes.location_id = location.location_id
      INNER JOIN users ON classes.trainer_user_id = users.user_id
      WHERE classes.Class_datetime BETWEEN ? AND ? AND Class_removed = 0
      `,
      [startDate, endDate]
    ).then(([queryResult]) => {
      if (queryResult.length > 0) {
        // Convert each row into a model object
        const classActivities = queryResult.map(result => {
          return new classesactivity(
            result.Class_id,
            result.Class_datetime,
            result.location_id,
            result.location_name,
            result.activity_id,
            result.activity_name,
            result.activity_description,
            result.activity_duration,
            result.trainer_user_id,
            result.user_email,
            result.user_password,
            result.user_role,
            result.user_phone,
            result.user_first_name,
            result.user_last_name,
            result.user_address
          );
        });
        return classActivities; // Return array of model objects
      } else {
        console.log("No matching results found for the given date range.");
        return []; // Return empty array if no results
      }
    }).catch(error => {
      console.error("Error fetching classes by date:", error);
      throw error; // Propagate the error
    });
  }