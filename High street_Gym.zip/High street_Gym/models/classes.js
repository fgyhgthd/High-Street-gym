import { db_conn } from "../database.js"
export function newClasses(
    id,
    datetime,
    location_id,
    activity_id,
    trainer_user_id,
   

) {
    return {
        id,
        datetime,
        location_id,
        activity_id,
        trainer_user_id,
    }
}
// Create
export function create(Class) {
    return db_conn.query(`
    INSERT INTO classes
 (   
Class_datetime,  location_id, activity_id,trainer_user_id) 
    VALUES (?, ?, ?, ?)

    `, [


        Class.datetime,
        Class.location_id,
        Class.activity_id,
        Class.trainer_user_id
      


    ])
}
// Testing Area (Remove before use!) 
//    const classes1 = newClasses(null, "2024-012-03 00:00:00", "2", "2", "15")
//   create(classes1)

// Read
export function getAll() {
    return db_conn.query("SELECT * FROM classes WHERE  Class_removed")
        .then((([queryResult]) => {
            return queryResult.map(
                result =>  newClasses(
                    result.Class_id,
                    result.Class_datetime,
                    result.location_id,
                    result.activity_id,
                    result.trainer_user_id,
                   

            
                )
            )
        }))
}


export function getById(classid) {
    return db_conn.query("SELECT * FROM classes WHERE Class_id = ?", [classid])
        .then(([queryResult]) => {
            // check that at least 1 match was found
            if (queryResult.length > 0) {
                const result = queryResult[0]

                // Convert the result into a staff model object
                return  newClasses(
                    result.Class_id,
                    result.Class_datetime,
                    result.location_id,
                    result.activity_id,
                    result.trainer_user_id,
                   
                )
            } else {
                return Promise.reject("no matching results")
            }
        })}






// export function getBySearchClassD(searchTerm) {
//     return db_conn.query(
//         "SELECT * FROM classes WHERE Class_removed = 0 AND (Class_datetime = ?)",
//         [searchTerm]
//     ).then(([queryResult]) => {
//         // convert each result into a model object
//         return queryResult.map(
//             result => newClasses(
//                 result.Class_id,
//                 result.Class_datetime,
//                 result.location_id,
//                 result.activity_id,
//                 result.trainer_user_id
//             )
//         )

//     })
// }

// export function getBySearchClass(searchTerm) {
  
//     return db_conn.query(
//         "SELECT * FROM classes WHERE Class_removed = 0 AND (  trainer_user_id = ? or Class_datetime = ?  )",
//         [searchTerm]
//     ).then(([queryResult]) => {
//         // convert each result into a model object
//         return queryResult.map(
//             result => newClasses(
//                 result.Class_id,
//                 result.Class_datetime,
//                 result.location_id,
//                 result.activity_id,
//                 result.trainer_user_id
//             )
//         )

//     })
// }



/////////////////////////// Testing Area (Remove before use!) ////////////
        
        //  getAll().then(newClasses => {
        //   console.log(newClasses)
        //    })
        
        //////////////////////////////////////////////////////////////////////////

        // Update
export function update(Class) {
    return db_conn.query(`
                UPDATE classes 
                SET 
                    Class_datetime = ?,
                    location_id = ?,
                    activity_id = ?,
                    trainer_user_id = ?
                WHERE 
                    Class_id = ?
            `, [
        Class.datetime,
        Class.location_id,
        Class.activity_id,
        Class.trainer_user_id,
        Class.id
    ])
}
/////////////////////////// Testing Area (Remove before use!) ////////////

//    const Class =  newClasses(5, "2024-15-03 100:00:00", "2", "2", "15")

//    update(Class)

//////////////////////////////////////////////////////////////////////////
// export function deleteById(classId) {
//     return db_conn.query(`
//     UPDATE classes
//     SET Class_removed = 1
//     WHEREClass_id = ?
//     `, [classId])

// }
export function deleteById(Class) {
    return db_conn.query(
        "UPDATE classes SET Class_removed = 1 WHERE Class_id = ?",
        [Class]
    )
}



////////////////////////// Testing Area (Remove before use!) ////////////
//    deleteById(41).then(() => console.log("Delete operation completed!"))

//////////////////////////////////////////////////////////////////////////


