import { db_conn } from "../database.js"
export function newActivities(
    id,
  name,
  description,
   duration,

) {
    return {
        id,
        name,
        description,
        duration,
       
    }
}

export function create(activity) {
    return db_conn.query(`
    INSERT INTO activities
    ( activity_name, activity_description, activity_duration)
    VALUES (?, ?, ?)
    `, [

        activity.name,
        activity.description,
        activity.duration,






    ])}
    // Testing Area (Remove before use!) 
//   const activity1 = newActivities(null, "tom", "mayur","13")
//    create(activity1)

  // Read
export function getAll() {
    return db_conn.query("SELECT * FROM activities")
        .then((([queryResult]) => {
            return queryResult.map(
                result =>  newActivities(
                    result.activity_id,
                    result.activity_name,
                    result.activity_description,
                    result.activity_duration,

            
                )
            )
        }))
}
export function getById(activitid) {
    return db_conn.query("SELECT * FROM activities WHERE activity_id = ?", [activitid])
        .then(([queryResult]) => {
            // check that at least 1 match was found
            if (queryResult.length > 0) {
                const result = queryResult[0]

                // Convert the result into a staff model object
                return newActivities(
                    result.activity_id,
                    result.activity_name,
                    result.activity_description,
                    result.activity_duration

            
                )
            
            } else {
                return Promise.reject("no matching results")
            }
        })}
        
        export function getByname(name) {
            return db_conn.query(`SELECT * FROM activities WHERE activity_name = ?`, [name])
                .then(([queryResult]) => {
                    // check that at least 1 match was found
                    if (queryResult.length > 0) {
                        // get the first matching result
                        const result = queryResult[0]
        
                        // convert result into a model object
                        return newActivities(
                            result.activity_id,
                            result.activity_name,
                            result.activity_description,
                            result.activity_duration
        
                          
                        )
                      
                    } else {
                        return Promise.reject("no matching results")
                    }
                })
        }
        
        /////////////////////////// Testing Area (Remove before use!) ////////////
        
        //   getAll().then(newActivities => {
        //    console.log(newActivities)
        //    })
        
        //////////////////////////////////////////////////////////////////////////
        export function updateActivityById(activity) {
            return db_conn.query(
                `
                UPDATE activities
                SET activity_name = ?, activity_description = ?, activity_duration = ?
                WHERE activity_id =?
            `,
                [activity.name , activity.description , activity.duration, activity.id]
            );
        }
        /////////////////////////// Testing Area (Remove before use!) ////////////

//   const update1 = newActivities(2, "tom", "mayurbhagat","14"  )
//    updateActivityById(update1)

//////////////////////////////////////////////////////////////////////////
// Delete
export function deleteById(activityid) {
    return db_conn.query("DELETE FROM activities WHERE activity_id = ?", [activityid])
}
////////////////////////// Testing Area (Remove before use!) ////////////

//  deleteById(1).then(() => console.log("Delete operation completed!"))

//////////////////////////////////////////////////////////////////////////