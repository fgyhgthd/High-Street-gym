import { db_conn } from "../database.js"
export function newPost(
    id,
    datetime,
    user_id,
    title,
    content

) {
    return {
        id,
        datetime,
        user_id,
        title,
        content

    }
}

export function create(post) {
    return db_conn.query(`
    INSERT INTO bolg_post
 (    post_datetime,  post_user_id, post_title, post_content) 
    VALUES (?, ?, ?, ?)

    `, [



        post.datetime,
        post.user_id,
        post.title,
        post.content



    ])
}

// Testing Area (Remove before use!) 
//  const post1 = newPost(null, "2024-012-03 00:00:00", "15", "test", "test")
//  create(post1)

// Read

export function getAll() {
    return db_conn.query("SELECT * FROM bolg_post")
        .then((([queryResult]) => {
            return queryResult.map(
                result => newPost(
                    result.post_id,
                    result.post_datetime,
                    result.post_user_id,
                    result.post_title,
                    result.post_content

                    

                )
            )
        }))
}
export function getById(postid) {
    return db_conn.query("SELECT * FROM bolg_post WHERE post_id = ?", [postid])
        .then(([queryResult]) => {
            // check that at least 1 match was found
            if (queryResult.length > 0) {
                const result = queryResult[0]

                // Convert the result into a staff model object
                return newPost(
                    result.post_id,
                    result.post_datetime,
                    result.post_user_id,
                    result.post_title,
                    result.post_content
                )
            } else {
                return Promise.reject("no matching results")
            }
        })}
        export function getBytitle(title) {
            return db_conn.query(`SELECT * FROM bolg_post WHERE post_title = ?`, [title])
                .then(([queryResult]) => {
                    // check that at least 1 match was found
                    if (queryResult.length > 0) {
                        // get the first matching result
                        const result = queryResult[0]
        
                        // convert result into a model object
                        return newPost(
                            result.post_id,
                            result.post_datetime,
                            result.post_user_id,
                            result.post_title,
                            result.post_content
                        
                        )
                      
                    } else {
                        return Promise.reject("no matching results")
                    }
                })
        }
                
        /////////////////////////// Testing Area (Remove before use!) ////////////
        
        //  getAll().then( newPost => {
        //    console.log( newPost)
        //    })
        
        //////////////////////////////////////////////////////////////////////////
        
        export function update(post) {
            return db_conn.query(`
             UPDATE bolg_post SET 
           
          post_datetime =?,
          post_user_id =?,
          post_title =?,
          post_content =?
           
             WHERE post_id = ?
             `, [
                post.datetime,
                post.user_id,
                post.title,
                post.content,
                post.id
            ])
        }
        /////////////////////////// Testing Area (Remove before use!) ////////////
        
    //    const post1 =  newPost(1, "2024-012-03 00:00:00","1","new", "comtent" )
        
    //       update(post1)
        
        //////////////////////////////////////////////////////////////////////////
        
        
        // Delete
        export function deleteBypostId(postid) {
            return db_conn.query("DELETE FROM bolg_post WHERE post_id = ?", [postid])
        }
        ////////////////////////// Testing Area (Remove before use!) ////////////
        
        //   deleteById(1).then(() => console.log("Delete operation completed!"))
        
        ////////////////////////////////////////////////////////////////////////