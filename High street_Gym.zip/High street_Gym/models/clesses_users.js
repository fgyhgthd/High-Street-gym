import { db_conn } from "../database.js"
export function classesusers(
    class_id,
    class_datetime,
    class_lacation,
    class_activity_id,
    trainer_user_id,
    user_email,
    user_password,
    user_role,
    user_phone,
    user_first_name,
    user_last_name,
    user_address,

  
) {
    return {
        class_id,
        class_datetime,
        class_lacation,
        class_activity_id,
        trainer_user_id,
        user_email,
        user_password,
        user_role,
        user_phone,
        user_first_name,
        user_last_name,
        user_address,
    
        

    }
}

export function getAllByclassuser() {
    return db_conn.query(
        `
        SELECT * FROM classes
        INNER JOIN users.js
        ON class. trainer_user_id = user_id
        
    `,

    ).then(([queryResult]) => {
        // convert each result into a model object
        return queryResult.map(
            result => classesusers(
                result.class_id,
                result.class_datetime,
                result.class_lacation,
                result.class_activity_id,
                result.trainer_user_id,
                result. user_email,
                result.user_password,
                result.user_role,
                result.user_phone,
                result.user_first_name,
                result.user_last_name,
                result.user_address,
            
                
             
            )
        )

    })
}
export function getAllByclassuserid(classID) {
    return db_conn.query(
        `
        SELECT * FROM classes
        INNER JOIN users
        ON class.trainer_user_id = users.user_id 
         where classes.class_id =?
    `,
        [classID]
    ).then(([queryResult]) => {
        // check that at least 1 match was found
        if (queryResult.length > 0) {
            // get the first matching result
            const result = queryResult[0]

            // convert result into a model object
            return classesusers(
                result.class_id,
                result.class_datetime,
                result.class_lacation,
                result.class_activity_id,
                result.trainer_user_id,
                result. user_email,
                result.user_password,
                result.user_role,
                result.user_phone,
                result.user_first_name,
                result.user_last_name,
                result.user_address,
            )

        } else {
            return Promise.reject("no matching results")
        }

    })
}