import { db_conn } from "../database.js"
export function newLaction(
    id,
  name

) {
    return {
        id,
        name
       
    }
}

export function create(location) {
    return db_conn.query(`
    INSERT INTO location
    (location_name)
    VALUES (?)
    `, [

        location.name




    ])
}

// Testing Area (Remove before use!) 
//   const location1 = newLaction(null, "ipn")
//   create(location1)

// Read
export function getAll() {
    return db_conn.query("SELECT * FROM location")
        .then((([queryResult]) => {
            return queryResult.map(
                result => newLaction(
                    result.location_id,
                    result.location_name,
                   
                )
            )
        }))
}
export function getById(locationid) {
    return db_conn.query("SELECT * FROM location WHERE location_id = ?", [locationid])
        .then(([queryResult]) => {
            // check that at least 1 match was found
            if (queryResult.length > 0) {
                const result = queryResult[0]

                // Convert the result into a staff model object
                return newLaction(
                    result.location_id,
                    result.location_name
                  
                )
            } else {
                return Promise.reject("no matching results")
            }
        })}
        export function getByname(name) {
            return db_conn.query(`SELECT * FROM location WHERE location_name = ?`, [name])
                .then(([queryResult]) => {
                    // check that at least 1 match was found
                    if (queryResult.length > 0) {
                        // get the first matching result
                        const result = queryResult[0]
        
                        // convert result into a model object
                        return newLaction(
                            result.location_id,
                            result.location_name
                          
                        )
                      
                    } else {
                        return Promise.reject("no matching results")
                    }
                })
        }
        
        /////////////////////////// Testing Area (Remove before use!) ////////////
        
        //  getAll().then(newLaction => {
        //   console.log(newLaction)
        //   })
        
        //////////////////////////////////////////////////////////////////////////
        
        // Update
export function update(location) {
    return db_conn.query(`
     UPDATE location SET 
   location_name =?
   
     WHERE location_id = ?
     `, [
        location.name,
     
        location.id
    ])
}
/////////////////////////// Testing Area (Remove before use!) ////////////

//   const location1 = newLaction(1, "ip" )

//  update(location1)

//////////////////////////////////////////////////////////////////////////


// Delete
export function deleteById(locationid) {
    return db_conn.query("DELETE FROM location WHERE location_id = ?", [locationid])
}
////////////////////////// Testing Area (Remove before use!) ////////////

//  deleteById(1).then(() => console.log("Delete operation completed!"))

//////////////////////////////////////////////////////////////////////////