import { useEffect, useState } from 'react';
import { useAuthenticate } from '../aithentication/useAuthenticat';
import { fetchAPI } from '../api.mjs';
import XMLDownloadButtion from '../common/XMLDownloaButtion';
import { CiExport } from "react-icons/ci";

export function TranerSession() {
  const { user, status } = useAuthenticate(["trainer"]);
  const [error, setError] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [sessionsData, setSessionsData] = useState([]);

  useEffect(() => {
    if (!user?.id || !user?.authenticationKey) {
      setError("User authentication is missing.");
      setIsLoading(false);
      return;
    }

    fetchAPI("GET", `/sessions/trainer/me`, null, user.authenticationKey)
      .then((res) => {
        console.log("API response:", res);

        const rawSessions = res.body?.sessions || [];

        if (!Array.isArray(rawSessions)) {
          console.error("Unexpected session format:", rawSessions);
          setError("Invalid session data format.");
          setIsLoading(false);
          return;
        }

        const enrichedSessions = rawSessions.map((item) => {
          const session = item.sessions;
          const activity = item.activities;
          const location = item.location;

          return {
            ...session,
            activity_name: activity?.activity_name || 'N/A',
            location_name: location?.name || 'N/A',
          };
        });

        setSessionsData(enrichedSessions);
        setError(enrichedSessions.length ? null : "No sessions found.");
        setIsLoading(false);
      })
      .catch((err) => {
        console.error("Error fetching trainer sessions:", err);
        setError(err.message || "Failed to fetch sessions.");
        setIsLoading(false);
      });
  }, [user]);

  const handleDelete = (sessionId) => {
    const confirmDelete = window.confirm("Are you sure you want to delete this session?");
    if (confirmDelete) {
      fetchAPI("DELETE", `/sessions/${sessionId}`, null, user.authenticationKey)
        .then(() => {
          setSessionsData((prev) =>
            prev.filter(s => s.Sessions_id !== sessionId)
          );
        })
        .catch((err) => {
          console.error("Failed to delete session:", err);
          alert("Failed to delete session: " + (err.message || "Unknown error"));
        });
    }
  };

  if (isLoading) return <p>Loading...</p>;
  if (error) return <p className="text-red-600">{error}</p>;

  return (
    <section>
      <h2 className="text-3xl font-bold text-center mb-6">Your Sessions</h2>

      {user ? (
        <XMLDownloadButtion
          route={`/sessions/xml?user_id=${user.id}`}
          filename="sessions.xml"
          authenticationKey={user?.authenticationKey}
          className="btn btn-warning"
        >
          <CiExport className="text-3xl" />
          Your Sessions Information
        </XMLDownloadButtion>
      ) : (
        <span className='loading loading-spinner loading-XL'></span>
      )}

      {sessionsData.length > 0 ? (
        sessionsData.map((session) => (
          <div
            key={session.Sessions_id}
            className="max-w-3xl mx-auto p-4 bg-white shadow-md rounded-md mt-4 mb-4"
          >
            <table className="table-auto w-full mb-4">
              <tbody>
                <tr>
                  <td className="font-semibold text-lg">Activity:</td>
                  <td>{session.activity_name}</td>
                </tr>
                <tr>
                  <td className="font-semibold text-lg">Date & Time:</td>
                  <td>
                    
                    {session.Sessions_datetime

                    
                      ? new Date(session.Sessions_datetime).toLocaleString()
                      : "Invalid Date"}
                  </td>
                </tr>
                <tr>
                  <td className="font-semibold text-lg">Location:</td>
                  <td>{session.location_name}</td>
                </tr>
              </tbody>
            </table>
            <button
              className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded"
              onClick={() => handleDelete(session.Sessions_id)}
            >
              Delete
            </button>
          </div>
        ))
      ) : (
        <p>No sessions found.</p>
      )}
    </section>
  );
}

export default TranerSession;
