import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import { createBrowserRouter, RouterProvider}from "react-router"
import './index.css'
import MakeBookinng from './booking/MakeBooking'
import loginView from './aithentication/loginView'
import Layout from './common/Layout'
import editBooking from './booking/eiditBooking'
import  InformationBooking from './booking/booking_information'
import BlogView from './Blog/BlogView'
import userImformtion from './User/userImformtion'
import TrainerSessions from './sessions/TranerSession'
import SignUp from './aithentication/SignUp'
import CreatePost from './Blog/CreatePost'
import { AuthenticattionProvider } from './aithentication/useAuthenticat'
  const router = createBrowserRouter([
    {
     
      Component: Layout,
      children:[
        {
         index: true,
          Component:loginView,
       },
       {
         path:"/MakeBooking",
         Component: MakeBookinng
       },
       {
        path:"/EditeBooking",
        Component: editBooking
      },
      {
        path:"/informationBooking",
        Component:  InformationBooking
      },
      {
        path:"/BlogView",
        Component:  BlogView
      },{
        path:"/update",
        Component: userImformtion
      },{
        path:"/Sessions",
        Component: TrainerSessions
      },
      {
        path:"/register",
        Component: SignUp
      },
      {
        path:"/create",
        Component: CreatePost
      }
      
      ]

    },
    
  ])

createRoot(document.getElementById('root')).render(
  <StrictMode>
    <AuthenticattionProvider>
    <RouterProvider router={router}/>
    </AuthenticattionProvider>
    
  </StrictMode>,
)
