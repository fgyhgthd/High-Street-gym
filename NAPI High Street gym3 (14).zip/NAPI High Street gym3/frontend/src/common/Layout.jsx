import { Outlet, useNavigate, useLocation } from "react-router";
import { MdEditCalendar } from "react-icons/md";
import { IoIosLogOut } from "react-icons/io";
import { CiUser } from "react-icons/ci";
import { CgGym } from "react-icons/cg";
import { FaBlog } from "react-icons/fa";
import { MdOutlinePreview } from "react-icons/md";
import { FaRegCalendarAlt } from "react-icons/fa";
import { useAuthenticate } from "../aithentication/useAuthenticat";

function Layout() {
  const navigate = useNavigate();
  const location = useLocation();
  const isAuthView = location.pathname === "/" || location.pathname === "/register";

  const { user, logout } = useAuthenticate();

  const navItems = [
    {
      path: "/MakeBooking",
      icon: <FaRegCalendarAlt />,
      label: "Bookings",
      disabled: !user || user.role !== "members",
    },
    {
      path: "/EditeBooking",
      icon: <MdEditCalendar />,
      label: "Edit Booking",
      disabled: !user || user.role !== "members",
    },
    {
      path: "/BlogView",
      icon: <FaBlog />,
      label: "Blog",
      disabled: false,
    },
    {
      path: "/Sessions",
      icon: <MdOutlinePreview />,
      label: "Sessions",
      disabled: !user || user.role !== "trainer",
    },
    {
      path: "/update",
      icon: <CiUser />,
      label: "User",
      // need to see why manger can not access this page  
      // members are able to see the page all good with this one but to not working with trainer 
      disabled: !user || (user.role !== "trainer" && user.role !== "members"),
    },
  ];

  return (
    <main className="max-w-[430px] min-h-screen mx-auto shadow bg-base-100">
      <header className="flex items-center justify-center bg-white shadow-md rounded-md mt-8 mb-4 p-4">
        <button
          className="flex items-center gap-2 text-black"
          onClick={() => navigate("/")}
        >
          <CgGym className="text-3xl" />
          <h1 className="text-2xl font-bold">High Street Gym</h1>
        </button>
      </header>

      <Outlet />

      {/* Bottom Nav: Show only BlogView if on auth pages */}
      <nav className="flex justify-around items-center py-3 bg-white shadow-md rounded-md mt-6 mx-2">
        {navItems.map(({ path, icon, label, disabled }) => {
          // Show only BlogView if on auth view
          if (isAuthView && path !== "/BlogView") return null;

          return (
            <button
              key={path}
              onClick={() => !disabled && navigate(path)}
              disabled={disabled}
              className={`flex flex-col items-center text-sm ${
                location.pathname === path
                  ? "text-green-600 font-semibold"
                  : "text-gray-600"
              } ${disabled ? "opacity-50 cursor-not-allowed" : ""}`}
            >
              <span className="text-2xl">{icon}</span>
              <span>{label}</span>
            </button>
          );
        })}

        {!isAuthView && user && (
          <button
            onClick={() => {
              logout();
              navigate("/");
            }}
            className="flex flex-col items-center text-sm text-red-500"
          >
            <IoIosLogOut className="text-2xl" />
            <span>Log Out</span>
          </button>
        )}
      </nav>

      {/* Footer Section */}
      <footer className="text-center text-xs text-gray-500 mt-6 mb-4 px-4">
        <p>© {new Date().getFullYear()} High Street Gym.  Made with love Mayur Bhagat .</p>
        <p>
          <button
            onClick={() => navigate("/privacy-policy")}
            className="underline hover:text-green-600 transition"
          >
            Privacy Policy
          </button>
        </p>
      </footer>
    </main>
  );
}

export default Layout;
