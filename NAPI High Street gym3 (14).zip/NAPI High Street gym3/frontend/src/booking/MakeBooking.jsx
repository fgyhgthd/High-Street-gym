import { Fragment, useCallback, useEffect, useState } from "react";
import { useNavigate } from "react-router";
import { fetchAPI } from "../api.mjs";
import { useAuthenticate } from "../aithentication/useAuthenticat";

function MakeBooking() {
    const { user, status, authenticationKey } = useAuthenticate(["members"]);
    const navigate = useNavigate();
    const [bookingsByDay, setBookingsByDay] = useState({});
    const [locations, setLocations] = useState([]);
    const [error, setError] = useState(null);
    const [selectedLocation, setSelectedLocation] = useState("");
    const [loading, setLoading] = useState(true);

    const getBookings = useCallback(() => {
        if (!authenticationKey) return;

        setLoading(true);
        fetchAPI("GET", "/Sessions/", null, authenticationKey)
            .then((res) => {
                const data = res.body;
                if (data.length > 0) {
                    setBookingsByDay(partitionBookingsByDay(data));
                    setLocations(extractUniqueLocations(data));
                    setError(null);
                } else {
                    setBookingsByDay({});
                    setLocations([]);
                    setError("No sessions found.");
                }
            })
            .catch((err) => {
                setError(err.message || "Failed to fetch bookings.");
            })
            .finally(() => setLoading(false));
    }, [authenticationKey]);

    useEffect(() => {
        getBookings();
    }, [getBookings]);

    return (
        <section className="flex flex-col items-center p-6 min-h-screen bg-base-200">
            <h2 className="text-3xl font-bold mb-6">Available Sessions</h2>

            {error && <span className="text-red-500 text-lg">{error}</span>}

            {loading ? (
                <span className="loading loading-spinner loading-lg my-10"></span>
            ) : (
                <>
                    <div className="mb-6">
                        <label className="block text-lg font-medium mb-2">
                            Select a location:
                        </label>
                        <select
                            className="select select-bordered w-full max-w-xs"
                            value={selectedLocation}
                            onChange={(e) => setSelectedLocation(e.target.value)}
                            disabled={loading}
                        >
                            <option value="">-- Choose a location --</option>
                            {locations.map((loc) => (
                                <option key={loc} value={loc}>
                                    {loc}
                                </option>
                            ))}
                        </select>
                    </div>

                    {!selectedLocation && (
                        <p className="text-gray-500 mt-4 italic">
                            Please select a location to view available sessions.
                        </p>
                    )}

                    {selectedLocation && (
                        <ul className="w-full max-w-2xl divide-y divide-gray-300">
                            {Object.entries(bookingsByDay).map(([day, sessions]) => {
                                const filteredSessions = sessions.filter(
                                    (s) => s.location.name === selectedLocation
                                );

                                return (
                                    <Fragment key={day}>
                                        <li className="text-lg font-semibold text-gray-700 bg-base-300 px-4 py-2">
                                            {day}
                                        </li>

                                        {filteredSessions.length > 0 ? (
                                            filteredSessions.map((session) => (
                                                <li
                                                    key={`${session.sessions.Sessions_id}-${session.sessions.Sessions_datetime}`}
                                                    className="flex justify-between items-center px-4 py-3 bg-white rounded shadow"
                                                >
                                                    <div className="flex flex-col">
                                                        <span className="text-md font-medium">
                                                            {session.activities.activity_name}
                                                        </span>
                                                        <span className="text-sm text-gray-500">
                                                            Location: {session.location.name}
                                                        </span>
                                                        <span className="text-sm text-gray-400">
                                                            {new Date(session.sessions.Sessions_datetime).toLocaleString()}
                                                            
                                                        </span>
                                                    </div>
                                                    <button
                                                        onClick={() =>
                                                            navigate("/informationBooking", {
                                                                state: { session },
                                                            })
                                                        }
                                                        className="btn btn-success"
                                                    >
                                                        Book &gt;
                                                    </button>
                                                </li>
                                            ))
                                        ) : (
                                            <li className="px-4 py-3 text-gray-500 italic bg-white rounded shadow">
                                                No sessions available.
                                            </li>
                                        )}
                                    </Fragment>
                                );
                            })}
                        </ul>
                    )}
                </>
            )}
        </section>
    );
}

function extractUniqueLocations(sessions) {
    const locationSet = new Set();
    sessions.forEach((s) => locationSet.add(s.location.name));
    return Array.from(locationSet).sort();
}

function partitionBookingsByDay(bookings) {
    const daysOfWeek = [
        "Sunday",
        "Monday",
        "Tuesday",
        "Wednesday",
        "Thursday",
        "Friday",
        "Saturday",
    ];
    const dayPartitions = {
        Sunday: [],
        Monday: [],
        Tuesday: [],
        Wednesday: [],
        Thursday: [],
        Friday: [],
        Saturday: [],
    };

    const seen = new Set();

    for (const session of bookings) {
        const { activity_name } = session.activities;
        const locationName = session.location.name;
        const datetime = session.sessions.Sessions_datetime;

        const key = `${activity_name}|${locationName}|${datetime}`;
        if (!seen.has(key)) {
            seen.add(key);
            const bookingDate = parseDateTime(datetime);
            const day = daysOfWeek[bookingDate.getDay()];
            dayPartitions[day].push(session);
        }
    }

    for (const day in dayPartitions) {
        dayPartitions[day].sort((a, b) => {
            return parseDateTime(a.sessions.Sessions_datetime) - parseDateTime(b.sessions.Sessions_datetime);
        });
    }

    return dayPartitions;
}

function parseDateTime(datetime) {
    return new Date(datetime.includes("T") ? datetime : datetime.replace(" ", "T"));
}

export default MakeBooking;
