import { useEffect, useState } from 'react';
import { fetchAPI } from '../api.mjs';
import { useAuthenticate } from '../aithentication/useAuthenticat';
import XMLDownloadButtion from '../common/XMLDownloaButtion';
import { CiExport } from "react-icons/ci";
import { RiDeleteBin6Line } from "react-icons/ri";

function EditBooking() {
    const { user } = useAuthenticate(["members"]);
    const [error, setError] = useState(null);
    const [isLoading, setIsLoading] = useState(true);
    const [bookings, setBookings] = useState([]);

    useEffect(() => {
        if (!user?.id || !user?.authenticationKey) {
            setError("User authentication is missing.");
            setIsLoading(false);
            return;
        }

        fetchAPI("GET", `/bookings/`, null, user.authenticationKey)
            .then((res) => {
                const data = res.body || [];
                setBookings(data);
                setError(data.length ? null : "No bookings found.");
                setIsLoading(false);
            })
            .catch((err) => {
                setError(err.message || "Failed to fetch bookings.");
                setIsLoading(false);
            });
    }, [user]);

    const handleDelete = (booking) => {
        const bookingId = Number(booking.booking_id);

        if (isNaN(bookingId)) {
            setError("Booking ID is invalid.");
            return;
        }

        const confirmDelete = window.confirm("Are you sure you want to delete this booking?");
        if (!confirmDelete) return;

        fetchAPI("DELETE", `/bookings/${bookingId}`, null, user.authenticationKey)
            .then(() => {
                setBookings(prev => prev.filter(b => b.booking_id !== bookingId));
            })
            .catch((err) => {
                setError(err.message || "Failed to delete booking.");
            });
    };

    if (isLoading) return <p>Loading...</p>;
    if (error) return <p className="text-red-600">{error}</p>;

    return (
        <section>
            <div className="max-w-3xl mx-auto p-4 bg-white shadow-md rounded-md mt-8 mb-4">
                <h2 className="text-3xl font-bold text-center mb-6">Edit Booking</h2>
                {
                    user &&
                    <XMLDownloadButtion
                        route={`/bookings/xml?user_id=${user.id}`}
                        filename="booking.xml"
                        authenticationKey={user?.authenticationKey}
                        className="btn btn-warning mb-4">
                        <CiExport className="text-3xl" />
                        Your Bookings Information
                    </XMLDownloadButtion>
                }

                {bookings.map((booking) => (
                    <section key={booking.booking_id} className="mb-6 border-t pt-4">
                        <table className="table-auto w-full mb-4">
                            <tbody>
                                <tr>
                                    <td className="font-semibold text-lg">Booking ID:</td>
                                    <td>{booking.booking_id}</td>
                                </tr>
                                <tr>
                                    <td className="font-semibold text-lg">Activity:</td>
                                    <td>{booking.activity_name}</td>
                                </tr>
                                <tr>
                                    <td className="font-semibold text-lg">Trainer:</td>
                                    <td>{booking.trainer.name} </td>
                                </tr>
                                <tr>
                                    <td className="font-semibold text-lg">Session Time:</td>
                                    
                                     <td>{new Date(booking.session_datetime).toLocaleString()}</td>
                                </tr>
                                
                                <tr>
                                    <td className="font-semibold text-lg">Location:</td>
                                    <td>{booking.location_name}</td>
                                </tr>
                            </tbody>
                        </table>
                        <button className="btn btn-error" onClick={() => handleDelete(booking)}>
                            <RiDeleteBin6Line /> Delete
                        </button>
                    </section>
                ))}
            </div>
        </section>
    );
}

export default EditBooking;
