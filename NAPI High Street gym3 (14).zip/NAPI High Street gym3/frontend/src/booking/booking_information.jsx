import { useLocation, useNavigate } from "react-router";
import { useEffect, useState } from "react";
import { MdArrowBackIosNew } from "react-icons/md";
import { fetchAPI } from "../api.mjs";
import { useAuthenticate } from "../aithentication/useAuthenticat";

function InformationBooking() {
    const { state } = useLocation();
    const navigate = useNavigate();
    const { user, authenticationKey } = useAuthenticate("members");
    const [conflicts, setConflicts] = useState([]);
    const [selectedTrainerName, setSelectedTrainerName] = useState("");
    const [selectedSession, setSelectedSession] = useState(null);
    const [userBookings, setUserBookings] = useState([]);
    const [duplicateBookingMessage, setDuplicateBookingMessage] = useState("");

    useEffect(() => {
        if (!state?.session) {
            navigate("/makeBooking");
            return;
        }

        fetchAPI("GET", "/Sessions/",null, authenticationKey)
            .then((res) => {
                const data = res.body;
                const session = state.session;

                const matchingSessions = data.filter(
                    (s) =>
                        s.sessions.Sessions_datetime === session.sessions.Sessions_datetime &&
                        s.location.name === session.location.name
                );

                setConflicts(matchingSessions);

                if (matchingSessions.length === 1) {
                    setSelectedSession(matchingSessions[0]);
                }
            })
            .catch((err) => {
                console.error("Failed to fetch sessions", err);
            });

        if (user?.id && authenticationKey) {
            fetchAPI("GET", `/bookings/`, null, authenticationKey)
                .then((res) => {
                    if (Array.isArray(res.body)) {
                        setUserBookings(res.body);
                    } else {
                        console.warn("Unexpected response format for bookings:", res.body);
                        setUserBookings([]);
                    }
                })
                .catch((err) => {
                    console.error("Failed to fetch user bookings", err);
                });
        } else {
            console.warn("User not authenticated or user_id missing.");
        }
    }, [state, navigate, user?.id, authenticationKey]);

    useEffect(() => {
        if (conflicts.length > 1 && selectedTrainerName) {
            const found = conflicts.find(
                (s) => s.users.first_name === selectedTrainerName
            );
            setSelectedSession(found);
        }
    }, [selectedTrainerName, conflicts]);

    const handleConfirmBooking = () => {
        if (!selectedSession || !user) {
            alert("Please select a session and make sure you're logged in.");
            return;
        }

        const alreadyBooked = Array.isArray(userBookings) && userBookings.some(
            (b) => b.Sessions_id === selectedSession.sessions.Sessions_id
        );

        if (alreadyBooked) {
            setDuplicateBookingMessage("You already have a booking for this session and can no longer make another booking. Have a nice day.");
            return;
        }

        setDuplicateBookingMessage("");

        fetchAPI("POST", "/bookings", {
            user_id: user.id,
            Sessions_id: selectedSession.sessions.Sessions_id,
            activity_id: selectedSession.activities.activity_id,
            location_id: selectedSession.location.id,
        }, authenticationKey)
            .then((response) => {
                if (response.status === 200) {
                    alert(`Your booking is confirmed with ${selectedSession.users.first_name}. See you in class.`);
                    navigate("/EditeBooking");
                } else {
                    alert("Booking failed: " + response.body.message);
                }
            })
            .catch((error) => {
                console.error("Booking error", error);
                alert("Failed to create booking: " + error.message);
            });
    };

    return (
        <section className="p-6 max-w-3xl mx-auto bg-white rounded-2xl shadow-lg animate-fade-in">
            <h2 className="text-3xl font-bold mb-6 text-center">Booking Information</h2>

            {conflicts.length > 1 && (
                <div className="mb-6">
                    <label className="block text-md font-semibold text-gray-700 mb-2">
                        Select Your Trainer
                    </label>
                    <select
                        value={selectedTrainerName}
                        onChange={(e) => setSelectedTrainerName(e.target.value)}
                        className="select select-bordered w-full text-base"
                    >
                        <option value="">-- Choose a trainer --</option>
                        {conflicts.map((s) => (
                            <option key={s.sessions.Sessions_id} value={s.users.first_name}>
                                {s.users.first_name}
                            </option>
                        ))}
                    </select>
                </div>
            )}

            {duplicateBookingMessage && (
                <div className="mb-6 p-4 bg-yellow-100 border-l-4 border-yellow-500 text-yellow-700 rounded">
                    {duplicateBookingMessage}
                </div>
            )}

            {selectedSession && (
                <>
                    <div className="bg-gray-50 p-6 rounded-xl shadow-inner space-y-3 text-base text-gray-700">
                        <p><span className="font-semibold">Activity:</span> {selectedSession.activities.activity_name}</p>
                        <p><span className="font-semibold">Description:</span> {selectedSession.activities.activity_description}</p>
                        <p><span className="font-semibold">Duration:</span> {selectedSession.activities.activity_duration} mins</p>
                        <p><span className="font-semibold">Trainer:</span> {selectedSession.users.first_name}</p>
                        <p><span className="font-semibold">Location:</span> {selectedSession.location.name}</p>
                        <p><span className="font-semibold">Date & Time:</span> {new Date(selectedSession.sessions.Sessions_datetime).toLocaleString()}</p>
                    </div>

                    <div className="mt-8 text-center flex justify-center gap-4">
                        <button
                            className="btn btn-success"
                            onClick={() => navigate("/makebooking")}
                        >
                            <MdArrowBackIosNew />
                            Back
                        </button>

                        <button
                            className="btn btn-success"
                            onClick={handleConfirmBooking}
                        >
                            Confirm Booking
                        </button>
                    </div>
                </>
            )}
        </section>
    );
}

export default InformationBooking;
