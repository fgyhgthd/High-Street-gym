export const API_BASE_URL = "http://localhost:8080/api";

/**
 * Makes an API request.
 * 
 * @param {"GET"|"POST"|"PUT"|"PATCH"|"DELETE"|string} method - HTTP method
 * @param {string} route - API route starting with /
 * @param {object|null} body - Optional body data
 * @param {string|null} authKey - Optional authentication key for headers
 * @returns {Promise<{ status: number, body: any }>} Result of the API fetch request
 * @throws {string} API fetch error
 */
export async function fetchAPI(method, route, body = null, authKey = null) {
  const headers = {
    "Content-Type": "application/json"
  };

  if (authKey) {
    headers["X-Auth-Key"] = authKey;
  }

  try {
    const response = await fetch(API_BASE_URL + route, {
      method,
      headers,
      body: body ? JSON.stringify(body) : null
    });

    const status = response.status;

    // Only try to parse JSON if content-type is JSON and status is not 204
    const contentType = response.headers.get("content-type") || "";
    let responseBody = null;

    if (status !== 204 && contentType.includes("application/json")) {
      responseBody = await response.json();
    }

    return {
      status,
      body: responseBody
    };
  } catch (error) {
    throw String(error);
  }
}
