import { useCallback, useEffect, useState } from "react";
import { CiLogin } from "react-icons/ci";
import { FaRegistered } from "react-icons/fa";
import { useAuthenticate } from "./useAuthenticat";
import { useNavigate } from "react-router";

function LoginView() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const { login, status, user } = useAuthenticate();
  
  const onLoginSubmit = useCallback((e) => {
    e.preventDefault();
    login(email, password);
  }, [email, password, login]);
  
  useEffect(() => {
    if (user) {
      if (user.role === "members") {
        navigate("/MakeBooking");
      } else if (user.role === "trainer") {
        navigate("/Sessions");
      }
    }
  }, [user, navigate]);
  
  return (
    <section className="flex justify-center items-center min-h-screen bg-base-200">
      <div className="card w-full max-w-md shadow-xl bg-base-100 p-6">
        <h1 className="text-3xl font-bold text-center mb-6">Login</h1>

        <form className="space-y-4" onSubmit={onLoginSubmit}>
          <label className="form-control w-full">
            <span className="label-text">Email</span>
            <input 
              value={email}
              onChange={e => setEmail(e.target.value)}
              type="email" 
              placeholder="your@email.com" 
              className="input input-bordered w-full"
              required
            />
          </label>

          <label className="form-control w-full">
            <span className="label-text">Password</span>
            <input
              value={password}
              onChange={e => setPassword(e.target.value)}
              type="password" 
              placeholder="••••••••" 
              className="input input-bordered w-full"
              required
            />
          </label>

          {/* Display error message here */}
          {status && status !== "loaded" && status !== "authenticating" && (
            <p className="text-error text-sm mt-2">{status}</p>
          )}

          <div className="flex flex-col sm:flex-row gap-4 mt-6">
            <button type="submit" className="btn btn-success">
              <CiLogin className="text-xl" />
              <span className="ml-2">Login</span>
            </button>

            <button
              onClick={() => navigate("/register")}
              type="button"
              className="btn btn-outline"
            >
              <FaRegistered className="text-xl" />
              <span className="ml-2">Register</span>
            </button>
          </div>
        </form>
      </div>
    </section>
  );
}

export default LoginView;
