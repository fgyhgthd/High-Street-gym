import { createContext, useCallback, useContext, useEffect, useState } from "react"
import { fetchAPI } from "../api.mjs"
import { useNavigate } from "react-router"

export const AuthenticationContext = createContext(null)

export function AuthenticattionProvider({ children }) {
    const [user, setUser] = useState(null)
    const [authenticationKey, setAuthenticationKey] = useState(localStorage.getItem("auth-key"))
    const [status, setStatus] = useState("resuming")

    useEffect(() => {
        if (authenticationKey) {
            fetchAPI("GET", "/users/self", null, authenticationKey)
                .then(response => {
                    setUser(response.body)
                    setStatus("loaded")
                })
                .catch(() => {
                    setUser(null)
                    setAuthenticationKey(null)
                    localStorage.removeItem("auth-key")
                    setStatus(null)
                })
        } else {
            setStatus(null)
        }
    }, [authenticationKey])

    return (
        <AuthenticationContext.Provider value={[user, setUser, authenticationKey, setAuthenticationKey, status, setStatus]}>
            {children}
        </AuthenticationContext.Provider>
    )
}

export function useAuthenticate(restrictToRoles = null) {
    const [user, setUser, authenticationKey, setAuthenticationKey, status, setStatus] = useContext(AuthenticationContext)
    const navigate = useNavigate()

    const getUser = useCallback((key) => {
        if (key) {
            setStatus("loading")
            fetchAPI("GET", "/users/self", null, key)
                .then(response => {
                    setUser(response.body)
                    setAuthenticationKey(key)
                    localStorage.setItem("auth-key", key)
                    setStatus("loaded")
                })
                .catch(() => {
                    setUser(null)
                    setAuthenticationKey(null)
                    localStorage.removeItem("auth-key")
                    setStatus("invalid key")
                })
        }
    }, [setUser, setAuthenticationKey, setStatus])

    const login = useCallback((email, password) => {
        const body = { email, password }

        setStatus("authenticating")
        fetchAPI("POST", "/authenticate", body)
            .then(response => {
                if (response.status === 200) {
                    const key = response.body.key
                    getUser(key)
                } else if (response.body?.errors?.[0]) {
                    // Display specific server error (e.g. manager login block)
                    setStatus(response.body.errors[0])
                } else {
                    setStatus("Email or password is invalid")
                }
            })
            .catch(error => {
                console.error(error)
                setStatus("network error")
            })
    }, [getUser, setStatus])

    const logout = useCallback(() => {
        if (authenticationKey) {
            fetchAPI("DELETE", "/authenticate", null, authenticationKey)
        }

        setUser(null)
        setAuthenticationKey(null)
        localStorage.removeItem("auth-key")
        setStatus("logged out")
    }, [authenticationKey, setUser, setAuthenticationKey, setStatus])

    const refresh = useCallback(() => {
        getUser(authenticationKey)
    }, [authenticationKey, getUser])

    useEffect(() => {
        if (restrictToRoles && status !== "resuming") {
            if (!user || !restrictToRoles.includes(user.role)) {
                navigate("/")
            }
        }
    }, [user, status, restrictToRoles, navigate])

    return {
        user,
        login,
        logout,
        refresh,
        status,
        authenticationKey,
    }
}


