import { useState, useCallback } from "react";
import { useNavigate } from "react-router";
import { fetchAPI } from "../api.mjs";
import validator from "validator";

function SignUp() {
  const [first_name, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [address, setAddress] = useState("");
  const [validationErrors, setValidationErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const [status, setStatus] = useState("");
  const navigate = useNavigate();

  const submitUser = useCallback(() => {
    setLoading(true);
    setStatus("");

    const validationErrors = {};
    if (!/^[a-zA-Z\-'\s]{2,}$/.test(first_name)) {
      validationErrors.first_name = "Missing or invalid first name";
    }
    if (!/^[a-zA-Z\-'\s]{1,}$/.test(lastName)) {
      validationErrors.lastName = "Missing or invalid last name";
    }
     if (!/^\+?\d{8,15}$/.test(phone)) {
      validationErrors.phone = "Phone number must be digits only, optionally starting with '+'";
    }


    if (!validator.isEmail(email)) {
      validationErrors.email = "Missing or invalid email";
    }
    if (!/^[\w\s.,'-]{5,}$/.test(address)) {
      validationErrors.address = "Missing or invalid address";
    }


    setValidationErrors(validationErrors);
    if (Object.keys(validationErrors).length > 0) {
      setLoading(false);
      return;
    }

    fetchAPI("POST", "/users", {
      first_name: first_name,
      last_name: lastName,
      phone: phone,
      email: email,
      password: password,
      address: address,
      role: "members",

    })
      .then((response) => {
        if (response.status === 200) {
          navigate("/");
        } else {
          setStatus("Failed to create user - " + response.body.message);
          setLoading(false);
        }
      })
      .catch((error) => {
        setStatus("Failed to create user - " + error.message);
        setLoading(false);
      });
  }, [first_name, lastName, phone, email, password, address, navigate]);

  return (
    <section className="flex justify-center items-center min-h-screen bg-base-200">
      <div className="card w-full max-w-md shadow-xl bg-base-100 p-6">
        <h1 className="text-2xl font-bold text-center mb-6">
          Join the number one world-class gym now
        </h1>

        <form
          className="space-y-4"
          onSubmit={(e) => {
            e.preventDefault();
            submitUser();
          }}
        >
          <label className="form-control w-full">
            <span className="label-text">First Name</span>
            <input
              value={first_name}
              onChange={(e) => setFirstName(e.target.value)}
              type="text"
              placeholder="John"
              className="input input-bordered w-full"
            />
            {validationErrors.first_name && (
              <p className="text-red-500 text-sm mt-1">{validationErrors.first_name}</p>
            )}
          </label>

          <label className="form-control w-full">
            <span className="label-text">Last Name</span>
            <input
              value={lastName}
              onChange={(e) => setLastName(e.target.value)}
              type="text"
              placeholder="Doe"
              className="input input-bordered w-full"
            />
            {validationErrors.lastName && (
              <p className="text-red-500 text-sm mt-1">{validationErrors.lastName}</p>
            )}
          </label>

          <label className="form-control w-full">
            <span className="label-text">Email</span>
            <input
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              type="email"
              placeholder="john@example.com"
              className="input input-bordered w-full"
            />
            {validationErrors.email && (
              <p className="text-red-500 text-sm mt-1">{validationErrors.email}</p>
            )}
          </label>

          <label className="form-control w-full">
            <span className="label-text">Password</span>
            <input
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              type="password"
              placeholder="••••••••"
              className="input input-bordered w-full"
            />
          </label>

          <label className="form-control w-full">
            <span className="label-text">Role</span>
            <input
              type="text"
              value="members"
              className="input input-bordered w-full"
              readOnly
            />
          </label>

          <label className="form-control w-full">
            <span className="label-text">Phone Number</span>
            <input
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              type="tel"
              placeholder="+61 412 345 678"
              className="input input-bordered w-full"
            />
            {validationErrors.phone && (
              <p className="text-red-500 text-sm mt-1">{validationErrors.phone}</p>
            )}
          </label>

          <label className="form-control w-full">
            <span className="label-text">Address</span>
            <input
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              type="text"
              placeholder="123 High St, Brisbane"
              className="input input-bordered w-full"
            />
            {validationErrors.address && (
              <p className="text-red-500 text-sm mt-1">{validationErrors.address}</p>
            )}
          </label>

          <button
            type="submit"
            disabled={loading}
            className="btn btn-success w-full mt-4"
          >
            Become a Member
          </button>

          {status && (
            <p className="text-center text-red-500 mt-2">{status}</p>
          )}
        </form>
      </div>
    </section>
  );
}

export default SignUp;
