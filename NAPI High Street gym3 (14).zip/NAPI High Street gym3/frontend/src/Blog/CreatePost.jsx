import { GrDocumentUpdate } from "react-icons/gr";
import { useState, useEffect } from "react";
import { MdArrowBackIosNew } from "react-icons/md";
import { useLocation, useNavigate } from "react-router";
import { useAuthenticate } from "../aithentication/useAuthenticat";
import { RiDeleteBin6Line } from "react-icons/ri";

function CreatePost() {
  const navigate = useNavigate();
  const location = useLocation();
  const blog = location.state?.blog;
  const { user, status } = useAuthenticate(["members"]);

  const [post_title, setTitle] = useState("");
  const [post_content, setContent] = useState("");
  const [post_user_id, setpost_user_id] = useState("");
  const [errors, setErrors] = useState({});

  const [showDeleteModal, setShowDeleteModal] = useState(false);
  const [showMessageModal, setShowMessageModal] = useState(false);
  const [modalMessage, setModalMessage] = useState("");

  useEffect(() => {
    if (blog) {
      setTitle(blog.post_title);
      setContent(blog.post_content);
    }
    if (user?.id) {
      setpost_user_id(String(user.id));
    }
  }, [blog, user]);

  if (status === "loading") return <div>Loading...</div>;
  if (!user) return <div>You are not authorized to view this page.</div>;

  const handleSubmit = async (e) => {
    e.preventDefault();

    // Form validation
    const validationErrors = {};

    if (!/^[a-zA-Z\-'\s]{2,}$/.test(post_title)) {
      validationErrors.title = "Missing or invalid title";
    }

    if (!/^[a-zA-Z\-'\s]{1,}$/.test(post_content)) {
      validationErrors.content = "Missing or invalid content";
    }

    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      return;
    }

    const url = blog
      ? `http://localhost:8080/api/blog/${blog.post_id}`
      : "http://localhost:8080/api/blog";
    const method = blog ? "PUT" : "POST";

    try {
      const response = await fetch(url, {
        method,
        headers: {
          "Content-Type": "application/json",
          "x-auth-key": user?.authenticationKey,
        },
        body: JSON.stringify({ post_title, post_content, post_user_id }),
      });

      if (response.ok) {
        navigate("/BlogView");
      } else {
        const errorData = await response.json();
        setModalMessage(errorData.message);
        setShowMessageModal(true);
      }
    } catch (error) {
      setModalMessage("An error occurred: " + error.message);
      setShowMessageModal(true);
    }
  };

  const confirmDelete = async () => {
    try {
      const response = await fetch(`http://localhost:8080/api/blog/${blog.post_id}`, {
        method: "DELETE",
        headers: {
          "Content-Type": "application/json",
          "x-auth-key": user?.authenticationKey,
        },
      });

      if (response.ok) {
        navigate("/BlogView");
      } else {
        const errorData = await response.json();
        setModalMessage(errorData.message);
        setShowMessageModal(true);
      }
    } catch (error) {
      setModalMessage("An error occurred while deleting: " + error.message);
      setShowMessageModal(true);
    }
  };

  return (
   <section className="flex justify-center items-start min-h-screen bg-base-200 pt-10">

      <div className="card w-full max-w-md shadow-xl bg-base-100 p-6">
        <h1 className="text-3xl font-bold text-center mb-6">
          {blog ? "Edit Post" : "Create Post"}
        </h1>

        <form className="space-y-4" onSubmit={handleSubmit}>
          <label className="form-control w-full">
            <span className="label-text">Title</span>
            <input
              value={post_title}
              onChange={(e) => setTitle(e.target.value)}
              type="text"
              placeholder="World class trainers only at..."
              className="input input-bordered w-full"
            />
            {errors.title && (
              <p className="text-red-500 text-sm mt-1">{errors.title}</p>
            )}
          </label>

          <label className="form-control w-full">
            <span className="label-text">Content</span>
            <textarea
              value={post_content}
              onChange={(e) => setContent(e.target.value)}
              placeholder="High Street Gym"
              className="textarea textarea-bordered w-full"
              rows={5}
            />
            {errors.content && (
              <p className="text-red-500 text-sm mt-1">{errors.content}</p>
            )}
          </label>

          <div className="mt-8 text-center flex justify-center gap-4 flex-wrap">
            <button
              type="button"
              className="btn btn-success mt-4"
              onClick={() => navigate("/BlogView")}
            >
              <MdArrowBackIosNew />
              <span className="ml-2">Back</span>
            </button>

            <button type="submit" className="btn btn-success mt-4">
              <GrDocumentUpdate className="text-lg" />
              <span className="ml-2">{blog ? "Update Post" : "Add Post"}</span>
            </button>

            {blog && (
              // delete 
              <button
                type="button"
                className="btn btn-error mt-4"
                onClick={() => setShowDeleteModal(true)}
              >
                <RiDeleteBin6Line />
              </button>
            )}
          </div>
        </form>
      </div>

      {/* Delete Confirmation Modal */}
      {showDeleteModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
          <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-sm text-center">
            <h2 className="text-xl font-semibold mb-4">Confirm Deletion</h2>
            <p className="mb-6">Are you sure you want to delete this post?</p>
            <div className="flex justify-center gap-4">
              <button
                className="btn btn-error"
                onClick={() => {
                  confirmDelete();
                  setShowDeleteModal(false);
                }}
              >
                Yes, Delete
              </button>
              <button
                className="btn"
                onClick={() => setShowDeleteModal(false)}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Message Modal */}
      {showMessageModal && (
        <div className="fixed inset-0 flex items-center justify-center backdrop-blur-sm z-50">
          <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-sm text-center">
            <h2 className="text-xl font-semibold mb-4">Message</h2>
            <p className="mb-6">{modalMessage}</p>
            <div className="flex justify-center">
              <button className="btn btn-primary" onClick={() => setShowMessageModal(false)}>
                OK
              </button>
            </div>
          </div>
        </div>
      )}
    </section>
  );
}

export default CreatePost;
