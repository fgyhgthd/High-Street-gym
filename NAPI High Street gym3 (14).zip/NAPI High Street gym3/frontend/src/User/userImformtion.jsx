import { GrDocumentUpdate } from "react-icons/gr";
import { useAuthenticate } from "../aithentication/useAuthenticat"
import { useEffect, useState } from "react";
import { useNavigate } from "react-router";
import validator from "validator";
import { fetchAPI } from "../api.mjs";

function UserInformation() {
  const { user, status, refresh } = useAuthenticate();

  const [first_name, setFirstName] = useState("");
  const [last_name, setLastName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState("");
  const [address, setAddress] = useState("");
  const [error, setError] = useState(null);
  const [isUpdating, setIsUpdating] = useState(false);
  const [validationErrors, setValidationErrors] = useState({});
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (!user || !user?.id || !user?.authenticationKey) return;

    fetchAPI("GET", `/users/${user.id}`, null, user.authenticationKey)
      .then((res) => {
        const data = res.body;
        if (!data) {
          setError("User information not found.");
        } else {
          setFirstName(data.first_name || "");
          setLastName(data.last_name || "");
          setEmail(data.email || "");
          setRole(data.role || "");
          setPhone(data.phone || "");
          setAddress(data.address || "");
        }
      })
      .catch((err) => {
        console.error("API fetch error:", err);
        setError(err.message || "Failed to fetch user information.");
      });
  }, [user]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    const validationErrors = {};

    if (!/^[a-zA-Z\-'\s]{2,}$/.test(first_name)) {
      validationErrors.first_name = "Missing or invalid first name";
    }
    if (!/^[a-zA-Z\-'\s]{1,}$/.test(last_name)) {
      validationErrors.last_name = "Missing or invalid last name";
    }
    if (!/^\+?\d{8,15}$/.test(phone)) {
      validationErrors.phone = "Phone number must be digits only, optionally starting with '+'";
    }
    if (!validator.isEmail(email)) {
      validationErrors.email = "Missing or invalid email";
    }
    if (!/^[\w\s.,'-]{5,}$/.test(address)) {
      validationErrors.address = "Missing or invalid address";
    }

    setValidationErrors(validationErrors);

    if (Object.keys(validationErrors).length > 0) {
      setLoading(false);
      return;
    }

    const updatedData = {
      first_name,
      last_name,
      email,
      role,
      phone,
      address,
    };

    if (password) updatedData.password = password;

    try {
      setIsUpdating(true);
      const response = await fetchAPI("PATCH", `/users/${user.id}`, updatedData, user.authenticationKey);
      await refresh();
      alert("Information updated successfully.");
      navigate("/update");
    } catch (err) {
      alert("Update failed: " + (err.message || err));
    } finally {
      setIsUpdating(false);
      setLoading(false);
    }
  };

  if (status === "resuming" || status === "loading") {
    return <p className="text-center mt-10">Loading...</p>;
  }

  if (!user) {
    return <p className="text-center text-red-500 mt-10">User authentication is missing.</p>;
  }

  if (error) {
    return <p className="text-center text-red-500 mt-10">{error}</p>;
  }

  return (
    <section className="flex justify-center items-center min-h-screen bg-base-200">
      <div className="card w-full max-w-md shadow-xl bg-base-100 p-6">
        <h1 className="text-3xl font-bold text-center mb-6">
          Your Personal Information
        </h1>

        <form className="space-y-4" onSubmit={handleSubmit}>
          <label className="form-control w-full">
            <span className="label-text">First Name</span>
            <input
              type="text"
              value={first_name}
              onChange={(e) => setFirstName(e.target.value)}
              placeholder="John"
              className="input input-bordered w-full"
            />
            {validationErrors.first_name && <p className="text-red-500 text-sm">{validationErrors.first_name}</p>}
          </label>

          <label className="form-control w-full">
            <span className="label-text">Last Name</span>
            <input
              type="text"
              value={last_name}
              onChange={(e) => setLastName(e.target.value)}
              placeholder="Doe"
              className="input input-bordered w-full"
            />
            {validationErrors.last_name && <p className="text-red-500 text-sm">{validationErrors.last_name}</p>}
          </label>

          <label className="form-control w-full">
            <span className="label-text">Email</span>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="john@example.com"
              className="input input-bordered w-full"
            />
            {validationErrors.email && <p className="text-red-500 text-sm">{validationErrors.email}</p>}
          </label>

          <label className="form-control w-full">
            <span className="label-text">Password (Optional)</span>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
              className="input input-bordered w-full"
            />
          </label>

          <input type="hidden" value={role} readOnly />

          <label className="form-control w-full">
            <span className="label-text">Phone Number</span>
            <input
              type="tel"
              value={phone}
              onChange={(e) => {
                let value = e.target.value;
                value = value.replace(/[^\d+]/g, "");
                value = value.replace(/\+(?=.)/g, ""); // Remove '+' if not at beginning
                if (value.startsWith("+")) {
                  value = "+" + value.slice(1).replace(/\+/g, "");
                }
                setPhone(value);
              }}
              placeholder="+61412345678"
              className="input input-bordered w-full"
            />
            {validationErrors.phone && <p className="text-red-500 text-sm">{validationErrors.phone}</p>}
          </label>

          <label className="form-control w-full">
            <span className="label-text">Address</span>
            <input
              type="text"
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="123 High St, Brisbane"
              className="input input-bordered w-full"
            />
            {validationErrors.address && <p className="text-red-500 text-sm">{validationErrors.address}</p>}
          </label>

          <button type="submit" className="btn btn-success w-full mt-4" disabled={isUpdating}>
            {isUpdating ? (
              <span className="loading loading-spinner loading-sm"></span>
            ) : (
              <>
                <GrDocumentUpdate className="text-lg" />
                <span className="ml-2">Update</span>
              </>
            )}
          </button>
        </form>
      </div>
    </section>
  );
}

export default UserInformation;

