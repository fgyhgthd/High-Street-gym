import * as users from "../models/users.js";

/**
 * Authorisation middleware
 * 
 * @param {Array<string>} allowed_roles - list of roles allow to access this endpoint- list of roles allow to access this endpoint
 */
export default function api_auth(allowed_roles) {
    return function (req, res, next) {
        const auth_key = req.get("X-AUTH-KEY")
        
        if (auth_key) {

            users.getByAuthKey(auth_key)
                .then(user => {
                    if (allowed_roles.includes(user.user_role)) {
                        next()
                    } else {
                        res.status(403).json({
                            status: 403,
                            message: "Access forbidden."
                        })
                    }
                })
                .catch(error => {
                    res.status(401).json({
                        status: 401,
                        message: "auth key not found / not logged in."
                    })
                })
        } else {
            res.status(400).json({
                status: 400,
                message: "missing auth key."
            })
        }
    }
}