import * as users from "../models/users.mjs";

export default function api_auth(allowed_roles) {
    return function (req, res, next) {
        const auth_key = req.get("X-Auth-KEY");
        console.log("Auth Key:", auth_key); // Log the auth key

        if (auth_key) {
            users.getByAuthKey2(auth_key)
                .then(user => {
                    console.log("User:", user); // Log the user

                    // Normalize allowed roles and user role to prevent mismatches
                    const normalizedRoles = allowed_roles.map(role => role.toLowerCase().replace(/s$/, ''));
                    const userRole = user?.user_role.toLowerCase().replace(/s$/, '');

                    if (user && normalizedRoles.includes(userRole)) {
                        req.session.user = user; // Set the user in the session
                        next();
                    } else {
                        console.log("User role mismatch or unauthorized access:", userRole);
                        res.status(403).json({
                            status: "error",
                            message: "Access forbidden. You do not have permission to access this resource."
                        });
                    }
                })
                .catch(error => {
                    console.error("Error fetching user by auth key:", error);
                    res.status(401).json({
                        status: "error",
                        message: "Authentication failed. Invalid or missing auth key."
                    });
                });
        } else {
            console.log("Missing auth key in request headers.");
            res.status(400).json({
                status: "error",
                message: "Missing auth key."
            });
        }
    };
}

// Example usage
api_auth(['member', 'trainer', 'members']);
