export default function access_control(allowedRoles = []) {
  const handleResponse = (req, res, statusCode, statusMessage, errorMessage) => {
    const prefersJson = req.xhr || req.headers.accept?.includes("application/json");
    const responsePayload = { status: statusMessage, message: errorMessage };

    if (prefersJson) {
      return res.status(statusCode).json(responsePayload);
    } else {
      const page = statusCode === 401 ? "status_login.ejs" : "status.ejs";
      return res.status(statusCode).render(page, responsePayload);
    }
  };

  return function (req, res, next) {
    // Check if user is authenticated
    if (!req.session?.user) {
      return handleResponse(
        req, 
        res, 
        401, 
        "Not Authenticated", 
        "You are not logged in. Please log in to access this resource."
      );
    }

    // Check if user's role is authorized
    const userRole = req.session.user.role;
    if (Array.isArray(allowedRoles) && allowedRoles.includes(userRole)) {
      return next();
    }

    return handleResponse(
      req, 
      res, 
      403, 
      "Access Denied", 
      "You do not have permission to access this resource. Please contact customer service if you believe this is an error."
    );
  };
}
