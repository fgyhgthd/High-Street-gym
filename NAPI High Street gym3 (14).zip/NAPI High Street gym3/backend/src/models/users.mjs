import { DatabaseModel } from "./databaseModel.mjs";
import mysql from "mysql2/promise";

export class usersModels extends DatabaseModel {
  // Instance constructor
  constructor(id, email, password, role, phone, first_name, last_name, address, authenticationKey) {
    super();
    this.id = id;
    this.email = email;
    this.password = password;
    this.role = role;
    this.phone = phone;
    this.first_name = first_name;
    this.last_name = last_name;
    this.address = address;
    this.authenticationKey = authenticationKey
  }

  // Convert database row to User model
  static tableToModel(row) {
    // console.log("Raw Database Row:", row); // Debugging log
    const data = row.users || row; // Handle nested users object
    return new usersModels(
       Number( data["user_id"]),
      data["user_email"],
      data["user_password"],
      data["user_role"],
      data["user_phone"],
      data["user_first_name"],
      data["user_last_name"],
      data["user_address"],
      data["authentication_key"]
    );
  }

  // Get all users
  /** @returns {Promise<Array<users>>} */
  static getAll() {
    return this.query("SELECT * FROM users")
      .then(result => {
        // console.log("Query Result:", result);
        return result.map(row => this.tableToModel(row));
      })
      .catch(error => {
        console.error("Database Error in getAll:", error);
        throw error;
      });
  }
  /**
 * Retrieve a user by their authentication key.
 * 
 * @param {number} id 
 * @returns {Promise<usersModels>}getByauthenticationKey
 */
 

  static getByauthenticationKey(authenticationKey) {
    return this.query("SELECT * FROM users WHERE authentication_key = ? ", [authenticationKey])
        .then(result =>
            result.length > 0
                ? this.tableToModel(result[0].users)
                : Promise.reject("not found")
        )
}

  /**
   * @param   {number}  id  - the user ID
   * @return {Promise<users | null>}
   */
  static async getById(id) {
    return this.query(
      "SELECT * FROM users WHERE user_id = ?",
      [id]
    ).then(result => {
      // console.log("Query Result:", result); // Debugging log
      if (result.length > 0) {
        return this.tableToModel(result[0]); // Fix: Handle nested object
      }
      return null; // User not found
    }).catch(error => {
      console.error("Database Error in getById:", error);
      throw error;
    });
  }

  /**
   * @param {string} email
   * @returns {Promise<users | null>}
   */
static async getByemail(email) {
  return this.query(
    "SELECT * FROM users WHERE user_email = ?",
    [email]
  ).then(result =>
    result.length > 0
      ? this.tableToModel(result[0])
      : null
  );
}


  /**
   * @param {users} user
   * @returns {Promise<Array<users>>}
   */
  static async update(user) {
    console.log("Executing UPDATE with values:", [
      user.email,
      user.password,
      user.role,
      user.phone,
      user.first_name,
      user.last_name,
      user.address,
      user.authenticationKey, // ✅ Correct casing
      user.id,
    ]);
  
    return this.query(
      `UPDATE users SET
        user_email = ?,
        user_password = ?,
        user_role = ?,
        user_phone = ?,
        user_first_name = ?,
        user_last_name = ?,
        user_address = ?,
        authentication_key = ?
      WHERE user_id = ?`,
      [
        user.email,
        user.password,
        user.role,
        user.phone,
        user.first_name,
        user.last_name,
        user.address,
        user.authenticationKey, 
        user.id,
      ]
    ).catch(error => {
      console.error("Database Error in update:", error);
      throw error;
    });
  }
  

  /**
   *@param {users} user
   * @returns {Promise<mysql.OkPacket>}
   */
  static create(user) {
    if (!user.first_name || user.first_name.trim() === "") {
      throw new Error("First name is required and cannot be null.");
    }
  
    console.log("Executing INSERT with values:", [
      user.email,
      user.password,
      user.role,
      user.phone,
      user.first_name,
      user.last_name,
      user.address,
      user.authenticationKey // ✅ FIXED here
    ]);
  
    return this.query(
      `INSERT INTO users (user_email, user_password, user_role, user_phone, user_first_name, user_last_name, user_address, authentication_key)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        user.email,
        user.password,
        user.role,
        user.phone,
        user.first_name,
        user.last_name,
        user.address,
        user.authenticationKey // ✅ FIXED here
      ]
    ).catch(error => {
      console.error("Database Error in create:", error);
      throw error;
    });
  }
  

  /**
   * @param {number} id
   * @returns {Promise<mysql.OkPacket>}
   */
  static delete(id) {
    return this.query("DELETE FROM users WHERE user_id = ?", [id])
      .then(result => {
        console.log(`User with ID ${id} deleted successfully.`);
        return result;
      })
      .catch(error => {
        console.error("Database Error in delete:", error);
        throw error;
      });
  }
}

//Test getById
// const userIdToFetch = 130;   users.getById(userIdToFetch)
//    .then(user => {
//     if (user) {
//       console.log("User found:", user);
//     } else {
//      console.log(`No user found with ID ${userIdToFetch}.`);
//      }
//  })
//    .catch(error => console.error("Error fetching user:", error));
