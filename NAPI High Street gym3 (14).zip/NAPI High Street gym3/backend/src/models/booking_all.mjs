import { usersModels } from "./users.mjs";
import { LocationModel } from "./location.mjs";
import { activitiesModel } from "./activties.mjs";
import { sessionsModel } from "./sessions.mjs";
import { bookingsModel } from "./bookings.mjs";
import { DatabaseModel } from "./databaseModel.mjs";

export class BookingALLM extends DatabaseModel {
    constructor(users, location, activities, sessions, bookings, trainer_name, trainer_email) {
        super();
        this.user = users;
        this.location = location;
        this.activities = activities;
        this.sessions = sessions;
        this.bookings = bookings;
        this.trainer_name = trainer_name;
        this.trainer_email = trainer_email;
    }

    static tableToModel(row) {
    return new BookingALLM(
        usersModels.tableToModel(row.users),
        LocationModel.tableToModel(row.location),
        activitiesModel.tableToModel(row.activities),
        sessionsModel.tableToModel(row.sessions),
        bookingsModel.tableToModel(row.bookings),
        row.trainer_name ?? "N/A",
        row.trainer_email ?? "N/A"
    );
}



    static getAllBybookingsAll() {
        return this.query(`
            SELECT * FROM bookings
            INNER JOIN sessions ON bookings.Sessions_id = sessions.Sessions_id
            INNER JOIN users ON bookings.user_id = users.user_id
            INNER JOIN activities ON bookings.activity_id = activities.activity_id
            INNER JOIN location ON bookings.location_id = location.location_id
        `).then(result => result.map(row => this.tableToModel(row)));
    }

    static getAllBybookingAllid(bookingAllid) {
        return this.query(`
            SELECT * FROM bookings
            INNER JOIN sessions ON bookings.Sessions_id = sessions.Sessions_id
            INNER JOIN users ON bookings.user_id = users.user_id
            INNER JOIN activities ON bookings.activity_id = activities.activity_id
            INNER JOIN location ON bookings.location_id = location.location_id
            WHERE bookings.booking_id = ?
        `, [bookingAllid])
        .then(result => result.length > 0 ? this.tableToModel(result[0]) : Promise.reject("Not found"));
    }

    static getAllBybookingsUsers(userID) {
        return this.query(`
            SELECT * FROM bookings
            INNER JOIN sessions ON bookings.Sessions_id = sessions.Sessions_id
            INNER JOIN users ON bookings.user_id = users.user_id
            INNER JOIN activities ON bookings.activity_id = activities.activity_id
            INNER JOIN location ON bookings.location_id = location.location_id
            WHERE bookings.user_id = ?
        `, [userID]).then(result => result.map(row => this.tableToModel(row)));
    }

    static getBySearch(searchTerm) {
        return this.query(`
            SELECT * FROM bookings
            INNER JOIN sessions ON bookings.Sessions_id = sessions.Sessions_id
            INNER JOIN users ON bookings.user_id = users.user_id
            INNER JOIN activities ON bookings.activity_id = activities.activity_id
            INNER JOIN location ON bookings.location_id = location.location_id
            WHERE users.user_first_name LIKE ?
        `, [`%${searchTerm}%`])
        .then(result => result.length > 0 ? result.map(row => this.tableToModel(row)) : Promise.reject("Not found"));
    }

  static getAllByUserID(UserID) {
    return this.query(`
        SELECT 
            bookings.*,
            sessions.*,
            users.*,
            activities.*,
            location.*,
            trainer.user_first_name AS trainer_first_name,
            trainer.user_last_name AS trainer_last_name,
            trainer.user_email AS trainer_email
        FROM bookings
        INNER JOIN sessions ON bookings.Sessions_id = sessions.Sessions_id
        INNER JOIN users ON bookings.user_id = users.user_id
        INNER JOIN activities ON bookings.activity_id = activities.activity_id
        INNER JOIN location ON bookings.location_id = location.location_id
        INNER JOIN users AS trainer ON sessions.trainer_user_id = trainer.user_id
        WHERE bookings.user_id = ?
    `, [UserID])
    .then(result => {
        console.log("✅ SQL result[0]:", result[0]); // Optional debug
        return result.map(row => {
            // ✅ Pull trainer data from nested object
            const trainerData = row.trainer ?? {};
            row.trainer_name = `${trainerData.trainer_first_name ?? ""} ${trainerData.trainer_last_name ?? ""}`.trim();
            row.trainer_email = trainerData.trainer_email ?? "N/A";

            return this.tableToModel(row);
        });
    });
}

}


