import express from "express";
import session from "express-session";
import cors from "cors";

import { userController } from "./controllers/users.mjs";
import { postController } from "./controllers/blog_post.mjs";
import { ActivityController } from "./controllers/activties.mjs";
import { BookingController } from "./controllers/booking.mjs";
import { locationController } from "./controllers/loctaion.mjs";
import { SessionController } from "./controllers/sessions.mjs";
import { AuthenticationController } from "./controllers/Authentication.mjs";
import { APIController } from "./controllers/API/ApiController.mjs";
import { ApiauthenticationController } from "./controllers/API/APIAuthenticationController.mjs"; // ✅ Added

const app = express();
const port = 8080;

// Enable CORS
app.use(cors({ origin: true, credentials: true }));

// Body parsers
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Debug middleware
app.use((req, res, next) => {
    console.log("Incoming Request:", {
        method: req.method,
        url: req.url,
        headers: req.headers,
        body: req.body,
    });
    next();
});

// Authentication middleware for non-API routes
app.use(AuthenticationController.middleware);

// ✅ Authentication middleware for API routes
app.use(ApiauthenticationController.middleware);

// App routes
app.use(userController.routes);
app.use(postController.routes);
app.use(ActivityController.routes);
app.use(BookingController.routes);
app.use(locationController.routes);
app.use(SessionController.routes);
app.use(AuthenticationController.routes);
app.use("/api", APIController.routes);

// View engine setup
app.set("view engine", "ejs");
app.set("views", "./src/views");

// Static files
app.use(express.static("src/static"));
app.use(express.static("dict/css"));

// Default route
app.get("/", (req, res) => res.render("login.ejs", {}));

// 404 handler
app.use((req, res) => {
    res.status(404).json({ message: "Route not found" });
});

// Start server
app.listen(port, () => {
    console.log(`Express server running at: http://localhost:${port}`);
});
