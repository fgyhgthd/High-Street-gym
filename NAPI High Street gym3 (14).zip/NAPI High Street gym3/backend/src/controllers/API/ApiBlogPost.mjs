import express from "express";
import { Blog } from "../../models/bolg_post.mjs";
import { ApiauthenticationController } from "./APIAuthenticationController.mjs";

export class APIpostController {
    static routes = express.Router();

    static {
        //  Apply authentication middleware to all blog routes
        this.routes.use(ApiauthenticationController.middleware);

        // Public blog routes
        this.routes.post("/", ApiauthenticationController.restrict(["members"]), this.createBlog);
        this.routes.get("/", this.viewAllPosts);
        this.routes.get("/:id", ApiauthenticationController.restrict(["members"]), this.getPostById);

        //  Protected routes: only members and managers can update/delete
        this.routes.put(
            "/:id",
            ApiauthenticationController.restrict(["members", "manager"]),
            this.updatePost
        );
        this.routes.delete(
            "/:id",
            ApiauthenticationController.restrict(["members", "manager"]),
            this.deletePost
        );
    }

    /**
     * @openapi
     * /api/blog:
     *   post:
     *     summary: Create a new blog post
     *     tags: [Blog Posts]
     *     security:
     *       - ApiKey: []
     *     requestBody:
     *       required: true
     *       content:
     *         application/json:
     *           schema:
     *              $ref: "#/components/schemas/BlogPost"
     *     responses:
     *       200:
     *         $ref: "#/components/responses/Created"
     *       403:
 *              $ref: "#/components/responses/Forbidden" 
     *       500:
     *         $ref: "#/components/responses/Error"
     */
    static async createBlog(req, res) {
        try {
            const loggedInUserId = req.authenticatedUser?.id;

            //  Ensure the post is created only for the authenticated user
            if (String(req.body.post_user_id) !== String(loggedInUserId)) {
                return res.status(403).json({
                    message: "You are not authorized to create a post for another user",
                    errors: ["You can only create posts for your own account"]
                });
            }

            const post = new Blog(
                null, // post_id should be null for new post
                new Date().toISOString().slice(0, 19).replace("T", " "),
                loggedInUserId,
                req.body.post_title,
                req.body.post_content
            );

            const result = await Blog.create(post);
            res.status(200).json({ id: result.insertId, message: "Post created" });
        } catch (error) {
            console.error(error);
            res.status(500).json({ message: "Failed to create post", errors: [error.message] });
        }
    }


    /**
     * @openapi
     * /api/blog/:
     *   get:
     *     summary: View all blog posts
     *     tags: [Blog Posts]
     *     responses:
     *       200:
     *         description: A list of blog posts
     *         content:
     *           application/json:
     *             schema:
     *               type: array
     *               items:
     *                 $ref: "#/components/schemas/BlogPost"
     *       500:
     *         $ref: "#/components/responses/Error"
     */
    static async viewAllPosts(req, res) {
        try {
            const posts = await Blog.getAll();
            const formattedPosts = posts.map(post => ({
                ...post,
                post_user_id: String(post.post_user_id),
                post_id: Number(post.post_id),
            }));
            res.status(200).json(formattedPosts);
        } catch (error) {
            console.error(error);
            res.status(500).json({ message: "Failed to load posts from database" });
        }
    }

    /**
     * @openapi
     * /api/blog/{id}:
     *   get:
     *     summary: Get a blog post by ID
     *     tags: [Blog Posts]
     *     security:
     *      - ApiKey: [] 
     *     parameters:
     *       - name: id
     *         in: path
     *         required: true
     *         schema:
     *           type: string
     *     responses:
     *       200:
     *         description: Blog post found
     *         content:
     *           application/json:
     *             schema:
     *               $ref: "#/components/schemas/BlogPost"
     *       404:
     *          $ref: "#/components/responses/NotFound"
     * 
     *       500:
     *         
     *          $ref: "#/components/responses/Error"
     */
    static async getPostById(req, res) {
        try {
            const post = await Blog.getById(req.params.id);
            if (!post) {
                return res.status(404).json({ message: "Post not found" });
            }
            res.status(200).json({
                ...post,
                post_datetime: new Date(post.post_datetime).toISOString().slice(0, 19).replace("T", " "),
                post_user_id: String(post.post_user_id),
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({ message: "Failed to load post from database" });
        }
    }


    /**
     * @openapi
     * /api/blog/{id}:
     *   put:
     *     summary: Update a blog post
     *     tags: [Blog Posts]
     *     security:
     *       - ApiKey: []
     *     parameters:
     *       - name: id
     *         in: path
     *         required: true
     *         schema:
     *           type: string
     *     requestBody:
     *       required: true
     *       content:
     *         application/json:
     *           schema:
     *             type: object
     *             properties:
     *               post_user_id:
     *                 type: string
     *               post_title:
     *                 type: string
     *               post_content:
     *                 type: string
     *     responses:
     *       200:
     *         $ref: "#/components/responses/Updated"
     *       403:
     *         $ref: "#/components/responses/Forbidden"
     *       404:
     *          $ref: "#/components/responses/NotFound"
     *        
     *       500:
     *         $ref: "#/components/responses/Error"
     */
    static async updatePost(req, res) {
        try {
            const postId = req.params.id;
            const loggedInUserId = req.authenticatedUser?.id;

            if (!req.body.post_user_id) {
                return res.status(400).json({
                    message: "post_user_id is required",
                    errors: ["Missing post_user_id"]
                });
            }

            if (String(req.body.post_user_id) !== String(loggedInUserId)) {
                return res.status(403).json({
                    message: "You are not authorized to create or update this post for another user",
                    errors: ["You can only update/create your own posts"]
                });
            }

            const existingPost = await Blog.getById(postId);

            const postData = {
                post_id: postId,
                post_user_id: req.body.post_user_id,
                post_title: req.body.post_title,
                post_content: req.body.post_content,
                post_datetime: new Date().toISOString().slice(0, 19).replace("T", " ")
            };


            if (existingPost) {
                // Authorization check for update
                if (String(existingPost.post_user_id) !== String(loggedInUserId)) {
                    return res.status(403).json({
                        message: "You are not authorized to edit this post",
                        errors: ["Only the original author can edit this post"]
                    });
                }
                //  This check if the database dose or dose not have the post id.
                //  if it dose exists than it will update the post to the new content  information. 
                //  if it does  not exists then it will create a new post with that id.

                //  update post 
                const result = await Blog.update(postData);
                if (result.affectedRows === 1) {
                    return res.status(200).json({ message: "Resource updated successfully" });
                } else {
                    return res.status(500).json({
                        message: "Post update failed",
                        errors: ["No rows were affected"]
                    });
                }
            } else {

                //  create post  
                const result = await Blog.create(postData, true);
                return res.status(200).json({
                    message: "Resource created as the ID did not exists.",
                    id: result.insertId || postId
                });
            }

        } catch (error) {
            console.error(error);
            res.status(500).json({
                message: "Failed to update or create post",
                errors: [error.message]
            });
        }
    }


    /**
 * @openapi
 * /api/blog/{id}:
 *   delete:
 *     summary: Delete a blog post
 *     tags: [Blog Posts]
 *     security:
 *       - ApiKey: []
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         $ref: "#/components/responses/PostDeleted"
 *       403:
 *         $ref: "#/components/responses/Forbidden"
 *       404:
 *         $ref: "#/components/responses/NotFound"
 *       500:
 *         $ref: "#/components/responses/Error"
 */
    static async deletePost(req, res) {
        try {
            const postId = req.params.id;
            const post = await Blog.getById(postId);

            // Return 404 if post doesn't exist
            if (!post) {
                return res.status(404).json({
                    message: "Post not found",
                    errors: ["No post found with the provided ID"]
                });
            }

            // Check ownership
            if (String(post.post_user_id) !== String(req.authenticatedUser.id)) {
                return res.status(403).json({
                    message: "You are not authorized to delete this post",
                    errors: ["Only the original author can delete this post."]
                });
            }

            const result = await Blog.deleteById(postId);

            if (result.affectedRows === 1) {
                return res.status(200).json({
                    message: "Post deleted successfully",
                    deleted_post_id: postId
                });
            } else {
                // Should rarely hit this if post exists, but handle it
                return res.status(500).json({
                    message: "Post deletion failed",
                    errors: ["Deletion affected no rows"]
                });
            }

        } catch (error) {
            console.error("Delete post error:", error);
            return res.status(500).json({ message: "Server error", errors: [error.message] });
        }
    }

}




