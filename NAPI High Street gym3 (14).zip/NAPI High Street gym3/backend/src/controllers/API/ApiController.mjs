import express from "express";
import swaggerJSDoc from "swagger-jsdoc";
import swaggerUI from "swagger-ui-express";
import { APIbookingController } from "./ApiBookings.mjs";
import { APIpostController } from "./ApiBlogPost.mjs";
import * as ApiValidator from "express-openapi-validator";
import { APIsessionsController } from "./ApiSessions.mjs";
import { APIUsersController } from "./AipUsers.mjs"; 
import { ApiauthenticationController } from "./APIAuthenticationController.mjs";

// Swagger/OpenAPI specification options
const options = {
  failOnErrors: true,
  definition: {
    openapi: "3.0.0",
    info: {
      version: "1.0.0",
      title: "High Street Gym API",
      description: "JSON REST API for interacting with the High Street Gym backend",
    },
    components: {
      securitySchemes: {
        ApiKey: {
          type: "apiKey",
          in: "header",
          name: "x-auth-key",
        },
      },
    },
  },
  apis: ["./src/controllers/API/*.mjs", "./src/components.yaml"], // ensure paths are correct
};

const specification = swaggerJSDoc(options);


export class APIController {
  static routes = express.Router();

  static {
    //  Swagger API Documentation
    /**
     * @openapi
     * /api/docs:
     *   get:
     *     summary: View automatically generated API documentation
     *     tags:
     *       - documentation
     *     responses:
     *       200:
     *         description: Swagger documentation page
     */
    this.routes.use("/docs", swaggerUI.serve, swaggerUI.setup(specification));

    // OpenAPI Request/Response Validation Middleware
    this.routes.use(
      ApiValidator.middleware({
        apiSpec: specification,
        validateRequests: true,
        validateResponses: true,
      })
    );

    //  Centralized Error Handling Middleware
    this.routes.use((err, req, res, next) => {
      res.status(err.status || 500).json({
        message: err.message,
        errors: err.errors,
      });
    });

    //  Authentication Middleware (Runs for all endpoints after this)
    this.routes.use(ApiauthenticationController.middleware);
    this.routes.use(ApiauthenticationController.routes);

    //  Mount Resource Endpoints
    this.routes.use("/bookings", APIbookingController.routes);
    this.routes.use("/blog", APIpostController.routes);
    this.routes.use("/sessions", APIsessionsController.routes);
    this.routes.use("/users", APIUsersController.routes);
  }
}
