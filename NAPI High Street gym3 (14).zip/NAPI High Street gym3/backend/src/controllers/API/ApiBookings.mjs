import express from "express";
import { bookingsModel } from "../../models/bookings.mjs";
import { BookingALLM } from "../../models/booking_all.mjs";
import { ApiauthenticationController } from "./APIAuthenticationController.mjs";

export class APIbookingController {
    static routes = express.Router();

    static {
        this.routes.post("/", ApiauthenticationController.restrict("members"), this.createBooking);
    
        this.routes.get("/xml", ApiauthenticationController.restrict("members"), this.getmembersBookingXML);
         this.routes.get("/", ApiauthenticationController.restrict("members"), this.getUserinfoBookingByID);
        this.routes.delete("/:id", ApiauthenticationController.restrict("members"), this.DeleteBooking);
    }

    /**
     * @type {express.RequestHandler}
     * @openapi
     * /api/bookings:
     *   post:
     *     summary: Create a new booking
     *     tags: [Bookings]
     *     security:
     *       - ApiKey: []
     *     requestBody:
     *       required: true
     *       content:
     *         application/json:
     *           schema:
     *             $ref: '#/components/schemas/BookingSessionRequest'
     *     responses:
     *       200:
     *         $ref: "#/components/responses/Created"
     *       400:
     *         $ref: '#/components/responses/BadRequest'
     *       403:
     *         $ref: '#/components/responses/Forbidden'
     *       500:
     *         $ref: '#/components/responses/Error'
     */
    static async createBooking(req, res) {
    try {
        const { user_id, Sessions_id, activity_id, location_id } = req.body;

        const loggedInUserId = req.user?.id;
        const userRole = req.user?.role;

        // 🔒 Authorization: prevent users from booking for others unless admin
        if (!loggedInUserId || (loggedInUserId.toString() !== user_id.toString() && userRole !== "admin")) {
            return res.status(403).json({
                message: "Forbidden: You cannot create bookings for other users",
                errors: ["User not authorized to book for this ID"]
            });
        }

        const missingFields = [];
        if (!user_id) missingFields.push("user_id");
        if (!Sessions_id) missingFields.push("Sessions_id");
        if (!activity_id) missingFields.push("activity_id");
        if (!location_id) missingFields.push("location_id");

        if (missingFields.length > 0) {
            return res.status(400).json({
                message: "Missing required booking fields",
                errors: missingFields.map(f => `Missing field: ${f}`)
            });
        }

        const existing = await bookingsModel.getByUserAndClass(user_id, Sessions_id);
        if (existing && existing.length > 0) {
            return res.status(400).json({
                message: "You already have a booking for this session",
                errors: ["Duplicate booking attempt"]
            });
        }

        const booking = new bookingsModel(
            null,
            user_id,
            Sessions_id,
            new Date().toISOString().slice(0, 19).replace("T", " "),
            activity_id,
            location_id
        );

        const result = await bookingsModel.create(booking);

        res.status(200).json({
            id: result.insertId,
            message: "Booking created"
        });
    } catch (error) {
        console.error("Booking creation error:", error.message, error.stack);
        res.status(500).json({
            message: "Failed to create booking",
            errors: [error.message || "Unknown server error"]
        });
    }
}


    
/**
 * @type {express.RequestHandler}
 * @openapi
 * /api/bookings/:
 *   get:
 *     summary: Get logged-in user's bookings
 *     tags: [Bookings]
 *     security:
 *       - ApiKey: []
 *     responses:
 *       200:
 *         description: A list of the user's bookings (can be empty)
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: '#/components/schemas/BookingSessionRequest'
 *       403:
 *         $ref: "#/components/responses/Forbidden"
 *       404: 
 *         $ref: "#/components/responses/NotFound"
 *       500:
 *         $ref: '#/components/responses/Error'
 */


static async getUserinfoBookingByID(req, res) {
  try {
    const userId = req.user?.id;
    console.log("Logged-in user:", req.user);

    if (!userId) {
      return res.status(403).json({
        message: "Unauthorized",
        errors: ["User must be logged in"],
      });
    }

    const rawBookings = await BookingALLM.getAllByUserID(userId);
    console.log("Raw bookings:", rawBookings);

    if (!rawBookings || rawBookings.length === 0) {
      return res.status(404).json({
        message: "No booking found",
      });
    }

    const bookings = rawBookings.map(b => ({
      booking_id: b.bookings?.id ?? null,
      user_id: b.user?.id ?? null,
      Sessions_id: b.sessions?.Sessions_id ?? null,
      booking_created_datetime: b.bookings?.booking_created_datetime ?? null,
      activity_id: b.activities?.activity_id ?? null,
      location_id: b.location?.id ?? null,

      trainer: {
        name: b.trainer_name ?? "N/A",
        email: b.trainer_email ?? "N/A",
      },

      activity_name: b.activities?.activity_name ?? "N/A",
      location_name: b.location?.name ?? "N/A",
      session_datetime: b.sessions?.Sessions_datetime ?? "N/A"
    }));

    res.status(200).json(bookings);
  } catch (error) {
    console.error("Error in getUserinfoBookingByID:", error);
    res.status(500).json({
      message: "Failed to load Bookings from database",
      errors: [error.message],
    });
  }
}




/**
 * @type {express.RequestHandler}
 * @openapi
 * /api/bookings/{id}:
 *   delete:
 *     summary: Delete a booking (only allowed by the booking owner)
 *     tags: [Bookings]
 *     security:
 *       - ApiKey: []
 *     parameters:
 *       - name: id
 *         in: path
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       200:
 *         description: Booking deleted
 *         content:
 *           application/json:
 *             schema:
 *              $ref: '#/components/responses/BookingDeleted'
 *       400:
 *         $ref: '#/components/responses/BadRequest'
 *       403:
 *         $ref: "#/components/responses/Forbidden"
 *       404:
 *         $ref: "#/components/responses/NotFound"
 *       500:
 *         $ref: '#/components/responses/Error'
 */
static async DeleteBooking(req, res) {
    const id = Number(req.params.id);
    const user = req.user || req.authenticatedUser; // fallback in case req.user is undefined
    const userId = user?.id;

    if (isNaN(id)) {
        return res.status(400).json({
            message: "Invalid booking ID",
            errors: ["Booking ID must be a valid number"],
        });
    }

    try {
        const booking = await bookingsModel.findById(id);
        console.log("Full booking object:", booking);

        if (!booking) {
            return res.status(404).json({
                message: "Booking not found - delete failed",
                errors: ["Booking not found"],
            });
        }

        console.log("Booking user_id:", booking.user_id, "Authenticated user id:", userId);

        if (String(booking.user_id) !== String(userId)) {
            return res.status(403).json({
                message: "You are not authorized to delete this booking",
                errors: ["Not the owner of this booking"],
            });
        }

        const result = await bookingsModel.deleteById(id);

        if (result.affectedRows === 1) {
            res.status(200).json({
                message: "Booking deleted",
                booking: {
                    id: booking.id,
                    user_id: booking.user_id,
                    Sessions_id: booking.Sessions_id,
                    booking_created_datetime: booking.booking_created_datetime,
                    activity_id: booking.activity_id,
                    location_id: booking.location_id,
                },
                errors: [] //  Required by OpenAPI response schema
            });
        } else {
            res.status(404).json({
                message: "Booking not found - delete failed",
                errors: ["Booking not deleted"],
            });
        }
    } catch (error) {
        console.error("Delete booking error:", error.message);
        res.status(500).json({
            message: "Failed to delete booking - database error",
            errors: [error.message],
        });
    }
}



/**
 * @type {express.RequestHandler}
 * @openapi
 * /api/bookings/xml:
 *   get:
 *     summary: Export member bookings to XML
 *     tags:
 *       - Bookings
 *     security:
 *       - ApiKey: []
 *     parameters:
 *       - in: query
 *         name: user_id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       '200':
 *         description: Member's booking history in XML format
 *         content:
 *           text/xml:
 *             schema:
 *               type: object
 *               xml:
 *                 name: MemberBookingHistory
 *                 attribute: true
 *               properties:
 *                 Booking:
 *                   type: array
 *                   xml:
 *                     name: Booking
 *                     wrapped: false
 *                   items:
 *                     type: object
 *                     properties:
 *                       BookingID:
 *                         type: string
 *                         example: "14"
 *                       BookingDateTime:
 *                         type: string
 *                         example: "2024-05-01T10:00:00Z"
 *                       activityName:
 *                         type: string
 *                         example: "Yoga"
 *                       activityDescription:
 *                         type: string
 *                         example: "Yoga is an ancient practice."
 *                       activityDuration:
 *                         type: string
 *                         example: "1 Hour"
 *                       SessionsDateTime:
 *                         type: string
 *                         example: "2024-05-01T10:30:00Z"
 *                       location:
 *                         type: string
 *                         example: "South Bank"
 *       400:
 *         $ref: '#/components/responses/BadRequest'
 *       403:
 *         $ref: '#/components/responses/Forbidden'
 *       401:
 *         $ref: '#/components/responses/NotFound'
 *       500:
 *         $ref: '#/components/responses/Error'
 */


static async getmembersBookingXML(req, res) {
  const requestedUserId = req.query.user_id;
  const loggedInUserId = req.user?.id;

  if (!requestedUserId) {
    return res.status(400).json({ message: "Missing required query parameter: user_id" });
  }

  if (!loggedInUserId || loggedInUserId.toString() !== requestedUserId.toString()) {
    return res.status(403).json({
      message: "Forbidden: You are not allowed to access another user's booking data",
      errors: ["Access denied"],
    });
  }

  try {
    const memberbookings = await BookingALLM.getAllByUserID(requestedUserId);

    if (!memberbookings || memberbookings.length === 0) {
      return res.status(404).json({
        message: "No bookings found for this user",
        errors: ["No booking data available for export"]
      });
    }

    // Extract first and last name safely
    const userFirstName = memberbookings[0]?.user?.first_name || "Unknown first Name";
    const userLastName = memberbookings[0]?.user?.last_name || "Unknown Last Name";
    const exportDate = new Date().toISOString().split("T")[0];

    // Render XML with all required data
    res.status(200).render("xml/mambers.xml.ejs", {
      memberbookings,
      userFirstName,
      userLastName,
      exportDate
    });
  } catch (error) {
    console.error("Export XML error:", error.message);
    res.status(500).json({
      message: "Failed to export XML for members",
      errors: [error.message],
    });
  }
}
}