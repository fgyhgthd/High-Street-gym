import express from "express";
import bcrypt from "bcrypt";
import { usersModels } from "../../models/users.mjs";
import { ApiauthenticationController } from "./APIAuthenticationController.mjs";

export class APIUsersController {
    static routes = express.Router();

    static {
        this.routes.post("/", this.createNewMembers);
        this.routes.patch ("/:id",
            // members must be able to do as  wall 
            ApiauthenticationController.restrict("any"),
            this.personalInformation
        );
        
        
        this.routes.get("/self",
            ApiauthenticationController.restrict("any"),
            this.getAuthenticatedUser
        )
        this.routes.get("/:id", 
            //   the acces for this is or two surs  
            ApiauthenticationController.restrict("any") ,this.getUserById);
       
    }
 
    /**
     * Register a new  user 
     * @type {express.RequestHandler}
     * @openapi
     * /api/users:
     *   post:
     *     summary: "Register a new  user"
     *     tags: [Users]
     *    
     *     requestBody:
     *       required: true
     *       content:
     *         application/json:
     *           schema:
     *             $ref: "#/components/schemas/User"
     *     responses:
     *       200:
     *         $ref: "#/components/responses/Created"
     *       500:
     *         $ref: "#/components/responses/Error"
     */
    static async createNewMembers(req, res) {
        try {
            const role = "members";

            const saltRounds = 10;
            const hashedPassword = await bcrypt.hash(req.body.password, saltRounds);

            const user = {
                ...req.body,
                password: hashedPassword,
                role
            };

            const result = await usersModels.create(user);

            res.status(200).json({
                id: result.insertId,
                message: "Member created"
            });
        } catch (error) {
            console.error(error);
            res.status(500).json({
                message: "Failed to create member",
                errors: [error.message || error]
            });
        }
    }

    /**
     * Get user by ID
     * @type {express.RequestHandler}
     * @openapi
     * /api/users/{id}:
     *   get:
     *     summary: "Get user by ID"
     *     tags: [Users]
     *     security:
     *       - ApiKey: []
     *     parameters:
     *       - in: path
     *         name: id
     *         required: true
     *         schema:
     *           type: string
     *     responses:
     *       200:
     *         $ref: "#/components/responses/UserFound"
     *       404:
     *          $ref: "#/components/responses/NotFound"
     *       403:
     *        $ref: "#/components/responses/Forbidden"    
     *       500:
     *         $ref: "#/components/responses/Error"
     */
    static async getUserById(req, res) {
    try {
        const requestedId = parseInt(req.params.id);
        const authenticatedUser = req.authenticatedUser;

        // Only allow access if the user is the owner or an admin
        if (
            !authenticatedUser ||
            (authenticatedUser.id !== requestedId && authenticatedUser.role !== "admin")
        ) {
            return res.status(403).json({
                message: "Forbidden: You are not allowed to access this user's data",
                errors: ["Forbidden"]
            });
        }

        const user = await usersModels.getById(requestedId);
        if (!user) {
            return res.status(404).json({ message: "User not found" });
        }

        res.status(200).json(user);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Failed to load user from database" });
    }
}

 /**
 * Update personal information
 * @type {express.RequestHandler}
 * @openapi
 * /api/users/{id}:
 *    patch :
 *     summary: "Update user information"
 *     tags: [Users]
 *     security:
 *       - ApiKey: []
 *     parameters:
 *       - in: path
 *         name: id
 *         required: true
 *         schema:
 *           type: string
 *     requestBody:
 *       required: true
 *       content:
 *         application/json:
 *           schema:
 *             $ref: "#/components/schemas/User"
 *     responses:
 *       200:
 *         $ref: "#/components/responses/Updated"
 *       403:
 *         $ref: "#/components/responses/Forbidden"
          
 *       404:
 *         $ref: "#/components/responses/UserFound"
 *       500:
 *         $ref: "#/components/responses/Error"
 */

 static async personalInformation(req, res) {
    try {
        const authenticatedUser = req.authenticatedUser;
        const targetUserId = parseInt(req.params.id);

        // Only allow users to update their own info
        if (authenticatedUser.id !== targetUserId) {
            return res.status(403).json({
                message: "You are not allowed to update this user.",
                errors: ["Forbidden"],
            });
        }

        const user = {
            ...req.body,
            
            authenticationKey: authenticatedUser.authenticationKey,
            id: req.params.id,
        };

        if (user.password) {
            const saltRounds = 10;
            user.password = await bcrypt.hash(user.password, saltRounds);
        }

        const result = await usersModels.update(user);
        if (result.affectedRows === 1) {
            res.status(200).json({ message: "User updated" });
        } else {
            res.status(404).json({
                message: "User not found - update failed",
                errors: ["Not found", "Update failed"],
            });
        }
    } catch (error) {
        console.error(error);
        res.status(500).json({
            message: "Failed to update user",
            errors: [error.message || error],
        });
    }
}



/**
 * Get authenticated user
 * @type {express.RequestHandler}
 * @openapi
 * /api/users/self:
 *   get:
 *     summary: "Get current authenticated user"
 *     tags: [Users]
 *     security:
 *       - ApiKey: []
 *     responses:
 *       200:
 *         description: Authenticated user info
 *         content:
 *           application/json:
 *             schema:
 *               $ref: "#/components/schemas/User"
 *       default:
 *        $ref: "#/components/responses/Error"
 */


     static async getAuthenticatedUser(req,res){
        res.status(200).json(req.authenticatedUser)
        

     }
}