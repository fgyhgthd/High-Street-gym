import express from "express"
import { usersModels } from "../../models/users.mjs"
import bcrypt from "bcryptjs"
import crypto from "crypto"

export class ApiauthenticationController {
    static middleware = express.Router()
    static routes = express.Router()

    static {
        this.middleware.use(this.#APIAuthenticationProvider)
        this.routes.post("/authenticate", this.handleAuthenticate)
        this.routes.delete("/authenticate", this.handleAuthenticate)
    }

    static async #APIAuthenticationProvider(req, res, next) {
        const authenticationKey = req.headers["x-auth-key"]
        if (authenticationKey) {
            try {
                req.authenticatedUser = await usersModels.getByauthenticationKey(authenticationKey)
                req.user = req.authenticatedUser
                console.log("Authenticated user:", req.authenticatedUser)
            } catch (error) {
                if (error == "not found") {
                    res.status(404).json({
                        message: "Failed to authenticate - key not found",
                        errors: ["Authentication key not found"]
                    })
                } else {
                    console.error(error)
                    res.status(500).json({
                        message: "Failed to authenticate - database error",
                        errors: ["A database error occurred while validating authentication key"]
                    })
                }
                return
            }
        }
        next()
    }

    /**
     * @type {express.RequestHandler}
     * @openapi
     * /api/authenticate:
     *     post:
     *         summary: "Authenticate with email and password"
     *         tags: [Authentication]
     *         requestBody:
     *             required: true
     *             content:
     *                 application/json:
     *                     schema:
     *                         $ref: "#/components/schemas/UserLogin"
     *         responses:
     *             '200':
     *                 $ref: "#/components/responses/LoginSuccessful"
     *             '400':
     *                 $ref: "#/components/responses/Error"
     *             '500':
     *                 $ref: "#/components/responses/Error"
     *             403:
     *              $ref: "#/components/responses/Forbidden"
     *     delete:
     *         summary: "Deauthenticate with API key header"
     *         tags: [Authentication]
     *         security:
     *             - ApiKey: []
     *         responses:
     *             '200':
     *                 $ref: "#/components/responses/Updated"
     *             default:
     *                 $ref: "#/components/responses/Error"
     */
    static async handleAuthenticate(req, res) {
    if (req.method == "POST") {
        try {
            const user = await usersModels.getByemail(req.body.email);

            // ✅ Check if user was found
            if (!user) {
                return res.status(400).json({
                    message: "Invalid credentials",
                    errors: ["The email or password is incorrect"]
                });
            }

            // ✅ Safe to access user.role now
            if (user.role === "manager") {
                return res.status(403).json({
                    message: "Access denied",
                    errors: ["Managers are not allowed to log in through this system."]
                });
            }

            if (await bcrypt.compare(req.body.password, user.password)) {
                const authenticationKey = crypto.randomUUID();
                user.authenticationKey = authenticationKey;
                await usersModels.update(user);

                res.status(200).json({
                    key: authenticationKey
                });
            } else {
                res.status(400).json({
                    message: "Invalid credentials",
                    errors: ["The email or password is incorrect"]
                });
            }
        } catch (error) {
            console.error(error);
            res.status(500).json({
                message: "Failed to authenticate user",
                errors: ["A database or internal error occurred"]
            });
        }
    } else if (req.method == "DELETE") {
        if (req.authenticatedUser) {
            const users = await usersModels.getByauthenticationKey(req.authenticatedUser.authenticationKey);
            users.authenticationKey = null;
            await usersModels.update(users);

            res.status(200).json({
                message: "Deauthentication successful"
            });
        } else {
            res.status(401).json({
                message: "Please login to access the requested resources",
                errors: ["Missing or invalid authentication key"]
            });
        }
    }
}


    /**
     * @param {Array<"members"|"manager"|"trainer">| "any"} allowedRoles 
     * @returns {express.RequestHandler}
     */
    static restrict(allowedRoles) {
        return function (req, res, next) {
            if (req.authenticatedUser) {
                if (allowedRoles == "any" || allowedRoles.includes(req.authenticatedUser.role)) {
                    next()
                } else {
                    res.status(403).json({
                        message: "Access forbidden",
                        errors: ["Role does not have access to the requested resource"]
                    })
                }
            } else {
                res.status(401).json({
                    message: "Not authenticated",
                    errors: ["Please authenticate to access the requested resource"]
                })
            }
        }
    }
}
