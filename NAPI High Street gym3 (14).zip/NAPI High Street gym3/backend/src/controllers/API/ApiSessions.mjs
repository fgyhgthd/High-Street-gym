import express from "express"
import { SessionsActivityUserLocationM } from "../../models/sessions_activity.mjs";
import { sessionsModel } from "../../models/sessions.mjs";
import { ApiauthenticationController } from "./APIAuthenticationController.mjs";

export class APIsessionsController {
  static routes = express.Router()

  static {
    this.routes.use(ApiauthenticationController.middleware);

    this.routes.get("/",ApiauthenticationController.restrict(["members"]), this.viewSssions);
    this.routes.get("/xml", ApiauthenticationController.restrict(["trainer"]),this.getsessionXML);
    this.routes.get("/trainer/me", ApiauthenticationController.restrict(["trainer"]), this.getTranerSessionByID);
    this.routes.delete("/:id", ApiauthenticationController.restrict(["trainer"]), this.deleteSessionsTraner);
  }

  static sendError(res, statusCode, message, errors = []) {
    return res.status(statusCode).json({ message, errors });
  }

/**
 * @openapi
 * /api/sessions/:
 *   get:
 *     summary: View all sessions available in the current week
 *     tags:
 *       - Sessions
 *     security:
 *       - ApiKey: []
 *     responses:
 *       200:
 *         description: List of available sessions
 *         content:
 *           application/json:
 *             schema:
 *               type: array
 *               items:
 *                 $ref: "#/components/schemas/SessionResponse"
 *       403:
 *         $ref: "#/components/responses/Forbidden"
 *       404:
 *         $ref: "#/components/responses/NotFound"
 *       500:
 *         $ref: "#/components/responses/Error"
 */

static async viewSssions(req, res) {
  try {
    const userRole = req.user?.role;

    // Optional role check – adjust logic as needed
    if (!userRole || !["members"].includes(userRole)) {
      return res.status(403).json({
        message: "Forbidden: You are not authorized to view sessions",
        errors: ["Access denied"],
      });
    }

    const today = new Date();
    const startOfWeek = new Date(today.setDate(today.getDate() - today.getDay()));
    const endOfWeek = new Date(today.setDate(startOfWeek.getDate() + 7));

    const Tranersessions = await SessionsActivityUserLocationM.getAllByclassDate(startOfWeek, endOfWeek);
    const sessionsArray = Array.isArray(Tranersessions) ? Tranersessions : [];

    if (sessionsArray.length === 0) {
      return res.status(404).json({ message: "No sessions found for this week" });
    }

    res.status(200).json(sessionsArray);
  } catch (error) {
    console.error(error);
    APIsessionsController.sendError(res, 500, "Failed to load sessions from database", [error.message]);
  }
}


  /**
   * @openapi
   * /api/sessions/trainer/me:
   *   get:
   *     summary: Get all sessions for the logged-in trainer
   *     tags:
   *       - Sessions
   *     security:
   *       - ApiKey: []
   *     responses:
   *       200:
   *         description: Trainer sessions with related data
   *         content:
   *           application/json:
   *             schema:
   *               type: object
   *               properties:
   *                 sessions:
   *                   type: array
   *                   items:
   *                     $ref: '#/components/schemas/SessionResponse'
   *               
   *       401:
   *         $ref: '#/components/responses/Error'
   *       403:
   *         $ref: '#/components/responses/Forbidden'
   *       404:
   *          $ref: "#/components/responses/NotFound"
   *       500:
   *         $ref: '#/components/responses/Error'
   */
 static async getTranerSessionByID(req, res) {
    try {
      const trainerId = req.user?.id;

      if (!trainerId || typeof trainerId !== "number") {
        return APIsessionsController.sendError(res, 401, "Unauthorized access - trainer authentication failed");
      }

      const trainerSessions = await SessionsActivityUserLocationM.getByTrainerId(trainerId);

      if (!trainerSessions || trainerSessions.length === 0) {
        return APIsessionsController.sendError(res, 404, "No sessions found for the trainer");
      }

      const responseData = {
        sessions: trainerSessions,
        activities: trainerSessions.map(session => session.activity).filter(a => typeof a === 'object' && a !== null),
        location: trainerSessions.map(session => session.location).filter(l => typeof l === 'object' && l !== null),
        users: trainerSessions.map(session => session.users).filter(u => typeof u === 'object' && u !== null),
      };

      res.status(200).json(responseData);
    } catch (error) {
      console.error(error);
      APIsessionsController.sendError(res, 500, "Failed to load sessions from database", [error.message]);
    }
  }




  /**
 * @openapi
 * /api/sessions/{id}:
 *   delete:
 *     summary: Delete a session and its associated bookings
 *     tags:
 *       - Sessions
 *     security:  
 *       - ApiKey: [] 
 *     parameters:
 *       - name: id
 *         in: path
 *         description: ID of the session to delete
 *         required: true
 *         schema:
 *           type: integer
 *     responses:
 *       200:
 *         description: Session deleted successfully
 *         content:
 *           application/json:
 *             schema:
 *               type: object
 *               properties:
 *                 message:
 *                   type: string
 *                   example: Session deleted successfully
 *       400:
 *         $ref: "#/components/responses/BadRequest"
 *       404:
 *         $ref: "#/components/responses/NotFound"
 *       403:
 *         $ref: "#/components/responses/Forbidden"
 *       500:
 *         $ref: "#/components/responses/Error"
 */


  //  missing 200  successful deleted 
 static async deleteSessionsTraner(req, res) {
  try {
    const trainerId = req.user?.id;
    const sessionId = req.params.id;

    if (!trainerId || isNaN(Number(sessionId))) {
      return APIsessionsController.sendError(res, 400, "Invalid trainer ID or session ID");
    }

    const session = await sessionsModel.getSessionById(sessionId);

    if (!session) {
      return APIsessionsController.sendError(res, 404, "Session not found");
    }

    if (session.Sessions?.trainer_user_id !== trainerId) {
      return APIsessionsController.sendError(res, 403, "Unauthorized: Cannot delete another trainer's session");
    }

    const result = await sessionsModel.deleteSessionAndBookings(sessionId);

    if (result.affectedRows === 1) {
      // Changed from 204 No Content to 200 OK with success message
      return res.status(200).json({ message: "Session deleted successfully" });
    } else {
      return APIsessionsController.sendError(res, 500, "Delete failed, session may not exist anymore");
    }
  } catch (error) {
    console.error(error);
    APIsessionsController.sendError(res, 500, "Failed to delete session - database error", [error.message]);
  }
}

/**
 * @openapi
 * /api/sessions/xml:
 *   get:
 *     summary: Export a logged-in trainer's sessions XML by their user ID
 *     tags:
 *       - Sessions
 *     security:
 *       - ApiKey: []
 *     parameters:
 *       - in: query
 *         name: user_id
 *         required: true
 *         schema:
 *           type: string
 *     responses:
 *       '200':
 *         description: Trainer sessions in XML format
 *         content:
 *           text/xml:
 *             schema:
 *               type: object
 *               xml:
 *                 name: TrainerSessions
 *                 attribute: true
 *               properties:
 *                 Session:
 *                   type: array
 *                   xml:
 *                     name: Session
 *                     wrapped: false
 *                   items:
 *                     type: object
 *                     properties:
 *                       sessionID:
 *                         type: string
 *                         example: "14"
 *                       activityName:
 *                         type: string
 *                         example: "Yoga"
 *                       sessionDateTime:
 *                         type: string
 *                         format: date-time
 *                         example: "2024-05-01T10:00:00Z"
 *                       activityDescription:
 *                         type: string
 *                         example: "Yoga is an ancient practice."
 *                       activityDuration:
 *                         type: string
 *                         example: "1 Hour"
 *                       location:
 *                         type: string
 *                         example: "South Bank"
 *       400:
 *         $ref: '#/components/responses/BadRequest'
 *       404:
 *         $ref: '#/components/responses/NotFound'
 *       403:
 *         $ref: '#/components/responses/Forbidden'
 *       500:
 *         $ref: '#/components/responses/Error'
 */

  static async getsessionXML(req, res) {
  try {
    const requestedTrainerId = parseInt(req.query.user_id);
    const authenticatedTrainerId = req.user?.id;

    if (!requestedTrainerId) {
      return res.status(400).json({ message: "Missing required query parameter: user_id" });
    }

    if (!authenticatedTrainerId || requestedTrainerId !== authenticatedTrainerId) {
      return APIsessionsController.sendError(res, 403, "Forbidden: You are not allowed to access this trainer's sessions");
    }

    function getISOWeek(date = new Date()) {
      const tmpDate = new Date(Date.UTC(date.getFullYear(), date.getMonth(), date.getDate()));
      const dayNum = tmpDate.getUTCDay() || 7;
      tmpDate.setUTCDate(tmpDate.getUTCDate() + 4 - dayNum);
      const yearStart = new Date(Date.UTC(tmpDate.getUTCFullYear(), 0, 1));
      return Math.ceil((((tmpDate - yearStart) / 86400000) + 1) / 7);
    }

    const today = new Date();
    const startOfWeek = new Date(today);
    startOfWeek.setDate(today.getDate() - today.getDay());
    const endOfWeek = new Date(startOfWeek);
    endOfWeek.setDate(startOfWeek.getDate() + 7);

    const Tranersessions = await SessionsActivityUserLocationM.getByTrainerId(authenticatedTrainerId);

    if (!Tranersessions || Tranersessions.length === 0) {
      return res.status(404).json({ message: "No sessions found for the authenticated trainer" });
    }

    const trainerName = Tranersessions[0]?.users.first_name || "Unknown";
    const exportWeek = `W${getISOWeek()}`;

    res.status(200)
      .contentType("text/xml")
      .render("xml/sessions.xml.ejs", {
        Tranersessions,
        exportWeek,
        trainerName
      });

  } catch (error) {
    console.error("Controller error:", error);
    APIsessionsController.sendError(res, 500, "Failed to export sessions as XML", [error.message || error]);
  }
}


}
