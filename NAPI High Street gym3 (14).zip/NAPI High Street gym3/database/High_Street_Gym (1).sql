-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: high street gym
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activities`
--

DROP TABLE IF EXISTS `activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activities` (
  `activity_id` int NOT NULL AUTO_INCREMENT,
  `activity_name` varchar(45) NOT NULL,
  `activity_description` varchar(1000) NOT NULL,
  `activity_duration` varchar(45) NOT NULL,
  PRIMARY KEY (`activity_id`),
  UNIQUE KEY `activity_id_UNIQUE` (`activity_id`)
) ENGINE=InnoDB AUTO_INCREMENT=125 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activities`
--

LOCK TABLES `activities` WRITE;
/*!40000 ALTER TABLE `activities` DISABLE KEYS */;
INSERT INTO `activities` VALUES (2,'yoga','Yoga is an ancient practice that combines physical postures, breathing techniques, and meditation to improve mental and physical health','30 to 45 minutes'),(7,'Pilates','Pilates uses a combination of approximately 50 simple, repetitive exercises to create muscular exertion','45 minutes to an hour'),(8,' Abs','Abdominal exercises are a type of strength exercise that affect the abdominal muscles','5 to 30 minutes '),(9,'HIIT or High-intensity Interval Training ','A training protocol alternating short periods of intense or explosive anaerobic exercise with brief recovery periods until the point of exhaustion.','30-60 minutes'),(10,' indoor cycling ','Indoor cycling is any type of indoor exercise that focuses on rotating pedals in circles','30-60 minutes daily '),(11,' Boxing ','Boxing is a sport that involves strategically punching an opponent while defending yourself from their return punches.','3 minutes for men, 2 minutes for women.'),(12,'Zumba','Zumba is an interval workout. The classes move between high- and low-intensity dance moves designed to get your heart rate up and boost cardio endurance.','1 Hour');
/*!40000 ALTER TABLE `activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_post`
--

DROP TABLE IF EXISTS `blog_post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blog_post` (
  `post_id` int NOT NULL AUTO_INCREMENT,
  `post_datetime` datetime NOT NULL,
  `post_user_id` int NOT NULL,
  `post_title` varchar(45) NOT NULL,
  `post_content` varchar(100) NOT NULL,
  PRIMARY KEY (`post_id`),
  UNIQUE KEY `post_id_UNIQUE` (`post_id`),
  KEY `user_bolg_post_fk_idx` (`post_user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=242 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_post`
--

LOCK TABLES `blog_post` WRITE;
/*!40000 ALTER TABLE `blog_post` DISABLE KEYS */;
INSERT INTO `blog_post` VALUES (164,'2025-02-14 08:02:34',97,'jack','jkack'),(165,'2025-02-22 02:28:39',62,'unfortunately ','test'),(166,'2025-02-24 23:27:14',142,'test','mayur'),(167,'2025-02-25 08:50:23',62,' tafe','tafe'),(175,'2025-03-01 11:38:23',97,'Pot','bhagt'),(177,'2025-03-03 23:15:15',62,'mayur','mayur'),(184,'2025-04-28 02:03:52',123,'Do every day','At High Street Gym'),(185,'2025-05-05 06:20:00',123,'Do every day','At High Street Gym'),(186,'2025-05-05 06:34:52',15,'Do every day','At High Street Gym'),(187,'2025-05-07 10:10:44',15,'test','NEW'),(188,'2025-05-07 10:11:16',15,'subject','subject'),(189,'2025-05-09 07:27:39',123,'Do every day','At High Street Gym'),(192,'2025-05-09 11:08:23',97,'tets','hfbhs'),(193,'2025-05-11 04:31:06',123,'Do every day','At High Street Gym'),(203,'2025-05-12 11:10:58',62,'test','test'),(207,'2025-05-20 00:22:44',97,'high ','djddd'),(210,'2025-05-20 03:41:12',96,'Do every day','At High Street Gym'),(218,'2025-05-21 00:09:56',123,'Do every dayh','At High Street Gym'),(219,'2025-05-21 00:15:11',62,'Do every day','At High Street Gym'),(232,'2025-05-28 03:13:17',145,'Do every dayD','At High Street GymD'),(233,'2025-05-28 03:27:04',145,'string','string'),(234,'2025-05-28 03:27:33',145,'string','string'),(235,'2025-05-28 03:28:44',145,'RUN','string'),(237,'2025-05-28 04:06:21',145,'RUN','string'),(238,'2025-05-28 04:08:17',145,'RUN','string'),(239,'2025-05-28 04:09:12',145,'RUN','string'),(240,'2025-05-28 04:09:22',145,'RUN','string'),(241,'2025-05-28 04:13:51',145,'Gym','Is cools ');
/*!40000 ALTER TABLE `blog_post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bookings`
--

DROP TABLE IF EXISTS `bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bookings` (
  `booking_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `Sessions_id` int NOT NULL,
  `booking_created_datetime` datetime DEFAULT CURRENT_TIMESTAMP,
  `activity_id` int NOT NULL,
  `location_id` int NOT NULL,
  PRIMARY KEY (`booking_id`),
  UNIQUE KEY `booking_id_UNIQUE` (`booking_id`),
  KEY `users_bookings_fk_idx` (`user_id`),
  KEY `classes_booking_id_idx` (`Sessions_id`),
  KEY `activities_bookings_fk_idx` (`activity_id`),
  KEY `location_bookings.fk_idx` (`location_id`),
  CONSTRAINT `activities_bookings_fk` FOREIGN KEY (`activity_id`) REFERENCES `activities` (`activity_id`),
  CONSTRAINT `classes_bookings_id` FOREIGN KEY (`Sessions_id`) REFERENCES `sessions` (`Sessions_id`),
  CONSTRAINT `lacation_bookings_fk` FOREIGN KEY (`location_id`) REFERENCES `location` (`location_id`),
  CONSTRAINT `users_bookings_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=702 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookings`
--

LOCK TABLES `bookings` WRITE;
/*!40000 ALTER TABLE `bookings` DISABLE KEYS */;
INSERT INTO `bookings` VALUES (680,123,277,'2025-05-24 10:53:15',2,103),(691,62,280,'2025-05-27 09:32:22',11,132),(698,145,282,'2025-06-04 03:12:10',8,2),(699,145,283,'2025-06-04 03:12:17',7,100),(701,145,295,'2025-06-09 08:31:05',9,2);
/*!40000 ALTER TABLE `bookings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location`
--

DROP TABLE IF EXISTS `location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `location` (
  `location_id` int NOT NULL AUTO_INCREMENT,
  `location_name` varchar(45) NOT NULL,
  PRIMARY KEY (`location_id`),
  UNIQUE KEY `location_id_UNIQUE` (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=142 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location`
--

LOCK TABLES `location` WRITE;
/*!40000 ALTER TABLE `location` DISABLE KEYS */;
INSERT INTO `location` VALUES (2,'Brisbane City'),(100,'Chermside'),(102,'Graceville'),(103,'Westlake'),(132,'Ashgrove');
/*!40000 ALTER TABLE `location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `Sessions_id` int NOT NULL AUTO_INCREMENT,
  `Sessions_datetime` datetime DEFAULT CURRENT_TIMESTAMP,
  `location_id` int NOT NULL,
  `activity_id` int NOT NULL,
  `trainer_user_id` int NOT NULL,
  PRIMARY KEY (`Sessions_id`),
  UNIQUE KEY `class_id_UNIQUE` (`Sessions_id`),
  KEY `location_classes_fk_idx` (`location_id`),
  KEY `activity_classes_fk_idx` (`activity_id`),
  KEY `users_classes_fk_idx` (`trainer_user_id`),
  CONSTRAINT `activity_classes_fk` FOREIGN KEY (`activity_id`) REFERENCES `activities` (`activity_id`),
  CONSTRAINT `location_classes_fk` FOREIGN KEY (`location_id`) REFERENCES `location` (`location_id`),
  CONSTRAINT `users_classes_fk` FOREIGN KEY (`trainer_user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=301 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES (277,'2025-05-22 22:54:00',103,2,97),(280,'2025-05-28 08:26:00',132,11,63),(282,'2025-06-03 18:20:00',2,8,62),(283,'2025-06-04 17:25:00',100,7,57),(285,'2025-07-07 08:26:00',103,7,63),(286,'2025-06-11 10:07:00',102,9,79),(288,'2025-06-01 11:34:00',132,7,57),(295,'2025-06-10 15:13:00',2,9,131),(296,'2025-06-11 15:14:00',100,9,131),(298,'2025-06-17 14:14:00',2,7,131),(299,'2025-06-19 13:13:00',100,9,63),(300,'2025-06-19 13:13:00',100,9,57);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `user_email` varchar(45) NOT NULL,
  `user_password` varchar(100) NOT NULL,
  `user_role` enum('manager','trainer','members') NOT NULL,
  `user_phone` varchar(45) NOT NULL,
  `user_first_name` varchar(45) NOT NULL,
  `user_last_name` varchar(45) NOT NULL,
  `user_address` varchar(45) NOT NULL,
  `authentication_key` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `users_id_UNIQUE` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=174 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (15,'mayurbhagat@outlook.com','$2a$10$bmemT32xAZESn373UxyVUu/e/M05BI.smVonSmp6lNDA5JlRpcHWS','manager','490942246','Sam','Tafe','14 Testing Street','63d6bc0c-aff2-44dc-8792-5922db471a1d'),(57,'tomeS@outlook.com','$2b$10$AxLl1LKL0xvl/WACW7W7xOO9qnzv6gC5IaBqV60SV07.o.u0cg/YO','trainer','405506601','jack','bahgs',' tham to and 24',NULL),(62,'mayurbhagat1@outlook.com','$2b$10$3B7TXGgJXCcLQbQMY8ohG.BgLabmmy3kXGqR/.RkCK9wOhK//i38K','members','405505574','Sam','Tafe','14 Testing Street',NULL),(63,'dom@outlook.com.au','$2a$10$D8p4WknWB6yZrSnsDPcqXeYzfnWHrRuWxfne37I.lJNJEIeSgA03m','trainer','0490942246','dom','hq','6',NULL),(77,'mayurbhagat1@outlook.com ','$2a$10$gN2KnPQmjcjMgtrFX0E/ZO2yyTEKidSk7YCDA1D3DvLekTc3l2F6O','members','0490942246','test','test','6',NULL),(78,'manager.@outlook.com.au','$2a$10$ZTB1pKnsBu2CTv0Z1W5mUum8DyGydssosr3yOAH9Z1M/WacHp4Y9q','trainer','0490942246','manger','manager','6',NULL),(79,'tom@outlook.com','$2a$10$SzW7oLaXPwzwjim4kwBGNOXpHM8G3ZGQdIBiaoJTO/2tNmU9Qh35.','trainer','0401155623','pan','HPsrt','6 ABBOT CIRCUIT',NULL),(81,'Tome1@outlook.com','$2a$10$hOvGpaA9kn6oYiCMQCu7HOhOO3HCGfGQXEbTudIIgcnkkERAbGyK6','members','04587845168','tomy','mbers','12 testing street goodan ',NULL),(96,'sam@yahoo.com','$2a$10$xwWCh4pE2qBsHabN2iQq9Ob16vh6jJMwUKnSllVKJTj1ugCpIgYOm','trainer','0412548789','Same ','  gan ',' 14 Brisbane rock',NULL),(97,'mayurbhagat2@outlook.com','$2b$10$C6KCC9OHl4pS3.wDTDUs1O5AyeoYk0zwyk11dreLNOmEbSWes9j8a','trainer','405505574','Sam','Tafe','14 Testing Street',NULL),(98,'Tgon@tgon.com.au','$2a$10$bBjfQX5TkZVb.86enJ0sweiOGLttGRU5O6uHhRGaLiyRqhjM4I9lO','members','04055022031',' Tgon','hqplot','16 computer Brisbane RD',NULL),(100,'TESTING@.OUTLOOK.COM','$2a$10$WcYbq6wpCx/xLSCxFNnP8.EOG5p6Cz8dU4K2VG6pun3vXF9ehKjNe','members','01234567891','TESTING','TESTING ','3',NULL),(101,'123@outlook.com.au','$2a$10$KNu5c.BEy/r46MGs4NJpxu8yyU9GAydBsTMO4DdxQjcylO9zPllxe','members','0412345678','gun','gun','5',NULL),(102,'test@outlook.com','$2a$10$4.ThY/IEYsHi6Xyow1dtYeBOz1aEO5V.5fj4w.rCVSphtYNEsA1/6','manager','04022034324','TESTING','TESTING','15 abc',NULL),(103,'h@outlook.com','$2a$10$MwQ7uskBht/YUyO5iPUpgutFF07dOzdz8xz4XOZ5Y0YfMPndMLMJm','manager','0573686473','ter','bhagat','15 bne',NULL),(104,'t@oitlokk.com','$2a$10$vYkOut3JLvGUMf.rg0MV..Vww.7A8c82a0ZP/sPTynz9pw1sbGso6','trainer','0483784283','TESTING','testing','15 bne',NULL),(105,'6747@outlook.com','$2a$10$vJB2LjODc8JPzA2ARMnLqOwqoGoAxhnz.SN1U9CCVzhBhw/4zUBce','manager','04055022031','mayur','bhagat','15 ben',NULL),(106,'4300@outlok.com','$2a$10$tE4lOdMBYG69oJEzJgpfieE/lyzUkbXTbewe9gU9GKjlyyDNHHytS','members','014573683671','bhagat','mayu','14 Australian Queensland Street',NULL),(107,'testuser@example.com','$2a$10$5ZMoVBcSCW0VGU5/m356mexrjquepiHMCcel2l2mv7Tv7irx/5sAK','members','1234567890','John','Doe','123 Main St, Anytown, USA',NULL),(108,'Cestuser@example.com','$2a$10$xI5nBGjUIad.F9gVTM587uYYXZ0qUgpWCmY/Xeiw97BegaAChwBtm','members','1234567890','John','Doe','123 Main St, Anytown, USA',NULL),(109,'Cestuser@example.com','$2a$10$qSLy13w0a2oi1RwLjVe53.PohDhnLpvEfQx6yMMGtUJuliSkylEya','members','1234567890','John','Doe','123 Main St, Anytown, USA',NULL),(110,'Cestuser@example.com','$2a$10$F113n8lcjoRiTqbcBcRQ0OhuN9ktHoUKp8OO4LZN37O6cIdB6SRvq','members','1234567890','John','Doe','123 Main St, Anytown, USA',NULL),(111,'Cestuser@example.com','$2a$10$0Wo6RmswOgSRJ.2XSCXqQuY5onquICPd1d6CkLQQnYSwbjZ.Rxq2O','members','1234567890','John','Doe','123 Main St, Anytown, USA',NULL),(112,'Cestuser@example.com','$2a$10$L9DGKVLPs/ovOlQ9XVqE7ek/a0tRsrQGokQIMCB4u3YmCUzHavnSO','members','1234567890','John','Doe','123 Main St, Anytown, USA',NULL),(113,'Cestuser@example.com','$2a$10$zs396oo2zUsexA654cIv9.DAx2Ke7wcEUE17XA9RvRYRjs5VL75bi','members','viren001@','John','Doe','123 Main St, Anytown, USA',NULL),(114,'0estuser@example.com','$2a$10$DTzk10MU4Wet.PAy0ra0SOqbMnOLOyYj7ciDUJg0jG9EXFJVVFZfi','members','0490942246','John','Doe','123 Main St, Anytown, USA',NULL),(115,'mayurbhagat@outlook.com','Viren001@','manager','0401155623','VIRENDRA','BHAGAT','6 ABBOT CIRCUIT',NULL),(116,'mayurbhagat@outlook.com','$2a$10$Cqc0Xo1JbN.QxDqP1ggHKuSAjrHLh4/strcIq0WtTgAoX50Y.nDUa','members','0401155623','VIRENDRA','BHAGAT','6 ABBOT CIRCUIT',NULL),(117,'mayurbhagat@outlook.com','$2a$10$2EkCaYPTCisvaAG4M1vBruoBKN49XmjF/ygao./zT5nCTMHnZgK6e','members','0490942246','mayur','BHAGAT','6',NULL),(118,'testinf@outlok.com','$2a$10$joritwJbWyWiQcUkTO06ouuVBww2d8Jpt4AGQaJaPf4/runfIamP2','members','0490942246','mayur','BHAGAT','6',NULL),(119,'T4@outlook.com','$2a$10$z3AOm0cP1LBwxtCsXRIcJ.za1z5oPPPY/pE5J.D12Go1qTX2jZ7.a','members','0490942246','mayur','BHAGAT','6',NULL),(120,'test@outlook.com','$2a$10$c664qcAiIgpbLbnW1VerteTj6W9hj.JFsCKps0.xmRZKsvy0B5MtK','members','0490942246','mayur','BHAGAT','6',NULL),(121,'NEWW2@outlokk.com','$2a$10$69jMF.Sp8YoPf2rnVjzNS.cQ7zor/ps5Y4ZCU4TTX8f35Ch9Xo1oy','members','0490942246','NEW','BHAGAT','6',NULL),(122,'testuser@example.com','$2a$10$rwQm7mDvDUjq1W3ADIejA.VrwQWhGTpKb2UwK3/xseeYUi7GWoXFi','members','1234567890','John','Doe','123 Main St, Anytown, USA',NULL),(123,'Tome@outlook.com.au','$2b$10$WIhCOUrmIjWIxN8raySTMeIxrF6/d7CedSz1MfGAjr4wnr5IsH.BO','members','0490942246','tome','BHAGAT','6 ABBOT CIRCUIT',NULL),(124,'testing@outlook.com','$2a$10$tubj4T5C2RZCWiIMwsI85u2QDxiCEPIw9ZUBEfu68TyreaIwzHId6','members','0490942246','mayur','BHAGAT','6',NULL),(125,'Tome@outlook.com.au','$2a$10$kJMuO0tAQ1tCPh.QXbBR6uXba42Xj2r.HeqVE32Sa9QZyHtGQNqbK','members','0490942246','mayur','BHAGAT','6',NULL),(126,'pot@outlook.com.au','$2a$10$CeHhOcSNlGEqlyxLVS6WwuQEBOMu1wViVhS/XpuWzYEwDnoPzoawS','members','0490942246','pot','BHAGAT','6',NULL),(127,'498@otulook.com','$2a$10$egddxdcMe0AczPwqXjtvbOvRD9kP5KfCt6EMRU3hsMoF5/ssD.cXq','members','408489549004','mayur','maurutio',' 4 hguhgh',NULL),(128,'like@outlook.com','$2b$10$yiQelIK3f/K2Chp6.KHBSOetALBWcdTWEtKnzzURpdWq4EOgDjZby','trainer','0490942246','Luke','BHAGAT','6',NULL),(129,'Laim@outlook.com.au','$2b$10$pZ8PAr5YadqjDg29t6kfYOY6MnubqJI.im7t8IGevOBtB/RROE8Cy','trainer','0490942246','Tomey','liam','6 ABBOT CIRCUIT',NULL),(130,'Tome@outlook.com.au','$2a$10$kbozmAjLqOA1o1WxmO6IieRYBUfyDV2edQyF1s91swOQTu/9EbluO','members','014573683671','mayur','bhagat','19 abbitt circuit bellbird park',NULL),(131,'mayurbhagat9@outlook.com','$2b$10$OMMPp0.dJ7aq2FgBdGxC5e0ceZU4wBp1ga3fr6j0cIj65LXQWrzGy','trainer','0401155629','SamN','Tafe','14 Testing Street','e3e1f311-86ba-405a-91f6-c31f95f8b3ff'),(134,'mayurbhagat1@outlook.com','$2a$10$7LCdUERBIsDdJfz6PMOhLeqh.0sN/DhFZf1Pt.5JA2RM5jq3LlkK2','manager','0490942246','mayur','BHAGAT','6',NULL),(135,'mayurbhagat1@outlook.com','$2a$10$WRhW.cG6zGL.8LlgerEYx.WlpDBAJDxCpdZioiotVSPmtT8NMcthS','manager','0490942246','mayur','BHAGAT','6',NULL),(136,'mayurbhagat1@outlook.com','$2a$10$aJgVUR2eO3HBoUoZHlS.p.zKT4XNF9RYM2RuGWNH0qqdlrgl.HeWO','members','0490942246','mayur','BHAGAT','6',NULL),(137,'mayurbhagat1@outlook.com','$2a$10$KPtVYtt2WiD5cO5LCXbbXO0Jlfs9FBvlwacYmJSqD/UgrEx0nLJXq','manager','0490942246','mayur','BHAGAT','6',NULL),(141,'mayurbhagat0@outlook.com.au','$2a$10$KKfqqWG2PvAJ/w4iLCw0uODN/o5Af90qx5MVHHrCO8XKstHLyLXC.','members','0490942246','mayur','BHAGAT','6',NULL),(142,'nee@outlook.com.au','$2a$10$8XS6Z4xOFVmCSTYOO8sgX.VXgXzCgMSinPCBKWs.5vhWYuA50M3Vm','trainer','408489549004','test','tes','6 abbot',NULL),(143,'mayur@nmayur.com','$2a$10$Myr5iNK/8URQNbe6CRmKrOmUkC8RXaly0f3Ui8PPfqYlxei2vjcmO','members','0490942246','mayur','BHAGAT','6',NULL),(144,'mayurbhagat1@outlook.com','$2a$10$pdNVO6SizeoXALOjRZQ6VuREGA46jKdt6jhDt1t.pPUbxCduzEUd6','members','0490942246','remove','BHAGAT','6',NULL),(145,'jack@yahoo.com','$2b$10$sT4JgjpWIf4M/Fevt.qZ/uXl.4avUDf6MprU48ySsfvjggOoX6nmK','members','405505574','Tom','Tafe','14 Testing Street',NULL),(146,'user@outlook.com.au','$2a$10$dqT.gVT8j9vT/mZNm05gKuYAhmTSa92mBzzOX28Jqwkd6z/EeoVJe','manager','04055088071','GitHub','User','6 pan rode ride ',NULL),(147,'trainer@oulook.com','$2a$10$4Qv7iH0FqhOUzjSSgrgHL.F98UIrvncT9Mzt5KPmWznSgI9tdXQK.','trainer','0402202251','GitHub','trainer','not',NULL),(148,'New@outlook.com','$2b$10$41U8v3XEEru.sgTAayb.Reem0uhMu1RweHP6ohwquuY9N9XJGVnbu','members','0405508871','may','may','17 dan rood',NULL),(149,'mayurbhagat1@outlook.com.mayur','$2a$10$Z01v.rSEBnhYmEmVWqYeFuXR1hxK6d.Zao8SGmWf4MiETeUfydcCG','members','0490942246','testing','BHAGAT','6',NULL),(150,'mayurbhagat1@outlook.com','$2a$10$FKGAo7kgC1v3fQhBJXaMmuoWsn5MuuB6gIZIhGypFhcwS.uMfDGES','members','0490942246','mayur','BHAGAT','6',NULL),(151,'Viren4300@yah.com','$2a$10$9b3ZupOGpFMK8XoL8L4uPe8IjeYQsnnXkfTyT7yMIEUhrTvkAcgkm','manager','0402202251','testing','trainer','6 abbot',NULL),(152,'rinfi@outloo.com','$2a$10$/lm2Jba5rzlYFrd7McStzOkktbtR2/WQ2CkeQiFSXNYTkvCTXnE3K','members','014573683671','run','run','6 pan rode ride',NULL),(153,'New@outlook.com','Viren022@','members','0405508871','may','may','17 dan rood',NULL),(154,'New@outlook.com','Viren022@','members','0405508871','may','may','17 dan rood',NULL),(155,'Hi@outlo.com','$2a$10$Z5y2Fs5e/2KsvCQOZ4ZyQOjOgz0hcoABK8cbjLLF.pq7CBsMgW99C','manager','0402202251','testing','testing','14 Australian Queensland Street',NULL),(156,'j@outlook.com','$2a$10$OtDrYI0/xmLHpnN2t8rBxekVryIGmfRiVfjHTZk6P/Eqc/Ux2SADO','members','04055088071','testing','jk','6 pan rode ride',NULL),(157,'john@example.com','securePass123','members','+1234567890','John','Doe','123 Street Name, City',NULL),(158,'john@example.com','securePass123','members','+1234567890','John','Doe','123 Street Name, City',NULL),(159,'New@outlook.com','$2b$10$2zCw78tmrDOnv/p6VZQuGuqng3peATf75m8I4AXAvg1jYFXpNnPFq','members','0405508871','may','may','17 dan rood',NULL),(160,'mayurbhagat@outlook.com','$2b$10$yiSKttvDjARi7uzrAlmhUePW/MbpDE3w3V5AUnPS.PfCEcPAgRerG','members','040550738','mayur','BHAGAT','6 ABBOT CIRCUIT',NULL),(161,'t@outlook.com','$2b$10$gWZh1uBt1JlB9dCGf09aMeuObRZpyMfQOT9eAitICZBHn1rTvuxy6','members','01490942246','may','BHAGAT','6 ABBOT CIRCUIT',NULL),(162,'mayurbhagat2@outlook.com','$2b$10$dXUeohwiLk8tUD4pyNTq7..GbsfBMSJoq5M/.kzAjJW9RlbsfVlMO','members','405505574','Sam','Tafe','14 Testing Street',NULL),(163,'New@outlook.com','$2b$10$00ssPsWDj.JBRQriz8e.AOKosIwG954LtH5ayJiA./3gxzMnSNoHK','members','0405508871','may','may','17 dan rood',NULL),(164,'New@outlook.com','$2b$10$mhoPqPLrUJC9AuEJXysjmOJsFhZc2mZrrM95EOLfG1OUCWyb61bi6','members','0405508871','may','may','17 dan rood',NULL),(165,'New@outlook.com','$2b$10$ig0DIcHGntMiz3T99LMZgeMQGCmJd2Z3FzN70S0SMCV109BpYYf7u','members','0405508871','may','may','17 dan rood',NULL),(166,'New@outlook.com','$2b$10$5hDEzVr9LL9RA3uhQeGIVOso6s4WnejpsZesICq/ONd4rhRvfLnNS','members','0405508871','may','may','17 dan rood',NULL),(167,'Laim@outlook.com.au','$2b$10$qhx.VfcozKXkhRIG7QYjk.PlBRQdMMgx.6PJoa5PXkqdn6XsRuJxi','members','+61490942246','mayur','BHAGAT','6 ABBOT CIRCUIT',NULL),(168,'Laim@outlook.com.au','$2b$10$GNQ1BomPb9dkfZLoTCcZteYh98Ou2a2vj08BJwHLT.Dvmr22IU2Ai','members','+61490942246','mayur','BHAGAT','6 ABBOT CIRCUIT',NULL),(169,'jack@yahoo.com','$2b$10$hRxmZuUANhEJXJox699yg.lG1Z5I6LbkDHsNZuq5IRGmlsrOnROdK','members','+61490942246','mayur','BHAGAT','6 ABBOT CIRCUIT',NULL),(170,'MB@outlook.com','$2b$10$rZew/D09pojv0SickBYvnecWF.GPQEzJf392uE/oN0WSlLudVbnrW','members','04055981','mayur','BHAGAT','6 ABBOT CIRCUIT',NULL),(171,'mayurbhagat0@outlook.com','$2b$10$5y.xptIHFLwZ5u.kc6QqiumfCK7Xaq3zZG7TNpySoT23T1rsINAnG','members','405505574','Sam','Tafe','14 Testing Street',NULL),(172,'P2@outlook.com','$2b$10$DkY05BfzqwJCKyg8GRPDxOjf2SrJHAlY3Vf8DGIXLhCskolIOesF.','members','405505574','Sam','Tafe','14 Testing Street',NULL),(173,'mayurbhagatP@outlook.com','$2b$10$.I8wh9owEgRc.LhJ.hvsr.G05kPaLdAda9V6IDp2T.STuNlU2Abhu','members','405505574','Sam','Tafe','14 Testing Street',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-06-10 13:18:16
