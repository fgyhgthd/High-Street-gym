import express from "express";
import validator from "validator";
import { AuthenticationController } from "./Authentication.mjs"
import { Blog } from "../models/bolg_post.js"; 


export class postController {
    static routes = express.Router();

    static {
        this.routes.get("/Blogviwe", this.viewBlog); 
        this.routes.get("/addblog", this.viewAddBlog);
        this.routes.post("/edit_blog", this.handleEditBlog);
        this.routes.get("/Blog_backend", AuthenticationController.restrict (["manager", "trainer"]), this.viewBlogBackend);
        this.routes.post("/edit_blog_backed", AuthenticationController.restrict (["manager", "trainer"]), this.handleEditBlogBackend); // Fixed typo
    }
//     Blog view for mebers 
static viewBlog(req, res) {
    const editID = req.query.edit_id;

    if (editID) {
        Promise.all([Blog.getById(editID), Blog.getAll()])
            .then(([editblog, allblog]) => {
                res.render("Blog.ejs", {
                    allblog,
                    editblog,
                    role: req.authenticatedUser.role,
                    userID: req.session.user.userID
                });
            });
    } else {
        Blog.getAll().then(allblog => {
            res.render("Blog.ejs", {
                allblog,
                role: req.authenticatedUser.role,
                userID: req.session.user.userID,
                editblog: new Blog(0, "", "", "", "", "")
            });
        });
    }
}

static viewAddBlog(req, res) {
    const editID = req.query.edit_id;

    if (editID) {
        Promise.all([Blog.getById(editID), Blog.getAll()])
            .then(([editblog, allblog]) => {
                res.render("addblog.ejs", { allblog, editblog, role: req.authenticatedUser.role, userID: req.session.user.userID });
            });
    } else {
        Blog.getAll().then(allblog => {
            res.render("addblog.ejs", {
                allblog,
                editblog: new Blog(0, "", "", "", "", ""),
                role: req.authenticatedUser.role,
                userID: req.session.user.userID
            });
        });
    }
}

///////////////////////////////////////////////////////////////////////////
static handleEditBlog(req, res) {
    const formData = req.body;
    const postId = formData.post_id;
    const userId = req.session.user.userID;

    // Validate form data - allow letters and spaces
    if (!/^[a-zA-Z\s]{2,}$/.test(formData.title)) {
        res.render("status.ejs", {
            status: "Invalid Title",
            message: "Please enter a valid title with letters and spaces.",
        });
        return;
    }

    if (!/^[a-zA-Z\s]{2,}$/.test(formData.content)) {
        res.render("status.ejs", {
            status: "Invalid Content",
            message: "Please enter valid content with letters and spaces.",
        });
        return;
    }

    // Create blog model from form data
    const editblog = new Blog(
        validator.escape(formData.post_id),
        new Date().toISOString().slice(0, 19).replace("T", " "),
        validator.escape(formData.user_id),
        validator.escape(formData.title),
        validator.escape(formData.content),
    );

    // CRUD operation based on the action button pressed
    if (formData.action == "create") {
        Blog.create(editblog).then(() => {
            res.redirect("/Blogviwe");
        });
    } else if (formData.action == "update") {
        Blog.getById(postId).then(Post => {
            // console.log("Post ID received:", postId);
            // console.log("Retrieved Post:", Post);
            
            if (!Post) {
                // console.log("Error: Post not found for ID:", postId);
                res.render("status.ejs", {
                    status: "Error",
                    message: "Post not found.",
                });
                return;
            }
            
            if (!Post.post_user_id) {
                // console.log("Error: Post.post_user_id is undefined for Post:", Post);
                res.render("status.ejs", {
                    status: "Error",
                    message: "Invalid post data.",
                });
                return;
            }
            
            if (String(Post.post_user_id) !== String(userId)) {
                console.log("Unauthorized access attempt:", {
                    loggedInUser: userId,
                    postOwner: Post.post_user_id,
                });
                res.render("status.ejs", {
                    status: "Unauthorized",
                    message: "You are not authorized to update this post.",
                });
                return;
            }
            
            Blog.update(editblog).then(() => {
                res.redirect("/Blogviwe");
            });
        });
    } else if (formData.action == "delete") {
        Blog.getById(postId).then(Post => {
            // console.log("Post ID received:", postId);
            // console.log("Retrieved Post:", Post);
            
            if (!Post) {
                // console.log("Error: Post not found for ID:", postId);
                res.render("status.ejs", {
                    status: "Error",
                    message: "Post not found.",
                });
                return;
            }
            
            if (!Post.post_user_id) {
                // console.log("Error: Post.post_user_id is undefined for Post:", Post);
                res.render("status.ejs", {
                    status: "Error",
                    message: "Invalid post data.",
                });
                return;
            }
            
            if (String(Post.post_user_id) !== String(userId)) {
                console.log("Unauthorized access attempt:", {
                    loggedInUser: userId,
                    postOwner: Post.post_user_id,
                });
                res.render("status.ejs", {
                    status: "Unauthorized",
                    message: "You are not authorized to delete this post.",
                });
                return;
            }
            
            Blog.deleteById(postId).then(() => {
                res.redirect("/Blogviwe");
            });
        });
    }
}

    //    ////////////////////////////////////////////////////////////////////////////////////////////////////////


    static viewBlogBackend(req, res) {
        const editID = req.query.edit_id;

        if (editID) {
            Promise.all([Blog.getById(editID), Blog.getAll()])
                .then(([editblog, allblog]) => {
                    res.render("Blog_backend.ejs", { allblog, editblog, role:req.authenticatedUser.role, userID: req.session.user.userID });
                });
        } else {
            Blog.getAll().then(allblog => {
                res.render("Blog_backend.ejs", {
                    allblog,
                    role: req.authenticatedUser.role,
                    userID: req.session.user.userID,
                    editblog: new Blog(0, "", "", "", "", "")
                });
            });
        }
    }
//   need to find out what is  happening here 
    static handleEditBlogBackend(req, res) {
        const formData = req.body;
        const editblog = new Blog(
            validator.escape(formData.post_id),
            new Date().toISOString().slice(0, 19).replace("T", " "),
            validator.escape(formData.user_id),
            validator.escape(formData.title),
            validator.escape(formData.content)
        );

        if (formData.action === "create") {
            Blog.create(editblog).then(() => res.redirect("/Blog_backend")); 
        } else if (formData.action === "update") {
            Blog.update(editblog).then(() => res.redirect("/Blog_backend")); 
        } else if (formData.action === "delete") {
            Blog.deleteById(editblog.post_id).then(() => res.redirect("/Blog_backend")); 
        }
    }
}
