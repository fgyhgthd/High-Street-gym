

import express from "express";
import validator from "validator";
import { bookingsModel } from "../models/bookings.js";
import { usersModels } from "../models/users.js"; 
import { BookingALLM } from "../models/booking_all.js"; 
import { activitiesModel } from "../models/activties.js";
import { LocationModel } from "../models/location.js";
import { sessionsModel } from "../models/sessions.js";
import { SessionsActivityUserLocationM} from "../models/sessions_activity.js";

import { AuthenticationController } from "./Authentication.mjs"
export class BookingController {
    static routes = express.Router();

    static {
            this.routes.post("/create_booking", this.createBooking);
        this.routes.get("/booking_confirmation", this.viewBookingConfirmation);
        this.routes.get("/bookings_confirmation", this.viewallAllbooking);
        this.routes.get("/editbooking", AuthenticationController.restrict (["members"]),this.viewEditBooking);
        this.routes.post("/edit_booking", AuthenticationController.restrict (["members"]), this.handleEditBooking);
        this.routes.get("/booking_view", AuthenticationController.restrict (["manager", "trainer"]), this. getBookingsBySearch);
        this.routes.post("/mangement_booking", AuthenticationController.restrict (["manager", "trainer"]), this.manageBooking);
      
    }
//   membes  create  booing
    static createBooking(req, res) {
        console.log("Received form data:", req.body);
    
        const formData = req.body;
    
        if (!/^[0-9]+$/.test(formData.user_id) ||
            !/^[0-9]+$/.test(formData.Sessions_id) ||
            !/^[0-9]+$/.test(formData.activity_id) ||
            !/^[0-9]+$/.test(formData.location_id)) {
            return res.render("status.ejs", {
                status: "Invalid Input",
                message: "Please enter valid IDs.",
            });
        }
    
        // Check for duplicate booking
        bookingsModel.getByUserAndClass(formData.user_id, formData.Sessions_id)
            .then(existingBooking => {
                if (!Array.isArray(existingBooking)) {
                    return res.status(500).send("Database error: Invalid response from getByUserAndClass.");
                }
    
                if (existingBooking.length > 0) {
                    return res.status(400).render("status.ejs", {
                        status: "Duplicate Booking",
                        message: "You have already booked this session.",
                    });
                }
    
                // Proceed with booking if no duplicate is found
                const booking = {
                    booking_id: formData.booking_id,
                    user_id: formData.user_id,
                    Sessions_id: formData.Sessions_id,
                    booking_created_datetime: new Date(),
                    activity_id: formData.activity_id,
                    location_id: formData.location_id,
                };
    
                return bookingsModel.create(booking)
                    .then(result => res.redirect(`/booking_confirmation?id=${result.insertId}`))
                    .catch(error => res.status(500).send("Failed to create booking: " + error));
            })
            .catch(error => res.status(500).send("Database error: " + error));
    }
    
    
   
    //   booking conformation view 

    static viewBookingConfirmation(req, res) {
        if (!req.query.id) return res.redirect("/booking_view");
       
        BookingALLM.getAllBybookingAllid(req.query.id)
            .then(booking => res.render("booking_confirmation.ejs", { role: req.authenticatedUser.role, booking }))
            .catch(error => res.render("status.ejs", { status: "Invalid booking ID", message: error }));
    }

    static viewallAllbooking(req, res) {
        if (!req.query.id) return res.redirect("/booking_view");

        BookingALLM.getAllBybookingsAll(req.query.id)
            .then(allAllbooking => res.render("booking_confirmation.ejs", { role: req.authenticatedUser.role, allAllbooking }))
            .catch(error => res.render("status.ejs", { status: "No booking found", message: error }));
    }

//   member   Edit booking page 


static viewEditBooking(req, res) {
    BookingALLM.getAllByUserID(req.session.user.userID)
        .then(allAllbooking => {
            // console.log('All Bookings:', allAllbooking); // Debug logging

            if (!Array.isArray(allAllbooking)) {
                allAllbooking = [];
            }

            const editID = req.query.edit_id ? String(req.query.edit_id) : null;
            let editAllbooking = {};

            if (editID) {
                editAllbooking = allAllbooking.find(b => b.bookings && b.bookings.id == editID) || {};
            }

            // console.log('Edit Booking:', editAllbooking); // Debug logging

            res.render("edit_booking.ejs", {
                role: req.authenticatedUser.role,
                allAllbooking,
                editAllbooking
            });
        })
        .catch(error => {
            // console.error('Error fetching bookings:', error); // Debug logging
            res.render("status.ejs", { status: "No bookings found", message: error });
        });
}

static handleEditBooking(req, res) {
    const formData = req.body;
    console.log(formData)
   
    if (!/^[0-9]{1,}$/.test(formData.user_id)) {
        res.render("status.ejs", {
             status: "Invalid User id ",
             message: "please enter a valid  user Id ",
        });
        return;
    }
    
    
    if (!/^[0-9]{1,}$/.test(formData.Sessions_id)) {
        res.render("status.ejs", {
            status: "Invalid Class id ",
            message: "please enter a valid  Class Id ",
        });
        return;
    }
    
    
    if (!/^[0-9]{1,}$/.test(formData.activity_id)) {
        res.render("status.ejs", {
            status: "Invalid Activity ID",
            message: "Please enter a vaild  Activity id .",
        });
        return;
    }
   
   
   
   
   
    
        
    // Extract user_id from form data
    const booking_id = formData.booking_id;

    // Create or update user based on form data
    const editBooking =  new bookingsModel(

        validator.escape(booking_id),
        validator.escape(formData.user_id),
        validator.escape(formData.Sessions_id),
        new Date(),
        validator.escape(formData.activity_id),
      
      
      
      
      
      


    )



    if (formData.action === "create") {
        bookingsModel.create(editBooking).then(() => res.redirect("/editbooking"));
    } else if (formData.action === "update") {
        bookingsModel.update(editBooking).then(() => res.redirect("/editbooking"));
    } else if (formData.action === "delete") {
        bookingsModel.deleteById(editBooking.id).then(() => res.redirect("/editbooking"));
    }
}

//     mangaers page 
 //   this is working 
 
            
 static getBookingsBySearch(req, res) { 
    const searchTerm = req.query.search_term;
    const editID = req.query.edit_id;

    let allAllbooking = [];
    let editAllbooking = new bookingsModel(0, "", "");
    let noResultsMessage = "";

    let bookingPromise;

    if (searchTerm) {
        bookingPromise = BookingALLM.getBySearch(searchTerm)
            .then(bookingData => {
                if (!Array.isArray(bookingData) || bookingData.length === 0) {
                    noResultsMessage = "No results found. Showing all bookings.";
                    console.warn("Warning: No bookings found for the search term.");
                    return BookingALLM.getAllBybookingsAll(); // Fetch all bookings instead
                }
                return bookingData;
            })
            .catch(error => {
                console.error("Error fetching data:", error);
                noResultsMessage = "No results found. Showing all bookings.";
                return BookingALLM.getAllBybookingsAll();
            });
    } else if (editID) {
        bookingPromise = BookingALLM.getAllBybookingAllid(editID).then(editData => {
            editAllbooking = editData;
            return BookingALLM.getAllBybookingsAll();
        });
    } else {
        bookingPromise = BookingALLM.getAllBybookingsAll();
    }

    bookingPromise
        .then(bookingData => {
            allAllbooking = bookingData || [];
            return Promise.all([
                usersModels.getAll(),
                SessionsActivityUserLocationM.getAllByclassactivties(),
                activitiesModel.getAll(),
                LocationModel.getAll()
            ]);
        })
        .then(([alluser, ClassOnDay, allactivittes, alllocation]) => {
            res.render("booking_view.ejs", {
                allAllbooking,
                editAllbooking,
                role: req.authenticatedUser.role, 
                alluser: alluser || [],
                ClassOnDay: ClassOnDay || [],
                alllocation: alllocation || [],
                allactivittes: allactivittes || [],
                searchTerm,
                noResultsMessage
            });
        })
        .catch(error => {
            console.error("Critical Error fetching data:", error);
            res.render("booking_view.ejs", {
                allAllbooking: [],
                editAllbooking: new bookingsModel(0, "", ""),
                role: req.authenticatedUser.role,
                alluser: [],
                ClassOnDay: [],
                alllocation: [],
                allactivittes: [],
                searchTerm,
                noResultsMessage: "An error occurred while fetching bookings."
            });
        });
}



static manageBooking(req, res) {
    const formData = req.body;
    const booking_id = validator.escape(formData.booking_id);

    if (!/^[0-9]+$/.test(formData.user_id) ||
        !/^[0-9]+$/.test(formData.Sessions_id) ||
        !/^[0-9]+$/.test(formData.activity_id)) {
        return res.render("status.ejs", {
            status: "Invalid Input",
            message: "Please enter valid IDs.",
        });
    }

    const editBooking = new bookingsModel(
        booking_id,
        validator.escape(formData.user_id),
        validator.escape(formData.Sessions_id),
        new Date,
        validator.escape(formData.activity_id),
        validator.escape(formData.location_id)
    );

    if (formData.action === "create") {
        bookingsModel.create(editBooking).then(() => res.redirect("/booking_view"));
    } else if (formData.action === "update") {
        bookingsModel.update(editBooking).then(() => res.redirect("/booking_view"));
    } else if (formData.action === "delete") {
        bookingsModel.deleteById(editBooking.id).then(() => res.redirect("/booking_view"));
    }
}
}


