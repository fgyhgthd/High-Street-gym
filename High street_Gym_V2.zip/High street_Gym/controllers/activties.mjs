import express from "express";
import validator from "validator";
import { activitiesModel } from "../models/activties.js";

import { AuthenticationController } from "./Authentication.mjs"
 export class ActivityController {
     static routes = express.Router()
    static { 
        this.routes.get("/add_activtes", AuthenticationController.restrict (["manager", "trainer"]), this. viewActivityManagement )
        this.routes.post("/edit_activity", AuthenticationController.restrict (["manager", "trainer"]), this. handleActivityManagement )
    }
 /**
  * 
  * 
  * @type { express.RequestHandler}
  */
//    to view  activites 
     static  viewActivityManagement( req, res) {
        const editID = req.query.edit_id;
          if ( editID){
             activitiesModel.getById ( editID)
             .then( editactivittes =>  {
                //   fetch activity by ID 
                 return activitiesModel .getAll ().then (  allactivittes => 
                 {
                    res.render("add_activtes.ejs",{
                        allactivittes,
                        editactivittes,
                        role: req.authenticatedUser.role
                    })
                 }

                 )
             }
                
             )
          }   else {
            //   fetch all activities 
            activitiesModel. getAll ()
            .then( allactivittes =>{
                 res.render ("add_activtes.ejs",{
                    allactivittes, 
                    role: req.authenticatedUser.role,
                    editactivittes: new activitiesModel (0,"","","")

                 });
                
            }) .catch( error => { 
                 // handle errors 
                 console.eorror ( "error fetching activities", error)
                  res.status ( 500).sent (" internal server Error ")
            })
         }
     }
 /**
     * @type {express.RequestHandler}
     */
 static handleActivityManagement(req, res) {
    const formData = req.body;

    // Extract activity_id from form data
    const activity_id = formData.activity_id;

    // Validate form data
    if (!/^[a-zA-Z\s]{2,}$/.test(formData.name)) {
        res.render("status.ejs", {
            status: "Invalid Activity Name",
            message: "Activity name must be in letters"
        });
        return;
    }
if (!/[a-zA-Z]{2,}/.test(formData.description)) {
            response.render("status.ejs", {
                status: "Invalid description",
                message: "description must be  in letters",
            });
            return;
        }
    
    
    if (!/^[0-9/\s/a-zA-Z-]{2,}$/.test(formData.duration)) {
        res.render("status.ejs", {
            status: "Invalid Duration",
            message: "Duration must be in number and letters, for example, '20 minutes'"
        });
        return;
    }

    // Create or update activity based on form data
    const editactivittes = new activitiesModel(
        validator.escape(activity_id),
        validator.escape(formData.name),
        validator.escape(formData.description),
        validator.escape(formData.duration)
    );

    // Determine and execute the CRUD operation based on the form button pressed
    if (formData.action === "create") {
        activitiesModel.create(editactivittes)
            .then(() => {
                res.redirect("/add_activtes");
            })
            .catch(error => {
                console.error("Error creating activity:", error);
                res.status(500).render("status.ejs", {
                    status: "Database Error",
                    message: "The activity could not be created"
                });
            });
    } else if (formData.action === "update") {
        activitiesModel.updateActivityById(editactivittes)
            .then(() => {
                res.redirect("/add_activtes");
            })
            .catch(error => {
                console.error("Error updating activity:", error);
                res.status(500).render("status.ejs", {
                    status: "Database Error",
                    message: "The activity could not be updated"
                });
            });
    } else if (formData.action === "delete") {
        activitiesModel.deleteById(editactivittes.activity_id)
            .then(() => {
                res.redirect("/add_activtes");
            })
            .catch(error => {
                console.error("Error deleting activity:", error);
                res.status(500).render("status.ejs", {
                    status: "Database Error",
                    message: "The activity could not be deleted"
                });
            });
    } else {
        res.render("status.ejs", {
            status: "Invalid Action",
            message: "The form doesn't support this action"
        });
    }
}
 }
