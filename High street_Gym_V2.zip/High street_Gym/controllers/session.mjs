import express from "express";
import { activitiesModel } from "../models/activties.js";
import { sessionsModel } from "../models/sessions.js";
import { SessionsActivityUserLocationM } from "../models/sessions_activity.js";

import { LocationModel } from "../models/location.js";
import { usersModels } from "../models/users.js";
import validator from "validator";
import { AuthenticationController } from "./Authentication.mjs"

export class SessionController {
    static routes = express.Router();

    static {
        this.routes.get("/booking", AuthenticationController.restrict (["members"]), this.getBooking);
        this.routes.get("/book_class", AuthenticationController.restrict (["members"]), this.getBookClass);
        this.routes.get("/Sesssions", AuthenticationController.restrict (["manager", "trainer"]), this.getSessionsBySearch);
      
        this.routes.post("/edit_class", AuthenticationController.restrict (["manager", "trainer"]), this.postEditClass);
        this.routes.get("/trainer_sessions", AuthenticationController.restrict (["trainer"]), this.getTrainerSessions);
        this.routes.post("/cancel_session", AuthenticationController.restrict (["trainer"]), this.postCancelSession);
    }
    //  view session  for member to book
    
    static getBooking(req, response) {
        const daysOfWeek = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
        const today = new Date();
    
        const mondayOfThisWeek = new Date();
        mondayOfThisWeek.setDate(today.getDate() - today.getDay());
    
        const sundayOfThisWeek = new Date(mondayOfThisWeek);
        sundayOfThisWeek.setDate(sundayOfThisWeek.getDate() + 7);
    
        const classesByDay = {
            "Monday": [],
            "Tuesday": [],
            "Wednesday": [],
            "Thursday": [],
            "Friday": [],
            "Saturday": [],
            "Sunday": [],
        };
    
        SessionsActivityUserLocationM.getAllByclassDate(mondayOfThisWeek, sundayOfThisWeek)
            .then(sessionsdateandtime => {
                const uniqueLocations = new Map();
    
                for (const session of sessionsdateandtime) {
                    const classDate = new Date(session.sessions.Sessions_datetime);
                    const dayOfWeek = daysOfWeek[classDate.getDay()];
                    classesByDay[dayOfWeek].push(session);
    
                    // Collect unique locations based on location.id
                    if (!uniqueLocations.has(session.location.id)) {
                        uniqueLocations.set(session.location.id, session.location);
                    }
                }
    
                response.render("booking.ejs", {
                    classesByDay,
                    locations: Array.from(uniqueLocations.values()), // Convert Map to array of locations
                    role:req.authenticatedUser.role
                });
            })
            .catch(error => {
                console.error("Error fetching classes by date:", error);
                response.status(500).send("Error fetching classes. Please try again later.");
            });
    }
    



    static getBookClass(req, response) {
        if (req.query.id) {
            SessionsActivityUserLocationM.getAllByclassid(req.query.id)
                .then(classes => {
                    response.render("book_class.ejs", { sessions: classes, role: req. authenticatedUser.role, userID: req.session.user.userID });
                })
                .catch(error => {
                    console.error("Error fetching class by ID:", error);
                    response.status(500).send("Error fetching class details.");
                });
        }
    }
    
    static getSessionsBySearch(req, response) {
        const { search_term, startDate, endDate, edit_id } = req.query;
    
        // If a search term is provided, fetch matching  Session  by traner  anme 
        if (search_term) {
           SessionsActivityUserLocationM.getBySearchClass(search_term)
          
                .then(allnewclessess => {
                    return Promise.all([
                        LocationModel.getAll(),
                        activitiesModel.getAll(),
                        usersModels.getAll(),
                        Promise.resolve(new sessionsModel(0, "", "", "", ""))
                    ]).then(([alllocation, allactivittes, alluser, editnewclesses]) => {
                        response.render("sessions.ejs", {
                            allnewclessess,
                            alllocation,
                            allactivittes,
                            alluser,
                            role: req.authenticatedUser.role,
                            editnewclesses,
                            localISOString
                        });
                    });
                })
                .catch(error => {
                    console.error("Error fetching search results:", error);
                    response.status(500).send("Internal Server Error");
                });
            return;  // ✅ Early return if search_term is used
        }
    
        // If startDate and endDate are provided, fetch matching  session between the dates enter 
        if (startDate && endDate) {
            SessionsActivityUserLocationM.getAllByclassDate(startDate, endDate)
                .then(allnewclessess => {
                    return Promise.all([
                        LocationModel.getAll(),
                        activitiesModel.getAll(),
                        usersModels.getAll(),
                        Promise.resolve(new sessionsModel(0, "", "", "", ""))
                    ]).then(([alllocation, allactivittes, alluser, editnewclesses]) => {
                        response.render("sessions.ejs", {
                            allnewclessess,
                            alllocation,
                            allactivittes,
                            alluser,
                            role: req.authenticatedUser.role,
                            editnewclesses,
                            localISOString

                        });
                    });
                })
                .catch(error => {
                    console.error("Error fetching date results:", error);
                    response.status(500).send("Internal Server Error");
                });
            return;  // ✅ Early return if startDate & endDate are used
        }
    
        // Default behavior if no search parameters are provided
        SessionsActivityUserLocationM.getAllByclassactivties()
            .then(allnewclessess => {
                return Promise.all([
                    LocationModel.getAll(),
                    activitiesModel.getAll(),
                    usersModels.getAll(),
                    edit_id ? sessionsModel.getById(edit_id) : Promise.resolve(new sessionsModel(0, "", "", "", ""))
                ]).then(([alllocation, allactivittes, alluser, editnewclesses]) => {
                    response.render("sessions.ejs", {
                        allnewclessess,
                        alllocation,
                        allactivittes,
                        alluser,
                        role: req.authenticatedUser.role,
                        editnewclesses,
                        localISOString
                        
                    });
                });
            })
            .catch(error => {
                console.error("Error fetching classes:", error);
                response.status(500).send("Internal Server Error");
            });
    }
    
    
        
    //  need to put  validation here
   
    
    
    static postEditClass(req, response) {
        const formData = req.body;
        const Sessions_id = validator.escape(formData.Sessions_id);

        const editClasses = new sessionsModel(
            Sessions_id,
            validator.escape(formData.Sessions_datetime),
            validator.escape(formData.location_id),
            validator.escape(formData.activity_id),
            validator.escape(formData.trainer_user_id)
        );

        const actionMap = {
            "create": () => sessionsModel.create(editClasses).then(() => response.redirect("/Sesssions")),
            "update": () => sessionsModel.update(editClasses).then(() => response.redirect("/Sesssions")),
            "delete": () => sessionsModel.deleteSessionAndBookings(editClasses.Sessions_id).then(() => response.redirect("/Sesssions"))
        };

        if (actionMap[formData.action]) {
            actionMap[formData.action]().catch(error => {
                console.error("Error processing class edit:", error);
                response.status(500).send("Internal Server Error");
            });
        }
    }

 static getTrainerSessions(req,response){
     const  trainerid = req.session.user.userID;
      SessionsActivityUserLocationM.getByTrainerId(trainerid)
      .then ( sessions => {
        // console.log (" fetched sessions ", sessions )
        response.render("trainer_sessions.ejs", { sessions, role: req.authenticatedUser.role, editsessions: null });

     

      }) .catch ( error => { 
        console.error ( " eorr feching trainer sessions : ",error)
        response.status(403).render( "status.ejs", {
            status:" No Session ",
             message:"  Session not fund "
        })
      })
 }
 static postCancelSession(req, response) {
    const formData = req.body;

    const trainerId = req.session.user.userID;

    const fieldsToValidate = ["Sessions_id", "location_id", "activity_id"];
    for (const field of fieldsToValidate) {
        if (!/^\d+$/.test(formData[field])) {
            return response.render("status.ejs", {
                status: `Invalid ${field}`,
                message: `Please enter a valid ${field.replace('_', ' ')} (numeric).`
            });
        }
    }

    if (!formData.Sessions_datetime || isNaN(Date.parse(formData.Sessions_datetime))) {
        return response.render("status.ejs", {
            status: `Invalid Sessions_datetime`,
            message: `Please enter a valid datetime (e.g., 2025-02-16 10:00:00).`
        });
    }

    const session = new sessionsModel(
        validator.escape(formData.Sessions_id),
        validator.escape(formData.Sessions_datetime),
        validator.escape(formData.location_id),
        validator.escape(formData.activity_id),
        trainerId
    );

    if (formData.action === "create") {
        sessionsModel.create(session)
            .then(() => response.redirect("/trainer_sessions"))
            .catch(err => {
                console.error(err);
                response.status(500).send("Error creating session");
            });
    } else if (formData.action === "update") {
        sessionsModel.update(session)
            .then(() => response.redirect("/trainer_sessions"))
            .catch(err => {
                console.error(err);
                response.status(500).send("Error updating session");
            });
    } else if (formData.action === "delete") {
        sessionsModel.deleteSessionAndBookings(session.Sessions_id)
            .then(() => response.redirect("/trainer_sessions"))
            .catch(err => {
                console.error(err);
                response.status(500).send("Error deleting session");
            });
    } else {
        response.status(400).send("Invalid action");
    }
}



}

function localISOString(date) {
    if (!date) return "";
    const timezoneOffset = 10;
    const offsetDate = new Date(date);
    offsetDate.setHours(offsetDate.getHours() + timezoneOffset);
    return offsetDate.toISOString().replace("Z", "").slice(0, 16);
}