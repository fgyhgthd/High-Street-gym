import express from "express";
import validator from "validator";
import { LocationModel } from "../models/location.js";

import { AuthenticationController } from "./Authentication.mjs"
export class locationController{
   static routes =  express.Router()
   static{
    locationController.routes.get( "/add_location", AuthenticationController.restrict (["manager", "trainer"]),this.viewLocationManagement  );
    locationController.routes.post  ("/edit_location",AuthenticationController.restrict (["manager", "trainer"]), this .handleLocationMangement    );

   }

   /**   
    * handles the GET request for the location managment page 
    * @type { express.requestHandler}
    */
   static  viewLocationManagement (req,res){
    const editID = req.query.edit_id ;
    LocationModel. getAll().then ((allLocations   ) =>{
       if (editID){
         return LocationModel . getById (editID) . then ((
          editlcosction
         ) =>{
          res.render("add_location.ejs",{
            allLocations ,
            editlcosction:
            editlcosction|| new LocationModel(0,""),
            role: req.authenticatedUser.role,
            
          })
         }
        )

       }
       res.render("add_location.ejs",{
      allLocations ,
      editlcosction: new LocationModel (0,""),
        role: req.authenticatedUser.role ,
      
       })
    }).catch ((error)=> {
       console. error ("Error fetching  location: ", error );
       res.status(500).send ("internal server Error ")
    })

   }


 /**   do not copy my comments 
    * handles the POST request for creating updating  or deleting locations 
    * @type { express.requestHandler}
    */





 static handleLocationMangement(req, res) {
  const formData = req.body;

  // Validate location name (only letters and spaces, min 2 characters)
  if (!/^[a-zA-Z\s]{2,}$/.test(formData.name)) {
      return res.render("status.ejs", {
          status: "Invalid Location Name",
          message: "Location name must contain only letters and spaces.",
      });
  }

  // Sanitize input data
  const location = new LocationModel(
      validator.escape(formData.location_id),
      validator.escape(formData.name)
  );

  let operation;
  if (formData.action === "create") {
      operation = LocationModel.create(location);
  } else if (formData.action === "update") {
      operation = LocationModel.update(location);
  } else if (formData.action === "delete") {
      operation = LocationModel.deleteById(location.id);
  } else {
      return res.render("status.ejs", {
          status: "Invalid Action",
          message: "Unsupported action.",
      });
  }

  operation
      .then((result) => {
          if (result?.affectedRows > 0 || formData.action === "create") {
              res.redirect("/add_location");
          } else {
              res.render("status.ejs", {
                  status: `${formData.action.charAt(0).toUpperCase() + formData.action.slice(1)} Failed`,
                  message: "Location not found.",
              });
          }
      })
      .catch((error) => {
          console.error(`Error during location ${formData.action}:`, error);
          res.render("status.ejs", {
              status: "Database Error",
              message: `Could not ${formData.action} location.`,
          });
      });
}


}
