import express from "express";
import session from "express-session";
import bcrypt from "bcryptjs";
import { usersModels } from "../models/users.js";

export class AuthenticationController {
    static middleware = express.Router();
    static routes = express.Router();

    static {
        this.middleware.use(session({
            secret: process.env.SESSION_SECRET || "9c55abf5-111d-4235-b8d8-07c3463999e7",
            resave: false,
            saveUninitialized: false,
            cookie: { secure: false } 
        }));

        this.middleware.use((req, res, next) => {+
            // console.log("Session User ID:", req.session.user?.userID);
            next();
        });

        this.middleware.use(this.#session_authentication);
        this.middleware.use(this.#api_key_authentication);

        this.routes.get("/login", this.viewAuthenticate);
        this.routes.post("/login", this.handleAuthenticate);

        this.routes.delete("/", this.handleDeauthenticate);
        this.routes.get("/logout", this.handleDeauthenticate);
    }

    static async #session_authentication(req, res, next) {
        if (req.session.user?.userID && !req.authenticatedUser) {
            try {
                req.authenticatedUser = await usersModels.getById(req.session.user?.userID);
            } catch (error) {
                console.error("Failed to authenticate user session - " + error);
            }
        }
        next();
    }

    static #api_key_authentication(req, res, next) {
        next();
    }

    static viewAuthenticate(req, res) {
        res.render("login.ejs");
    }

    static async handleAuthenticate(req, res) {
        // console.log("Received login request");
        const contentType = req.get("Content-Type");
        const email = req.body["email"];
        const password = req.body["password"];

        if (contentType == "application/x-www-form-urlencoded") {
            try {
                // console.log("Fetching user by email:", email);
                const user = await usersModels.getByemail(email);
                if (!user) {
                    // console.log("User not found");
                    return res.status(400).render("status.ejs", {
                        status: "Authentication Failed.",
                        message: "Invalid credentials."
                    });
                }

                // console.log("User found, checking password");
                const isCorrectPassword = await bcrypt.compare(password, user.password);

                if (!isCorrectPassword) {
                    // console.log("Incorrect password");
                    return res.status(400).render("status.ejs", {
                        status: "Authentication Failed.",
                        message: "Invalid credentials."
                    });
                }

                // console.log("Authentication successful, setting session");
                req.session.user = req.session.user || {};
                req.session.user.userID = user.id;
                // console.log("Session set, redirecting to /home");
                if (user.role === "manager") {
                    res.redirect("/users");
                } else if (user.role === "members") {
                    res.redirect("/booking");
                } else if (user.role === "trainer") {
                    res.redirect("/booking_view");
                }
            } catch (error) {
                // console.error("Authentication error:", error);
                res.status(500).render("status.ejs", {
                    status: "Authentication Failed.",
                    message: "Server error."
                });
            }
        } else {
            res.status(501).render("status.ejs", {
                status: "Unsupported Authentication Format.",
                message: "Credentials must be sent as URL encoded form data or JSON."
            });
        }
    }

    static handleDeauthenticate(req, res) {
        if (req.session.user?.userID) {
            req.session.destroy(() => {
                // console.log("User logged out");
                res.status(200).render("status.ejs", {
                    status: "Logged out successfully.",
                    message: "You have been logged out."
                });
            });
        } else {
            res.status(401).render("status.ejs", {
                status: "Unauthenticated.",
                message: "Please login to access the requested resource."
            });
        }
    }

    static restrict(allowedRoles) {
        return function (req, res, next) {
            if (req.authenticatedUser) {
                if (allowedRoles.includes(req.authenticatedUser.role)) {
                    next();
                } else {
                    res.status(403).render("status.ejs", {
                        status: "Access Forbidden.",
                        message: "Role does not have access to the requested resource."
                    });
                }
            } else {
                res.status(401).render("status_login.ejs", {
                    status: "Unauthenticated.",
                    message: "Please login to access the requested resource."
                });
            }
        };
    }
}
