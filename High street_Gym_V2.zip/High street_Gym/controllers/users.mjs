import express from "express";
import validator from "validator";
import { usersModels } from "../models/users.js";

import bcrypt from "bcryptjs";
import { AuthenticationController } from "./Authentication.mjs"
export class userController {
    static routes = express.Router();

    static {

        this.routes.get("/users", AuthenticationController.restrict(["manager"]), this.viewUsers);
        this.routes.post("/edit_user", AuthenticationController.restrict(["manager"]), this.handleuserEdit);
        this.routes.get("/sinup", this.viewSignup);
        this.routes.post("/edit_signup", this.handleSignup);
    }



    static viewUsers(req, res) {
        const editID = req.query.edit_id;

        if (editID) {
            Promise.all([usersModels.getById(editID), usersModels.getAll()])
                .then(([edituser, alluser]) => {
                    res.render("users.ejs", {
                        alluser,
                        edituser,
                        role: req.authenticatedUser.role
                    });
                })
                .catch(() => res.status(500).send("Internal Server Error"));
        } else {
            usersModels.getAll()
                .then(alluser =>
                    res.render("users.ejs", {
                        alluser,
                        role: req.authenticatedUser.role,
                        edituser: new usersModels(0, "", "", "", "", "", "", "")
                    })
                )
                .catch(() => res.status(500).send("Internal Server Error"));
        }
    }

    static handleuserEdit(req, res) {
        const formData = req.body;

        if (!/^[a-zA-Z]{2,}$/.test(formData.first_name)) {
            return res.render("status.ejs", {
                status: "Invalid first name",
                message: "First name must contain only letters."
            });
        }
        if (!/^[a-zA-Z-]{2,}$/.test(formData.last_name)) {
            return res.render("status.ejs", {
                status: "Invalid last name",
                message: "Last name must contain only letters."
            });
        }
        if (!/^[0-9]{10,}$/.test(formData.phone)) {
            return res.render("status.ejs", {
                status: "Invalid phone",
                message: "Please enter a valid phone number."
            });
        }
        if (!validator.isEmail(formData.email)) {
            return res.render("status.ejs", {
                status: "Invalid email",
                message: "Please enter a valid email address."
            });
        }
        if (!/^[a-zA-Z0-9-@]{6,}$/.test(formData.password)) {
            return res.render("status.ejs", {
                status: "Invalid password",
                message: "Password must be at least 6 characters long."
            });
        }

        const user = new usersModels(
            validator.escape(formData.user_id),
            validator.escape(formData.email),
            formData.password,
            validator.escape(formData.role),
            validator.escape(formData.phone),
            validator.escape(formData.first_name),
            validator.escape(formData.last_name),
            validator.escape(formData.address)
        );

        if (!user.password.startsWith("$2a")) {
            user.password = bcrypt.hashSync(user.password);
        }

        if (formData.action === "create") {
            usersModels.create(user).then(() => res.redirect("/users"));
        } else if (formData.action === "update") {
            usersModels.update(user).then(() => res.redirect("/users"));
        } else if (formData.action === "delete") {
            usersModels.delete(user.id).then(() => res.redirect("/users"));
        }
    }

    static viewSignup(req, res) {
        usersModels.getAll()
            .then(alluser => res.render("signup.ejs", {
                alluser,
                edituser: new usersModels(0, "", "", "", "", "", "", "")
            }));
    }

    static handleSignup(req, res) {
        const formData = req.body;

        if (!/^[a-zA-Z]{2,}$/.test(formData.first_name)) {
            return res.render("status.ejs", {
                status: "Invalid first name",
                message: "First name must contain only letters."
            });
        }
        if (!/^[a-zA-Z-]{2,}$/.test(formData.last_name)) {
            return res.render("status.ejs", {
                status: "Invalid last name",
                message: "Last name must contain only letters."
            });
        }
        if (!/^[0-9]{10,}$/.test(formData.phone)) {
            return res.render("status.ejs", {
                status: "Invalid phone",
                message: "Please enter a valid phone number."
            });
        }
        if (!validator.isEmail(formData.email)) {
            return res.render("status.ejs", {
                status: "Invalid email",
                message: "Please enter a valid email address."
            });
        }
        if (!/^[a-zA-Z0-9-@]{6,}$/.test(formData.password)) {
            return res.render("status.ejs", {
                status: "Invalid password",
                message: "Password must be at least 6 characters long."
            });
        }

        const user = new usersModels(
            validator.escape(formData.user_id),
            validator.escape(formData.email),
            formData.password,
            "members",
            validator.escape(formData.phone),
            validator.escape(formData.first_name),
            validator.escape(formData.last_name),
            validator.escape(formData.address)
        );

        if (!user.password.startsWith("$2a")) {
            user.password = bcrypt.hashSync(user.password);
        }

        usersModels.create(user).then(() => res.redirect("/login"));
    }
}
