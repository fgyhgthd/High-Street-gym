export default function access_control(allowedRoles) {
  return function (request, response, next) {
    if (request.session.user != null) {
      if (allowedRoles.includes(request.session.user.role)) {
        next();
      } else {
        response.render("status.ejs", {
          status: " Your Access Has Been Denied",
          message: " You are a Unauthorized Person if you  think that you should have access than you need to  conact customer service To get Access  permission     ",
        });
      }
    } else {
      response.render("status_login.ejs", {
        status: "Access Denied",
        message: "Not logged in",
      });
    }
  };
}