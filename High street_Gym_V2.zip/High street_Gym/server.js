import express from "express";
import session from "express-session";
// Import controllers
import { userController } from "./controllers/users.mjs";
 import { postController } from "./controllers/blog_post.js";
import { ActivityController  } from "./controllers/activties.mjs";
import { BookingController } from "./controllers/booking.js";
 import { locationController } from "./controllers/loctaion.mjs";
 import {  SessionController } from "./controllers/session.mjs";
 import { AuthenticationController  } from "./controllers/Authentication.mjs";
const app = express();
const port = 808;

// Middleware
app.use (express.json())
app.use(express.urlencoded({ extended: true }));

app.use(AuthenticationController.middleware)




// Use controllers
app.use(userController.routes);
 app.use(postController.routes);
 app.use(ActivityController .routes);
 app.use(BookingController.routes);
 app.use(locationController.routes);
 app.use( SessionController.routes);
 
 app.use(AuthenticationController.routes);


// Set up EJS view engine
app.set("view engine", "ejs");

// Serve static files
app.use(express.static("static"));

// Routes

// app.get("/login", (req, res) => {
//     res.render("login.ejs", {});
// });
app.use("/login", AuthenticationController.routes)


app.get("/home", (req, res) => {
    if (req.session.user) {
        res.render("home.ejs", { role: req.session.user.role });
    } else {
        res.redirect("/login");
    }
});

// Start server
app.listen(port, () => {
    console.log(`Express server started on http://localhost:${port}`);
    console.log(`Login: http://localhost:${port}/login`);
    console.log(`Add Activities: http://localhost:${port}/add_activtes`);
    console.log(`Booking View: http://localhost:${port}/booking_view`);
    console.log(`Booking View: http://localhost:${port}/users`);
});
