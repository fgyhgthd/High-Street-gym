-- MySQL dump 10.13  Distrib 8.0.36, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: high street gym
-- ------------------------------------------------------
-- Server version	8.0.36

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activities`
--

DROP TABLE IF EXISTS `activities`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activities` (
  `activity_id` int NOT NULL AUTO_INCREMENT,
  `activity_name` varchar(45) NOT NULL,
  `activity_description` varchar(1000) NOT NULL,
  `activity_duration` varchar(45) NOT NULL,
  PRIMARY KEY (`activity_id`),
  UNIQUE KEY `activity_id_UNIQUE` (`activity_id`)
) ENGINE=InnoDB AUTO_INCREMENT=124 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activities`
--

LOCK TABLES `activities` WRITE;
/*!40000 ALTER TABLE `activities` DISABLE KEYS */;
INSERT INTO `activities` VALUES (2,'yoga','Yoga is an ancient practice that combines physical postures, breathing techniques, and meditation to improve mental and physical health','30 to 45 minutes'),(7,'Pilates','Pilates uses a combination of approximately 50 simple, repetitive exercises to create muscular exertion','45 minutes to an hour'),(8,' Abs','Abdominal exercises are a type of strength exercise that affect the abdominal muscles','5 to 30 minutes '),(9,'HIIT or High-intensity Interval Training ','A training protocol alternating short periods of intense or explosive anaerobic exercise with brief recovery periods until the point of exhaustion.','30-60 minutes'),(10,' indoor cycling ','Indoor cycling is any type of indoor exercise that focuses on rotating pedals in circles','30-60 minutes daily '),(11,' Boxing ','Boxing is a sport that involves strategically punching an opponent while defending yourself from their return punches.','3 minutes for men, 2 minutes for women.'),(12,'Zumba','Zumba is an interval workout. The classes move between high- and low-intensity dance moves designed to get your heart rate up and boost cardio endurance.','1 Hour'),(74,'Pilates','A core-strengthening workout','45'),(76,'Pilates','A core-strengthening workout','45'),(78,'Pilates','A core-strengthening workout','45'),(80,'Pilates','A core-strengthening workout','45'),(82,'Pilates','A core-strengthening workout','45'),(84,'Pilates','A core-strengthening workout','45'),(88,'Pilates','A core-strengthening workout','45'),(90,'Pilates','A core-strengthening workout','45');
/*!40000 ALTER TABLE `activities` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `blog_post`
--

DROP TABLE IF EXISTS `blog_post`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `blog_post` (
  `post_id` int NOT NULL AUTO_INCREMENT,
  `post_datetime` datetime NOT NULL,
  `post_user_id` int NOT NULL,
  `post_title` varchar(45) NOT NULL,
  `post_content` varchar(100) NOT NULL,
  PRIMARY KEY (`post_id`),
  UNIQUE KEY `post_id_UNIQUE` (`post_id`),
  KEY `user_bolg_post_fk_idx` (`post_user_id`),
  CONSTRAINT `user_bolg_post_fk` FOREIGN KEY (`post_user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=181 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `blog_post`
--

LOCK TABLES `blog_post` WRITE;
/*!40000 ALTER TABLE `blog_post` DISABLE KEYS */;
INSERT INTO `blog_post` VALUES (133,'2025-03-12 08:49:41',15,'sttaf','sattDS'),(137,'2024-11-19 03:41:16',81,'tetst','tes tes tes ts New '),(141,'2025-02-12 00:50:42',15,'test',' test test '),(142,'2024-10-08 10:52:13',15,'Do  gym every day ','As sky is not the limit'),(147,'2024-11-06 03:56:29',81,'test','test test test and r'),(153,'2025-01-29 02:41:29',15,'tome','mayur'),(154,'2025-02-01 07:12:19',97,'test test te','test test ts '),(156,'2025-02-01 08:55:21',97,'mayur','mayur'),(161,'2025-02-13 00:35:48',97,'mayur','mayur'),(162,'2025-02-13 00:36:34',97,'mayur ','testing '),(163,'2025-02-13 00:39:37',62,' tome ','tioem'),(164,'2025-02-14 08:02:34',97,'jack','jkack'),(165,'2025-02-22 02:28:39',62,'unfortunately ','test'),(166,'2025-02-24 23:27:14',142,'test','mayur'),(167,'2025-02-25 08:50:23',62,' tafe','tafe'),(175,'2025-03-01 11:38:23',97,'Pot','bhagt'),(177,'2025-03-03 23:15:15',62,'mayur','mayur'),(178,'2025-03-12 08:44:12',97,'Mayur','mayur ');
/*!40000 ALTER TABLE `blog_post` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `bookings`
--

DROP TABLE IF EXISTS `bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `bookings` (
  `booking_id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `Sessions_id` int NOT NULL,
  `booking_created_datetime` datetime DEFAULT CURRENT_TIMESTAMP,
  `activity_id` int NOT NULL,
  `location_id` int NOT NULL,
  PRIMARY KEY (`booking_id`),
  UNIQUE KEY `booking_id_UNIQUE` (`booking_id`),
  KEY `users_bookings_fk_idx` (`user_id`),
  KEY `classes_booking_id_idx` (`Sessions_id`),
  KEY `activities_bookings_fk_idx` (`activity_id`),
  KEY `location_bookings.fk_idx` (`location_id`),
  CONSTRAINT `activities_bookings_fk` FOREIGN KEY (`activity_id`) REFERENCES `activities` (`activity_id`),
  CONSTRAINT `classes_bookings_id` FOREIGN KEY (`Sessions_id`) REFERENCES `sessions` (`Sessions_id`),
  CONSTRAINT `lacation_bookings_fk` FOREIGN KEY (`location_id`) REFERENCES `location` (`location_id`),
  CONSTRAINT `users_bookings_fk` FOREIGN KEY (`user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=579 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `bookings`
--

LOCK TABLES `bookings` WRITE;
/*!40000 ALTER TABLE `bookings` DISABLE KEYS */;
INSERT INTO `bookings` VALUES (563,98,224,'2025-03-31 12:18:17',2,2),(565,63,225,'2025-03-31 12:18:29',2,2),(566,57,224,'2025-03-31 12:18:33',2,2),(577,62,226,'2025-04-01 12:22:42',2,2),(578,97,226,'2025-04-03 09:45:36',2,2);
/*!40000 ALTER TABLE `bookings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `location`
--

DROP TABLE IF EXISTS `location`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `location` (
  `location_id` int NOT NULL AUTO_INCREMENT,
  `location_name` varchar(45) NOT NULL,
  PRIMARY KEY (`location_id`),
  UNIQUE KEY `location_id_UNIQUE` (`location_id`)
) ENGINE=InnoDB AUTO_INCREMENT=141 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `location`
--

LOCK TABLES `location` WRITE;
/*!40000 ALTER TABLE `location` DISABLE KEYS */;
INSERT INTO `location` VALUES (2,'Brisbane City'),(100,'Chermside'),(102,'Graceville'),(103,'Westlake'),(132,'Ashgrove');
/*!40000 ALTER TABLE `location` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `Sessions_id` int NOT NULL AUTO_INCREMENT,
  `Sessions_datetime` datetime DEFAULT CURRENT_TIMESTAMP,
  `location_id` int NOT NULL,
  `activity_id` int NOT NULL,
  `trainer_user_id` int NOT NULL,
  PRIMARY KEY (`Sessions_id`),
  UNIQUE KEY `class_id_UNIQUE` (`Sessions_id`),
  KEY `location_classes_fk_idx` (`location_id`),
  KEY `activity_classes_fk_idx` (`activity_id`),
  KEY `users_classes_fk_idx` (`trainer_user_id`),
  CONSTRAINT `activity_classes_fk` FOREIGN KEY (`activity_id`) REFERENCES `activities` (`activity_id`),
  CONSTRAINT `location_classes_fk` FOREIGN KEY (`location_id`) REFERENCES `location` (`location_id`),
  CONSTRAINT `users_classes_fk` FOREIGN KEY (`trainer_user_id`) REFERENCES `users` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=227 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
INSERT INTO `sessions` VALUES (156,'2024-10-30 13:04:00',2,74,103),(172,'2024-11-14 13:44:00',102,7,128),(176,'2024-11-21 13:25:00',100,7,131),(178,'2024-12-03 12:27:00',100,11,63),(179,'2024-12-04 12:27:00',100,11,97),(180,'2024-12-05 03:13:00',2,2,131),(181,'2025-01-29 10:00:00',2,2,79),(182,'2025-02-03 10:00:00',2,7,97),(184,'2025-02-03 10:00:00',2,2,78),(185,'2025-02-03 10:00:00',100,90,111),(186,'2025-02-02 10:00:00',2,2,63),(195,'2025-02-20 10:17:00',2,7,57),(196,'2025-02-16 11:26:00',2,7,15),(197,'2025-02-16 11:26:00',2,7,63),(198,'2025-02-23 15:13:00',2,12,98),(202,'2025-02-23 10:54:00',2,12,57),(203,'2025-02-27 17:32:00',2,7,15),(204,'2025-03-05 09:30:00',2,2,15),(205,'2025-03-05 09:30:00',2,2,63),(206,'2025-03-06 09:32:00',102,7,78),(208,'2025-03-04 06:26:00',2,8,81),(209,'2025-03-06 05:33:00',103,8,15),(211,'2025-03-05 05:43:00',2,11,57),(215,'2025-03-04 07:28:00',2,7,57),(216,'2025-03-03 12:37:00',2,2,63),(217,'2025-03-12 00:00:00',2,7,78),(218,'2025-03-12 00:27:00',2,7,57),(219,'2025-03-12 23:26:00',100,7,57),(222,'2025-03-14 11:00:00',100,9,63),(224,'2025-03-16 01:09:00',2,2,96),(225,'2025-03-19 15:07:00',100,2,57),(226,'2025-04-01 10:00:00',2,2,57);
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `user_email` varchar(45) NOT NULL,
  `user_password` varchar(100) NOT NULL,
  `user_role` enum('manager','trainer','members') NOT NULL,
  `user_phone` varchar(45) NOT NULL,
  `user_first_name` varchar(45) NOT NULL,
  `user_last_name` varchar(45) NOT NULL,
  `user_address` varchar(45) NOT NULL,
  `user_auth_key` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `users_id_UNIQUE` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=149 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (15,'mayurbhagat@outlook.com','$2a$10$Xk0SQifTYAdjGZYvwQSnnuGcJg9U.6o5oKySmpAongE0W46t2gkR.','manager','040550654473','Name','bhaget','17 dan rood ','10894739-c133-4286-af52-3c80be7581fc'),(57,'tomeS@outlook.com','$2a$10$3u1/PAKBk4kJ21RVdq4MYuFKKs9ZreCwZcaOUFmz9b9y88cZgl27K','trainer','0405506601','jack','bahgs',' tham to and 24',NULL),(62,'mayurbhagat1@outlook.com','$2a$10$/5AXOCnDX9hhqew2djZK4OBVDZWslWmqud6u8o.qvrl5QPZYA68we','members','0490942246','Unknown','BHAGAT','6',NULL),(63,'dom@outlook.com.au','$2a$10$D8p4WknWB6yZrSnsDPcqXeYzfnWHrRuWxfne37I.lJNJEIeSgA03m','trainer','0490942246','dom','hq','6',NULL),(77,'mayurbhagat1@outlook.com ','$2a$10$gN2KnPQmjcjMgtrFX0E/ZO2yyTEKidSk7YCDA1D3DvLekTc3l2F6O','members','0490942246','test','test','6',NULL),(78,'manager.@outlook.com.au','$2a$10$ZTB1pKnsBu2CTv0Z1W5mUum8DyGydssosr3yOAH9Z1M/WacHp4Y9q','trainer','0490942246','manger','manager','6',NULL),(79,'tom@outlook.com','$2a$10$SzW7oLaXPwzwjim4kwBGNOXpHM8G3ZGQdIBiaoJTO/2tNmU9Qh35.','trainer','0401155623','pan','HPsrt','6 ABBOT CIRCUIT',NULL),(81,'Tome1@outlook.com','$2a$10$hOvGpaA9kn6oYiCMQCu7HOhOO3HCGfGQXEbTudIIgcnkkERAbGyK6','members','04587845168','tomy','mbers','12 testing street goodan ',NULL),(96,'sam@yahoo.com','$2a$10$xwWCh4pE2qBsHabN2iQq9Ob16vh6jJMwUKnSllVKJTj1ugCpIgYOm','trainer','0412548789','Same ','  gan ',' 14 Brisbane rock',NULL),(97,'jack@yahoo.com','$2a$10$jEl91thf1cTuALsoc5O1UewqPLY2/BVfe6V/D4ZPvvNKmJy9UayxW','members','04055088074','jack','pan','14 Australian Queensland Street',NULL),(98,'Tgon@tgon.com.au','$2a$10$bBjfQX5TkZVb.86enJ0sweiOGLttGRU5O6uHhRGaLiyRqhjM4I9lO','members','04055022031',' Tgon','hqplot','16 computer Brisbane RD',NULL),(100,'TESTING@.OUTLOOK.COM','$2a$10$WcYbq6wpCx/xLSCxFNnP8.EOG5p6Cz8dU4K2VG6pun3vXF9ehKjNe','members','01234567891','TESTING','TESTING ','3',NULL),(101,'123@outlook.com.au','$2a$10$KNu5c.BEy/r46MGs4NJpxu8yyU9GAydBsTMO4DdxQjcylO9zPllxe','members','0412345678','gun','gun','5',NULL),(102,'test@outlook.com','$2a$10$4.ThY/IEYsHi6Xyow1dtYeBOz1aEO5V.5fj4w.rCVSphtYNEsA1/6','manager','04022034324','TESTING','TESTING','15 abc',NULL),(103,'h@outlook.com','$2a$10$MwQ7uskBht/YUyO5iPUpgutFF07dOzdz8xz4XOZ5Y0YfMPndMLMJm','manager','0573686473','ter','bhagat','15 bne',NULL),(104,'t@oitlokk.com','$2a$10$vYkOut3JLvGUMf.rg0MV..Vww.7A8c82a0ZP/sPTynz9pw1sbGso6','trainer','0483784283','TESTING','testing','15 bne',NULL),(105,'6747@outlook.com','$2a$10$vJB2LjODc8JPzA2ARMnLqOwqoGoAxhnz.SN1U9CCVzhBhw/4zUBce','manager','04055022031','mayur','bhagat','15 ben',NULL),(106,'4300@outlok.com','$2a$10$tE4lOdMBYG69oJEzJgpfieE/lyzUkbXTbewe9gU9GKjlyyDNHHytS','members','014573683671','bhagat','mayu','14 Australian Queensland Street',NULL),(107,'testuser@example.com','$2a$10$5ZMoVBcSCW0VGU5/m356mexrjquepiHMCcel2l2mv7Tv7irx/5sAK','members','1234567890','John','Doe','123 Main St, Anytown, USA',NULL),(108,'Cestuser@example.com','$2a$10$xI5nBGjUIad.F9gVTM587uYYXZ0qUgpWCmY/Xeiw97BegaAChwBtm','members','1234567890','John','Doe','123 Main St, Anytown, USA',NULL),(109,'Cestuser@example.com','$2a$10$qSLy13w0a2oi1RwLjVe53.PohDhnLpvEfQx6yMMGtUJuliSkylEya','members','1234567890','John','Doe','123 Main St, Anytown, USA',NULL),(110,'Cestuser@example.com','$2a$10$F113n8lcjoRiTqbcBcRQ0OhuN9ktHoUKp8OO4LZN37O6cIdB6SRvq','members','1234567890','John','Doe','123 Main St, Anytown, USA',NULL),(111,'Cestuser@example.com','$2a$10$0Wo6RmswOgSRJ.2XSCXqQuY5onquICPd1d6CkLQQnYSwbjZ.Rxq2O','members','1234567890','John','Doe','123 Main St, Anytown, USA',NULL),(112,'Cestuser@example.com','$2a$10$L9DGKVLPs/ovOlQ9XVqE7ek/a0tRsrQGokQIMCB4u3YmCUzHavnSO','members','1234567890','John','Doe','123 Main St, Anytown, USA',NULL),(113,'Cestuser@example.com','$2a$10$zs396oo2zUsexA654cIv9.DAx2Ke7wcEUE17XA9RvRYRjs5VL75bi','members','viren001@','John','Doe','123 Main St, Anytown, USA',NULL),(114,'0estuser@example.com','$2a$10$DTzk10MU4Wet.PAy0ra0SOqbMnOLOyYj7ciDUJg0jG9EXFJVVFZfi','members','0490942246','John','Doe','123 Main St, Anytown, USA',NULL),(115,'mayurbhagat@outlook.com','$2a$10$yki7c1pGy85bp3ctrE8n2.rZR./jS6SrHf1NxbFGnwBpJeppiUk0.','members','0401155623','VIRENDRA','BHAGAT','6 ABBOT CIRCUIT',NULL),(116,'mayurbhagat@outlook.com','$2a$10$Cqc0Xo1JbN.QxDqP1ggHKuSAjrHLh4/strcIq0WtTgAoX50Y.nDUa','members','0401155623','VIRENDRA','BHAGAT','6 ABBOT CIRCUIT',NULL),(117,'mayurbhagat@outlook.com','$2a$10$2EkCaYPTCisvaAG4M1vBruoBKN49XmjF/ygao./zT5nCTMHnZgK6e','members','0490942246','mayur','BHAGAT','6',NULL),(118,'testinf@outlok.com','$2a$10$joritwJbWyWiQcUkTO06ouuVBww2d8Jpt4AGQaJaPf4/runfIamP2','members','0490942246','mayur','BHAGAT','6',NULL),(119,'T4@outlook.com','$2a$10$z3AOm0cP1LBwxtCsXRIcJ.za1z5oPPPY/pE5J.D12Go1qTX2jZ7.a','members','0490942246','mayur','BHAGAT','6',NULL),(120,'test@outlook.com','$2a$10$c664qcAiIgpbLbnW1VerteTj6W9hj.JFsCKps0.xmRZKsvy0B5MtK','members','0490942246','mayur','BHAGAT','6',NULL),(121,'NEWW2@outlokk.com','$2a$10$69jMF.Sp8YoPf2rnVjzNS.cQ7zor/ps5Y4ZCU4TTX8f35Ch9Xo1oy','members','0490942246','NEW','BHAGAT','6',NULL),(122,'testuser@example.com','$2a$10$rwQm7mDvDUjq1W3ADIejA.VrwQWhGTpKb2UwK3/xseeYUi7GWoXFi','members','1234567890','John','Doe','123 Main St, Anytown, USA',NULL),(123,'Tome@outlook.com.au','$2a$10$A4x.v.ky6FwAd.i/lZzdv./8780WZloJQjJcuss77rzyi6evIF.0y','members','0490942246','tome','BHAGAT','6',NULL),(124,'testing@outlook.com','$2a$10$tubj4T5C2RZCWiIMwsI85u2QDxiCEPIw9ZUBEfu68TyreaIwzHId6','members','0490942246','mayur','BHAGAT','6',NULL),(125,'Tome@outlook.com.au','$2a$10$kJMuO0tAQ1tCPh.QXbBR6uXba42Xj2r.HeqVE32Sa9QZyHtGQNqbK','members','0490942246','mayur','BHAGAT','6',NULL),(126,'pot@outlook.com.au','$2a$10$CeHhOcSNlGEqlyxLVS6WwuQEBOMu1wViVhS/XpuWzYEwDnoPzoawS','members','0490942246','pot','BHAGAT','6',NULL),(127,'498@otulook.com','$2a$10$egddxdcMe0AczPwqXjtvbOvRD9kP5KfCt6EMRU3hsMoF5/ssD.cXq','members','408489549004','mayur','maurutio',' 4 hguhgh',NULL),(128,'like@outlook.com','$2a$10$T5DGUNcayOgyHYVFctz3be79yMrAE5KGOSdAxA.VFmr4vkUZqq60q','trainer','0490942246','Luke','BHAGAT','6',NULL),(129,'Laim@outlook.com.au','$2a$10$mvlwSLHeDF7Y.gKgQFxaPecVnQV0eFAfw1ySfyKBSXQ9/DLeLAGOK','trainer','0490942246','testing','liam','6',NULL),(130,'Tome@outlook.com.au','$2a$10$kbozmAjLqOA1o1WxmO6IieRYBUfyDV2edQyF1s91swOQTu/9EbluO','members','014573683671','mayur','bhagat','19 abbitt circuit bellbird park',NULL),(131,'not@outlook.com','$2a$10$8TMEdg.U.dhyS39UuFZ8pud21Xe5RVF63ixRhwEAKn/BCZ1l3iv7q','trainer','04983948984','not','not','5 tyruhuhhtifg',NULL),(134,'mayurbhagat1@outlook.com','$2a$10$7LCdUERBIsDdJfz6PMOhLeqh.0sN/DhFZf1Pt.5JA2RM5jq3LlkK2','manager','0490942246','mayur','BHAGAT','6',NULL),(135,'mayurbhagat1@outlook.com','$2a$10$WRhW.cG6zGL.8LlgerEYx.WlpDBAJDxCpdZioiotVSPmtT8NMcthS','manager','0490942246','mayur','BHAGAT','6',NULL),(136,'mayurbhagat1@outlook.com','$2a$10$aJgVUR2eO3HBoUoZHlS.p.zKT4XNF9RYM2RuGWNH0qqdlrgl.HeWO','members','0490942246','mayur','BHAGAT','6',NULL),(137,'mayurbhagat1@outlook.com','$2a$10$KPtVYtt2WiD5cO5LCXbbXO0Jlfs9FBvlwacYmJSqD/UgrEx0nLJXq','manager','0490942246','mayur','BHAGAT','6',NULL),(141,'mayurbhagat0@outlook.com.au','$2a$10$KKfqqWG2PvAJ/w4iLCw0uODN/o5Af90qx5MVHHrCO8XKstHLyLXC.','members','0490942246','mayur','BHAGAT','6',NULL),(142,'nee@outlook.com.au','$2a$10$8XS6Z4xOFVmCSTYOO8sgX.VXgXzCgMSinPCBKWs.5vhWYuA50M3Vm','trainer','408489549004','test','tes','6 abbot',NULL),(143,'mayur@nmayur.com','$2a$10$Myr5iNK/8URQNbe6CRmKrOmUkC8RXaly0f3Ui8PPfqYlxei2vjcmO','members','0490942246','mayur','BHAGAT','6',NULL),(144,'mayurbhagat1@outlook.com','$2a$10$pdNVO6SizeoXALOjRZQ6VuREGA46jKdt6jhDt1t.pPUbxCduzEUd6','members','0490942246','remove','BHAGAT','6',NULL),(145,'jack@yahoo.com','$2a$10$BTZFy2YLmlI4WVzm9eQJAu9LnAFq/F5zCfNyNEgs1XqPODCaXDd6C','members','0490942246','mayur','BHAGAT','6',NULL),(146,'user@outlook.com.au','$2a$10$dqT.gVT8j9vT/mZNm05gKuYAhmTSa92mBzzOX28Jqwkd6z/EeoVJe','manager','04055088071','GitHub','User','6 pan rode ride ',NULL),(147,'trainer@oulook.com','$2a$10$4Qv7iH0FqhOUzjSSgrgHL.F98UIrvncT9Mzt5KPmWznSgI9tdXQK.','trainer','0402202251','GitHub','trainer','not',NULL),(148,'m@yahoo.com','$2a$10$eGIfrhUieI.fbQpN6Ed4.ueo4pi1kFJ7bBRwHpiWczQnfIuwtLsBC','members','0407777987','GitHub','members','not',NULL);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-04-03  9:54:11
