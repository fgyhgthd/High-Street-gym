import { DatabaseModel } from "./databaseModel.mjs";

export class Blog extends DatabaseModel {

    constructor(post_id, post_datetime, post_user_id, post_title, post_content) {
        super();
        this.post_id = post_id;
        this.post_datetime = post_datetime;
        this.post_user_id = post_user_id;
        this.post_title = post_title;
        this.post_content = post_content;
    }

    /**
     * Converts a database row into a Blog instance
     * @param {Object} row
     * @returns {Blog}
     */
    static tableToModel(row) {
        if (row.blog_post ) {
  row=row.blog_post // Adjust for nested structure 
        }
        return new Blog(
            row["post_id"],
            row["post_datetime"],
            row["post_user_id"],
            row["post_title"],
            row["post_content"]
        );
    }

    /**
     * Fetch all blog posts
     * @returns {Promise<Blog[]>}
     */
    static getAll() {
        return this.query("SELECT * FROM blog_post")
            .then(results => results.map(row => this.tableToModel(row)))
            .catch(error => {
                console.error("Error fetching blog posts:", error);
                throw error;
            });
    }

    /**
     * Fetch a blog post by ID
     * @param {number} post_id
     * @returns {Promise<Blog>}
     */
    static getById(post_id) {
        return this.query("SELECT * FROM blog_post WHERE post_id = ?", [post_id])
            .then(results => results.length > 0 ? this.tableToModel(results[0]) : Promise.reject("Post not found"))
            .catch(error => {
                console.error("Error fetching blog post:", error);
                throw error;
            });
    }

    /**
     * Fetch a blog post by post_title
     * @param {string} post_title
     * @returns {Promise<Blog>}
     */
    static getByTitle(post_title) {
        return this.query("SELECT * FROM blog_post WHERE post_title = ?", [post_title])
            .then(results => results.length > 0 ? this.tableToModel(results[0]) : Promise.reject("Title not found"))
            .catch(error => {
                console.error("Error fetching blog post by post_title:", error);
                throw error;
            });
    }

    /**
     * Update a blog post
     * @param {Blog} post
     * @returns {Promise<void>}
     */
    static update(post) {
        return this.query(`
            UPDATE blog_post SET 
            post_datetime = ?, 
            post_user_id = ?, 
            post_title = ?, 
            post_content = ? 
            WHERE post_id = ?`, [
            post.post_datetime,
            post.post_user_id,
            post.post_title,
            post.post_content,
            post.post_id
        ]);
    }

    /**
     * Create a new blog post
     * @param {Blog} post
     * @returns {Promise<void>}
     */
    static create(post) {
        return this.query(`
            INSERT INTO blog_post (post_datetime, post_user_id, post_title, post_content) 
            VALUES (?, ?, ?, ?)`, [
            post.post_datetime,
            post.post_user_id,
            post.post_title,
            post.post_content
        ]);
    }

    /**
     * Delete a blog post by ID
     * @param {number} post_id
     * @returns {Promise<void>}
     */
    static deleteById(post_id) {
        return this.query("DELETE FROM blog_post WHERE post_id = ?", [post_id]);
    }
}

// Testing the Blog class
// Blog.getAll()
//     .then(posts => console.log(posts))
//     .catch(error => console.error(error));

// Example of creating a blog post
// const testPost = new Blog(null, "2024-02-06 12:00:00", 1, "Test Post", "This is a test blog post.");
// Blog.create(testPost)
//     .then(() => console.log("Post created successfully"))
//     .catch(error => console.error(error));
