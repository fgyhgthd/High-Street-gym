
import { DatabaseModel } from "./databaseModel.mjs";
 import{usersModels} from"./users.js"
 import{LocationModel} from"./location.js"
 import {activitiesModel}from"./activties.js"
 import{ sessionsModel}from "./sessions.js"


  export class SessionsActivityUserLocationM  extends DatabaseModel{
    //   instance 
    constructor( users,location,activities,sessions){
      super()
        this .users =users
         this.location = location
          this . activities =activities
          this . sessions = sessions
      
    }
    static tableToModel(row){
       return new SessionsActivityUserLocationM (
        usersModels.tableToModel(row.users),
         LocationModel. tableToModel (row.location),
         activitiesModel.  tableToModel ( row.activities),
         sessionsModel. tableToModel  ( row. sessions)
       )
    }
/**
     * 
     * @param {string}  getAll filter by
     * @returns {Promise<Array<OrderProductModel>>}
     */
  static getAllByclassactivties(getAll) {
      return this.query(
          `
          SELECT * FROM sessions
          INNER JOIN activities ON sessions.activity_id = activities.activity_id
          INNER JOIN location ON sessions.location_id = location.location_id
          INNER JOIN users ON sessions.trainer_user_id = users.user_id
          `
          , [getAll]
      )

      .then(result => result.map(row => this.tableToModel(row)))
  }


   /**
     * 
     * @param {number} id 
     * @returns {Promise<SessionsActivityUserLocationM>}
     */
  static getAllByclassid(sessionsID) {
    console.log("Searching for Sessions_id:",sessionsID);
    return this.query(
        `
        SELECT * FROM sessions
        INNER JOIN activities ON sessions.activity_id = activities.activity_id
        INNER JOIN location ON sessions.location_id = location.location_id
        INNER JOIN users ON sessions.trainer_user_id = users.user_id
        WHERE sessions.Sessions_id = ?
        `,
        [sessionsID]
    )  .then(result =>
      result.length > 0
          ? this.tableToModel(result[0])
          : Promise.reject("not found")
  )
}



//   testing  all  by 


static getBySearchClass(searchTerm, startDateTime, endDateTime) {
  // Convert searchTerm to lowercase for case-insensitive search
  // const adjustedSearchTerm = `%${search_Term.toLowerCase()}%`;
  console.log("Search Term:", searchTerm);
  // console.log("Start Date:", startDateTime);
  // console.log("End Date:", endDateTime);

  return this.query(
    `
    SELECT * FROM sessions
    INNER JOIN activities ON sessions.activity_id = activities.activity_id
    INNER JOIN location ON sessions.location_id = location.location_id
    INNER JOIN users ON sessions.trainer_user_id = users.user_id
    WHERE (
            users.user_first_name = ? 
            OR (sessions.Sessions_datetime >= ? AND sessions.Sessions_datetime <= ?) 
        )
   
    `,
    [searchTerm, startDateTime, endDateTime]
  )
  .then(result => {
    console.log("Query Result:", result);
    return result.length > 0
      ? result.map(row => this.tableToModel(row))
      : [];
  });
}




//    Get Classes  within Date range  fo /booking members   

static getAllByclassDate(startDate, endDate) {
  const adjustedStartDate = new Date(startDate).toISOString().slice(0, 19).replace('T', ' ');
  const adjustedEndDate = new Date(endDate).toISOString().slice(0, 19).replace('T', ' ');

  console.log("Fetching sessions from:", adjustedStartDate, "to", adjustedEndDate);

  return this.query(
    `
    SELECT * FROM sessions
    INNER JOIN activities ON sessions.activity_id = activities.activity_id
    INNER JOIN location ON sessions.location_id = location.location_id
    INNER JOIN users ON sessions.trainer_user_id = users.user_id
    WHERE sessions.Sessions_datetime BETWEEN ? AND ?
    `,
    [adjustedStartDate, adjustedEndDate]
  )
    
  .then(result => result.map(row => this.tableToModel(row)))


}
// Get Classes by Trainer ID
static getByTrainerId(userID) {
  return this.query(
    `
    SELECT * FROM sessions
    INNER JOIN activities ON sessions.activity_id = activities.activity_id
    INNER JOIN location ON sessions.location_id = location.location_id
    INNER JOIN users ON sessions.trainer_user_id = users.user_id
    WHERE sessions.trainer_user_id = ?
    `,
    [userID]
  ).then(result =>
    result.length > 0
      ? result.map(row => this.tableToModel(row))
      : Promise.reject(`No sessions found for trainer ID ${userID}`)
  );
}
}
//   testing  getAllbyclassDate
// const startDate = '2025-02-18'; // Replace with your desired start date (YYYY-MM-DD)
// const endDate = '2025-02-21';   // Replace with your desired end date (YYYY-MM-DD)

// SessionsActivityUserLocationM.getAllByclassDate(startDate, endDate)
//   .then((sessions) => {
//     console.log('Sessions found within date range:', sessions);
//   })
//   .catch((error) => {
//     console.error('Error fetching sessions by date range:', error);
//   });

  //   testing getByTrainerid

// const userIdToFetch = 57; 
// SessionsActivityUserLocationM. getByTrainerId(userIdToFetch)
//    .then(user => {
//      if (user) {
//      console.log("User found:", user);
//     } else {
//        console.log(`No user found with ID ${userIdToFetch}.`);
//      }
//    })
//    .catch(error => console.error("Error fetching user:", error));







///////////////////////////////////////////////////////////////////////////////////// need to go  if not needed ///////////////////////////////////////////////////////////////////////////////////////////
// export function getBySearchClass(searchTerm) {
//     return db_conn.query(
//         "SELECT * FROM sessions WHERE Class_removed = 0 AND (  trainer_user_id = ?)",
//         [`%${searchTerm}%`]
//     ).then(([queryResult]) => {
//         // convert each result into a model object
//         return queryResult.map(
//             result =>  classesactivity(
//                 result.Sessions_id,
//                 result.Class_datetime,
//                 result.location_id,
//                 result.trainer_user_id,
//                 result.activity_id,
//                 result.activity_name,
//                 result.activity_description,
//                 result.activity_duration, 
//                 result.location_name,
//                 result.   user_id,
//                 result.user_email,
//                 result.user_password,
//                 result.user_role,
//                 result.user_phone,
//                 result. user_first_name,
//                 result.user_last_name,
//                 result.user_address,
            
//             )
//         )

//     })
// }
// export function getBySearchClass(searchTerm) {
  // return db_conn.query(
      // `
      // SELECT * FROM sessions
      // INNER JOIN activities ON sessions.activity_id = activities.activity_id
      // INNER JOIN location ON sessions.location_id = location.location_id
      // INNER JOIN users ON sessions.trainer_user_id = users.user_id
      // WHERE sessions.Class_removed = 0 
        // AND (users.user_first_name = ? OR sessions.Class_datetime = ?)
      // `,
      // [searchTerm, searchTerm] // Assuming searchTerm can represent both user_id and Class_datetime
  // ).then(([queryResult]) => {
      // convert each result into a model object
      // return queryResult.map(result => new classesactivity(
          // result.Sessions_id,
          // result.Class_datetime,
          // result.location_id,
          // result.location_name,
          // result.activity_id,
          // result.activity_name,
          // result.activity_description,
          // result.activity_duration,
          // result.trainer_user_id,
          // result.user_email,
          // result.user_password,
          // result.user_role,
          // result.user_phone,
          // result.user_first_name,
          // result.user_last_name,
          // result.user_address
      // ));
  // });
// }




//   const searchTerm = "tome"; // Example: Trainer's first name

//  SessionsActivityUserLocationM.getBySearchClass(searchTerm)
//   .then((sessions) => {     console.log("Search Results:", sessions);
//   })
//   .catch((error) => {
//      console.error("Error:", error);
//   });
