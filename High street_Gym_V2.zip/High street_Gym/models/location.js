import { DatabaseModel } from "./databaseModel.mjs";

export class LocationModel extends DatabaseModel {
  // Instance constructor
  constructor(id, name) {
    super();
    this.id = id;
    this.name = name;
  }

  // Convert database row to Location model
  static tableToModel(row) {
    // Extract the nested object if necessary
    const locationData = row.location || row; // Ensure it works in both cases

    return new LocationModel(
      locationData["location_id"], // Extract correctly
      locationData["location_name"]
    );
  }

  /**
   * @returns {Promise<Array<LocationModel>>}
   */
  static getAll() {
    return this.query("SELECT * FROM location")
      .then((result) => {
        console.log("Raw DB Result:", result); // Debugging output
        const rows = Array.isArray(result) ? result : result[0];
        return rows.map((row) => this.tableToModel(row));
      })
      .catch((error) => {
        console.error("Database Error in getAll:", error);
        throw error;
      });
  }

  // Create a new location
  static create(location) {
    return this.query(`INSERT INTO location (location_name) VALUES (?)`, [
      location.name,
    ]).catch((error) => {
      console.error("Database Error in create:", error);
      throw error;
    });
  }

  // Update a location
  static update(location) {
    return this.query(
      `UPDATE location SET location_name = ? WHERE location_id = ?`,
      [location.name, location.id]
    ).catch((error) => {
      console.error("Database Error in update:", error);
      throw error;
    });
  }

  // Delete a location by ID
  static deleteById(locationId) {
    return this.query("DELETE FROM location WHERE location_id = ?", [
      locationId,
    ]).catch((error) => {
      console.error("Database Error in deleteById:", error);
      throw error;
    });
  }

  // Get location by ID
  static getById(locationId) {
    return this.query("SELECT * FROM location WHERE location_id = ?", [
      locationId,
    ])
      .then((result) => {
        console.log("Raw DB Result for getById:", result); // Debugging output

        const rows = Array.isArray(result) ? result : result[0];
        return rows.length > 0
          ? this.tableToModel(rows[0])
          : Promise.reject("Not found");
      })
      .catch((error) => {
        console.error("Database Error in getById:", error);
        throw error;
      });
  }

  // Get location by name
  static getByName(location_name) {
    return this.query("SELECT * FROM location WHERE location_name = ?", [
      location_name,
    ])
      .then((result) => {
        console.log("Raw DB Result for getByName:", result); // Debugging output

        const rows = Array.isArray(result) ? result : result[0];
        return rows.length > 0
          ? this.tableToModel(rows[0])
          : Promise.reject("Not found");
      })
      .catch((error) => {
        console.error("Database Error in getByName:", error);
        throw error;
      });
  }
}

// Testing
// LocationModel.getAll()
//   .then((locations) => console.log("Locations:", locations))
//   .catch((error) => console.error("Error fetching locations:", error));
