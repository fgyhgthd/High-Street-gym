import { usersModels} from "./users.js";
import { LocationModel } from "./location.js";
import { activitiesModel } from "./activties.js";
import { sessionsModel } from "./sessions.js";
import { bookingsModel } from "./bookings.js";
import { DatabaseModel } from "./databaseModel.mjs";

export class BookingALLM extends DatabaseModel {
    constructor(users, location, activities, sessions, bookings) {
        super();
        this.user = users;
        this.location = location;
        this.activities = activities;
        this.sessions = sessions;
        this.bookings = bookings;
    }

    static tableToModel(row) {
        return new BookingALLM(
            usersModels.tableToModel(row.users),
            LocationModel.tableToModel(row.location),
            activitiesModel.tableToModel(row.activities),
            sessionsModel.tableToModel(row.sessions),
            bookingsModel.tableToModel(row.bookings)
        );
    }

    static getAllBybookingsAll() {
        return this.query(`
            SELECT * FROM bookings
            INNER JOIN sessions ON bookings.Sessions_id = sessions.Sessions_id
            INNER JOIN users ON bookings.user_id = users.user_id
            INNER JOIN activities ON bookings.activity_id = activities.activity_id
            INNER JOIN location ON bookings.location_id = location.location_id
        `).then(result => result.map(row => this.tableToModel(row)));
    }

    static getAllBybookingAllid(bookingAllid) {
        return this.query(`
            SELECT * FROM bookings
            INNER JOIN sessions ON bookings.Sessions_id = sessions.Sessions_id
            INNER JOIN users ON bookings.user_id = users.user_id
            INNER JOIN activities ON bookings.activity_id = activities.activity_id
            INNER JOIN location ON bookings.location_id = location.location_id
            WHERE bookings.booking_id = ?
        `, [bookingAllid])
        .then(result => result.length > 0 ? this.tableToModel(result[0]) : Promise.reject("Not found"));
    }

    static getAllBybookingsUsers(userID) {
        return this.query(`
            SELECT * FROM bookings
            INNER JOIN sessions ON bookings.Sessions_id = sessions.Sessions_id
            INNER JOIN users ON bookings.user_id = users.user_id
            INNER JOIN activities ON bookings.activity_id = activities.activity_id
            INNER JOIN location ON bookings.location_id = location.location_id
            WHERE bookings.user_id = ?
        `, [userID]).then(result => result.map(row => this.tableToModel(row)));
    }

    static getBySearch(searchTerm) {
        return this.query(`
            SELECT * FROM bookings
            INNER JOIN sessions ON bookings.Sessions_id = sessions.Sessions_id
            INNER JOIN users ON bookings.user_id = users.user_id
            INNER JOIN activities ON bookings.activity_id = activities.activity_id
            INNER JOIN location ON bookings.location_id = location.location_id
            WHERE users.user_first_name LIKE ?
        `, [`%${searchTerm}%`])
        .then(result => result.length > 0 ? result.map(row => this.tableToModel(row)) : Promise.reject("Not found"));
    }

    static getAllByUserID(UserID) {
        return this.query(`
            SELECT * FROM bookings
            INNER JOIN sessions ON bookings.Sessions_id = sessions.Sessions_id
            INNER JOIN users ON bookings.user_id = users.user_id
            INNER JOIN activities ON bookings.activity_id = activities.activity_id
            INNER JOIN location ON bookings.location_id = location.location_id
            WHERE bookings.user_id = ?
        `, [UserID]).then(result => {
            return result.length > 0 ? result.map(row => this.tableToModel(row)) : Promise.reject("No matching results");
        });
    }
}



// Testing
// BookingALLM.getAllBybookingsAll().then(users => console.log(users)).catch(error => console.error(error));
// BookingALLM.getAllBybookingAllid(478).then(console.log).catch(console.error);
// BookingALLM.getBySearch("test").then(console.log).catch(console.error);
