import { DatabaseModel } from "./databaseModel.mjs";

export class bookingsModel extends DatabaseModel {
    constructor(id, user_id, Sessions_id, booking_created_datetime, activity_id, location_id) {
        super();
        this.id = id;
        this.user_id = user_id;
        this.Sessions_id = Sessions_id;
        this.booking_created_datetime = booking_created_datetime;
        this.activity_id = activity_id;
        this.location_id = location_id;
    }

    static tableToModel(row) {
        return new bookingsModel(
            row["booking_id"],
            row["user_id"],
            row["Sessions_id"],
            row["booking_created_datetime"],
            row["activity_id"],
            row["location_id"]
        );
    }

    /**
     * @returns {Promise<Array<bookingsModel>>}
     */
    static getAll() {
        return this.query("SELECT * FROM bookings")
            .then(result => result.map(row => this.tableToModel(row)));
    }

    /**
     * @param {bookingsModel} booking
     * @returns {Promise<mysql.OkPacket>}
     */
    static update(booking) {
        return this.query(
            `
            UPDATE bookings 
            SET user_id = ?, Sessions_id = ?, booking_created_datetime = ?, activity_id = ?, location_id = ? 
            WHERE booking_id = ?
            `,
            [
                booking.user_id,
                booking.Sessions_id,
                booking.booking_created_datetime,
                booking.activity_id,
                booking.location_id,
                booking.id
            ]
        );
    }

    /**
     * @param {bookingsModel} booking
     * @returns {Promise<mysql.OkPacket>}
     */
    static create(booking) {
        return this.query(
            `
            INSERT INTO bookings (user_id, Sessions_id, booking_created_datetime, activity_id, location_id)  
            VALUES (?, ?, ?, ?, ?)
            `,
            [
                booking.user_id,
                booking.Sessions_id,
                booking.booking_created_datetime,
                booking.activity_id,
                booking.location_id
            ]
        );
    }

    /**
     * @param {number} id
     * @returns {Promise<mysql.OkPacket>}
     */
    static deleteById(id) {
        return this.query("DELETE FROM bookings WHERE booking_id = ?", [id]);
    }

    /**
     * Get bookings by user and session.
     * @param {number} userId
     * @param {number} sessionsId
     * @returns {Promise<Array<bookingsModel>>}
     */
    static getByUserAndClass(userId, sessionsId) {
        return this.query(
            "SELECT * FROM bookings WHERE user_id = ? AND Sessions_id = ?",
            [userId, sessionsId]
        ).then(result => result.map(row => this.tableToModel(row)));
    }

    /**
     * Get all bookings by user ID.
     * @param {number} userID
     * @returns {Promise<Array<bookingsModel>>}
     */
    static getAllByUserID(userID) {
        return this.query(
            "SELECT * FROM bookings WHERE user_id = ?",
            [userID]
        ).then(result => result.map(row => this.tableToModel(row)));
    }
}

// Testing
// bookingsModel.getAll().then(bookings => console.log(bookings)).catch(error => console.error(error));
//  const newBooking = new bookingsModel(null, 62, 181, "224-12-03 00:00:00", 2, 2);
//  bookingsModel.create(newBooking).then(() => console.log("Booking created successfully!")).catch(error => console.error(error));
//  bookingsModel.deleteById(476).then(() => console.log("Booking deleted successfully!")).catch(error => console.error(error));
