import { DatabaseModel } from "./databaseModel.mjs";
import { users } from "./users.js";
import { Blog } from "./bolg_post.js";




  export class PostUsersModel extends  DatabaseModel{
    //   Instance 
    constructor (users,blog_post){
        super()
        this.users= users
         this . blog_post = blog_post


    }

    //  static 
    static tableToModel (row ) {
         return new  PostUsersModel(
            users. tableToModel ( row.users ),
            Blog. tableToModel( row.blog_post )
         )
  } 
/**
     * 
     * @param {string} Blog to filter by
     * @returns {Promise<Array<PostUsersModel>>}
     */
static getAllByBlog(Blog) {
    return this.query(
        `
        SELECT * FROM blog_post
        INNER JOIN users
        ON blog_post.post_user_id = users.user_id
    `,
    [Blog]
    ).then(result => result.map(row => this.tableToModel(row)));
}

static getAllBypostid(post) {
    return this.query(
        `
        SELECT * FROM blog_post
        INNER JOIN users
        ON blog_post.post_user_id = users.user_id
        WHERE blog_post.post_id = ?
    `,
    [post]
    ).then(result =>
        result.length > 0
            ? this.tableToModel(result[0])
            : Promise.reject("Not found")
    );
}

  }
// TESTING
// PostUsersModel.getAllByBlog()
//     .then(posts => console.log("All Posts with Users:", posts))
//     .catch(error => console.error("Error:", error));

// PostUsersModel.getAllBypostid(133) // Change ID as needed
//     .then(post => console.log("Post with User:", post))
//     .catch(error => console.error("Error:", error));
