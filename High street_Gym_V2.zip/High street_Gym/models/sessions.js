import { DatabaseModel } from "./databaseModel.mjs";

// Instance
export class sessionsModel extends DatabaseModel {
    constructor(Sessions_id, Sessions_datetime, location_id, activity_id, trainer_user_id) {
        super();
        this.Sessions_id = Sessions_id;
        this.Sessions_datetime = Sessions_datetime;
        this.location_id = location_id;
        this.activity_id = activity_id;
        this.trainer_user_id = trainer_user_id;
    }

    // Static
    static tableToModel(row) {
        const data = row.sessions || row; // Support both nested and flat rows
        if (!data) {
            console.error("Invalid row format:", row);
            return null;
        }
    
        return new sessionsModel(
            data.Sessions_id,
            data.Sessions_datetime,
            data.location_id,
            data.activity_id,
            data.trainer_user_id
        );
    }

    /**
     * @returns {Promise<Array<sessionsModel>>}
     */
    // Read
    static getAll() {
        return this.query("SELECT * FROM sessions")
            .then(result => {
                console.log("Raw Query Result:", result); // Debugging
                return result.map(row => this.tableToModel(row));
            })
            .catch(error => {
                console.error("Database Error:", error);
                return [];
            });
    }

    // GetByID
    static getById(id) {
        return this.query("SELECT * FROM sessions WHERE Sessions_id = ?", [id])
            .then(result =>
                result.length > 0
                    ? this.tableToModel(result[0])
                    : Promise.reject("not found")
            );
    }

    // Create
    static async create(sessions) {
        const [activityExists] = await this.query(
            "SELECT COUNT(*) AS count FROM activities WHERE activity_id = ?",
            [sessions.activity_id]
        );

        if (activityExists.count === 0) {
            return Promise.reject("Invalid activity_id: No matching activity found.");
        }

      

        return this.query(
            `
            INSERT INTO sessions
            (Sessions_datetime, location_id, activity_id, trainer_user_id) 
            VALUES (?, ?, ?, ?)
        `,
            [
                sessions.Sessions_datetime,
                sessions.location_id,
                sessions.activity_id,
                sessions.trainer_user_id,
            ]
        );
    }

    // Update
    static update(sessions) {
       
        return this.query(
            `
            UPDATE sessions 
            SET 
                Sessions_datetime = ?,
                location_id = ?,
                activity_id = ?,
                trainer_user_id = ?
            WHERE 
                Sessions_id = ?
        `,
            [
                sessions.Sessions_datetime,
                sessions.location_id,
                sessions.activity_id,
                sessions.trainer_user_id,
                sessions.Sessions_id,
            ]
        );
    }

    // Delete Session and Bookings
    static deleteSessionAndBookings(Sessions_id) {
        return this.query(`DELETE FROM bookings WHERE Sessions_id = ?`, [Sessions_id])
            .then(() => this.query(`DELETE FROM sessions WHERE Sessions_id = ?`, [Sessions_id]));
    }
}

// Testing Area (Remove before use!)
// const sessionIdToDelete = 145;
// sessionsModel.deleteSessionAndBookings(sessionIdToDelete)
//     .then(result => {
//         if (result.affectedRows > 0) {
//             console.log(`Session with ID ${sessionIdToDelete} and related bookings were deleted.`);
//         } else {
//             console.log(`No session found with ID ${sessionIdToDelete}.`);
//         }
//     })
//     .catch(error => console.error("Error deleting session and bookings:", error));

// Testing
// sessionsModel.getAll()
//  .then((locations) => console.log("Locations:", locations))
//    .catch((error) => console.error("Error fetching locations:", error));
