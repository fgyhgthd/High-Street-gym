import { DatabaseModel } from "./databaseModel.mjs";

export class activitiesModel extends DatabaseModel {
    constructor(activity_id, activity_name, activity_description, activity_duration) {
        super();
        this.activity_id = activity_id;
        this.activity_name = activity_name;
        this.activity_description = activity_description;
        this.activity_duration = activity_duration;
    }

    static tableToModel(row) {
        return new activitiesModel(
            row["activity_id"],  
            row["activity_name"],  
            row["activity_description"],  
            row["activity_duration"]
        );
    }

    /**
     * @returns {Promise<Array<activitiesModel>>}
     */
    static getAll() {
        return this.query("SELECT * FROM activities")
            .then(result => {
                console.log("Raw Database Rows:", JSON.stringify(result, null, 2));
                if (!result || result.length === 0) {
                    throw new Error("No activities found in the database.");
                }
                return result.map(row => {
                    console.log("Mapping Row:", row);
                    if (!row || !row.activities) {
                        console.error("Received undefined or invalid row!");
                        return null;
                    }
                    const mappedRow = {
                        activity_id: row.activities.activity_id || "N/A",
                        activity_name: row.activities.activity_name || "N/A",
                        activity_description: row.activities.activity_description || "N/A",
                        activity_duration: row.activities.activity_duration || "N/A"
                    };
                    console.log("Mapped Row:", mappedRow);
                    return mappedRow;
                });
            })
            .catch(error => {
                console.error("Database Query Error:", error);
                throw error;
            });
    }

    /**
     * @param {number} activity_id
     * @returns {Promise<activitiesModel>}
     */
    static getById(activity_id) {
        return this.query("SELECT * FROM activities WHERE activity_id = ?", [activity_id])
            .then(result => {
                console.log("Query Result by ID:", result);
                return result.length > 0 
                    ? {
                        activity_id: result[0].activities.activity_id || "N/A",
                        activity_name: result[0].activities.activity_name || "N/A",
                        activity_description: result[0].activities.activity_description || "N/A",
                        activity_duration: result[0].activities.activity_duration || "N/A"
                    }
                    : Promise.reject("Activity not found");
            });
    }

    /**
     * @param {string} name
     * @returns {Promise<Array<activitiesModel>>}
     */
    static getByName(name) {
        return this.query("SELECT * FROM activities WHERE LOWER(activity_name) = LOWER(?)", [name])
            .then(result => {
                console.log("Query Result by Name:", result);
                return result.length > 0 
                    ? result.map(row => {
                        if (!row || !row.activities) {
                            console.error("Received undefined or invalid row!");
                            return null;
                        }
                        return {
                            activity_id: row.activities.activity_id || "N/A",
                            activity_name: row.activities.activity_name || "N/A",
                            activity_description: row.activities.activity_description || "N/A",
                            activity_duration: row.activities.activity_duration || "N/A"
                        };
                    })
                    : Promise.reject("Activity not found");
            });
    }

    /**
     * @param {activitiesModel} activity 
     * @returns {Promise<mysql.OkPacket>}
     */
    static create(activity) {
        return this.query(`
            INSERT INTO activities (activity_name, activity_description, activity_duration)
            VALUES (?, ?, ?)
        `, [
            activity.activity_name,
            activity.activity_description,
            activity.activity_duration
        ]);
    }

    /**
     * @param {activitiesModel} activity
     * @returns {Promise<mysql.OkPacket>}
     */
    static updateActivityById(activity) {
        return this.query(`
            UPDATE activities
            SET activity_name = ?, activity_description = ?, activity_duration = ?
            WHERE activity_id = ?
        `, [
            activity.activity_name,
            activity.activity_description,
            activity.activity_duration,
            activity.activity_id
        ]);
    }

    /**
     * @param {number} activity_id
     * @returns {Promise<mysql.OkPacket>}
     */
    static deleteById(activity_id) {
        return this.query("DELETE FROM activities WHERE activity_id = ?", [activity_id]);
    }
}

// Testing
// activitiesModel.getAll()
//     .then(activities => console.log("Activities:", activities))
//     .catch(error => console.error("Error fetching Activities:", error));

// activitiesModel.getById(2)
//     .then(activity => console.log("Activity by ID:", activity))
//     .catch(error => console.error("Error fetching Activity by ID:", error));

// activitiesModel.getByName("Pilates")
//     .then(activities => console.log("Activities by Name:", activities))
//     .catch(error => console.error("Error fetching Activities by Name:", error));
//  crate 

// const newActivity = new activitiesModel(
//     null, // The ID will be auto-incremented
//     "Tesst",
//     "A relaxing and strengthening workout",
//     "60 minutes"
// );

// activitiesModel.create(newActivity)
//     .then(result => {
//         console.log("Activity created successfully:", result);
//     })
//     .catch(error => {
//         console.error("Error creating activity:", error);
//     });
//   update 
// const updatedActivity = new activitiesModel(
//     121, // Existing activity ID
//     "Advanced Yoga",
//     "A more challenging and intense yoga session",
//     "75 minutes"
// );

// activitiesModel.updateActivityById(updatedActivity)
//     .then(result => {
//         console.log("Activity updated successfully:", result);
//     })
//     .catch(error => {
//         console.error("Error updating activity:", error);
//     });
//   delte 
// const activityIdToDelete = 121;

// activitiesModel.deleteById(activityIdToDelete)
//     .then(result => {
//         console.log("Activity deleted successfully:", result);
//     })
//     .catch(error => {
//         console.error("Error deleting activity:", error);
//     });
