import mysql from "mysql2/promise";

export class DatabaseModel {
    static connection;

    static {
        this.connection = mysql.createPool({
            host: "localhost",
            user: "root",
            password: "root",
            database: "high street gym",
            port: "3309", // Ensure this is correct
            nestTables: true,
        });
    }

    /**
     * Executes a SQL query with provided values.
     * @param {string} sql - The SQL query string.
     * @param {any | Array<string>} values - The values to be passed into the query.
     * @returns {Promise<mysql.OkPacket | mysql.RowDataPacket>} - The result of the query.
     */
    static async query(sql, values) {
        try {
            const [result] = await this.connection.query(sql, values);
            return result;
        } catch (error) {
            console.error("Database Query Error:", error);
            throw error;
        }
    }

    /**
     * Converts a JavaScript Date object to MySQL Date format (YYYY-MM-DD).
     * @param {Date} date - The JavaScript Date object.
     * @returns {string} - The formatted date string.
     */
    static toMySqlDate(date) {
        const year = date.toLocaleString('default', { year: 'numeric' });
        const month = date.toLocaleString('default', { month: '2-digit' });
        const day = date.toLocaleString('default', { day: '2-digit' });
        return [year, month, day].join('-');
    }
}
